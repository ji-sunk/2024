import { Link } from "react-router-dom";
import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Autoplay, Navigation, Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

let slideInx = 0;
const BannSwiper = () => {
  SwiperCore.use([Navigation, Scrollbar, Autoplay, Pagination]);
  return (
    <>
      <div className="bp-main-bann">
        <div className="swiper-container">
          <Swiper
            autoplay={{
              delay: 2500,
              disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
            }}
            loop={true} // 슬라이드 루프
            centeredSlides={true}
            spaceBetween={12} // 슬라이스 사이 간격
            slidesPerView={1} // 보여질 슬라이스 수
            navigation={false} // prev, next button
            grabCursor={true}
            pagination={{
              el: ".pagination-bullets",
              type: "bullets",
            }}
            initialSlide={slideInx}
            watchSlidesProgress
          >
            <SwiperSlide className="bp-item">
              <div className="img-area">
                <div className="img-bann">
                  <Link to="">
                    <img src="/assets/images/img-bann-pr.png" />
                  </Link>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide className="bp-item">
              <div className="img-area">
                <div className="img-bann">
                  <img src="/assets/images/img-bann-pr2.png" />
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide className="bp-item">
              <div className="img-area">
                <div className="img-bann">
                  <img src="/assets/images/img-bann-pr3.png" />
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
        <div className="pagination-bullets"></div>
      </div>
    </>
  );
};

export default BannSwiper;
