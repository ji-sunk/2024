import { Close } from "@mui/icons-material";
import {
  Box,
  FormControl,
  FormControlLabel,
  IconButton,
  Paper,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";

import { useState } from "react";

type Anchor = "top" | "left" | "bottom" | "right";

const ListDrawerMf = () => {
  // [Drawer]
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [RadioValueCard, setRadioValueCard] = useState("radioCard-01");
  const handleChangeradioCard = (event) => {
    setRadioValueCard(event.target.value);
  };
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    listDrawer2: false, //성별
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  return (
    <>
      <SwipeableDrawer
        anchor="bottom"
        open={isDrawerOpen.listDrawer2}
        onClose={toggleDrawer("listDrawer2", false)}
        onOpen={toggleDrawer("listDrawer2", true)}
        className="bp-drawer drawer-bottom"
      >
        <div className="drawer-header" id="drawer-header">
          <div className="inner">
            <Box className="left-area"></Box>
            <Box className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={toggleDrawer("listDrawer2", false)}
              >
                <Close fontSize="small" className="bp-icon" />
              </IconButton>
            </Box>
          </div>
          <div className="inner">
            <Box className="left-area">
              <Typography variant="h2">성별</Typography>
            </Box>
          </div>
        </div>
        <Paper className="drawer-body">
          <Box className="drawer-cont">
            <div className="box-inner">
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radioCard-01"
                  name="radio buttons group"
                  value={RadioValueCard}
                  className="bp-btns-group fullWidth list-radio"
                  onChange={handleChangeradioCard}
                  row
                >
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-01" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-01" />}
                    label="남자"
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-02" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-02" />}
                    label="여자"
                  />
                </RadioGroup>
              </FormControl>
            </div>
          </Box>
        </Paper>
      </SwipeableDrawer>
    </>
  );
};

export default ListDrawerMf;
