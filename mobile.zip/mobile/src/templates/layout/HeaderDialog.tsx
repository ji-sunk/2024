import { ReactNode } from "react";

import { AppBar, Box, Button, IconButton } from "@mui/material";
import { GridCloseIcon } from "@mui/x-data-grid";
import { ArrowNarrowLeft } from "@untitled-ui/icons-react";

interface HeaderDialogProps {
  children?: ReactNode;
}

const HeaderDialog = (props: HeaderDialogProps) => {
  return (
    <>
      <AppBar position="fixed" className="sub-header">
        <Box className="inner">
          <div className="left-area">
            <Button
              size="medium"
              className="btn-text-primary"
              startIcon={
                <ArrowNarrowLeft fontSize="medium" className="bp-icon medium" />
              }
            >
              MY카드
            </Button>
            {/* [D]logo */}
          </div>
          <div className="right-area">
            <IconButton
              className="btn-icon-only"
              size="small"
              aria-label="닫기"
              // onClick={toggleDrawer("drawer1", false)}
            >
              <GridCloseIcon fontSize="small" className="bp-icon" />
            </IconButton>
          </div>
        </Box>
      </AppBar>
    </>
  );
};

export default HeaderDialog;
