import { ArrowNarrowLeft } from "@untitled-ui/icons-react";
import { ReactNode } from "react";
import {
  Avatar,
  Box,
  Button,
  Chip,
  IconButton,
  Paper,
  AppBar,
  Typography,
} from "@mui/material";
import { ChevronRight, Menu04, Settings02, SearchSm } from "@untitled-ui/icons-react";
import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";
import AllMenuDrawer from "src/components/common/AllMenuDrawer";

interface HeaderSubProps {
  children?: ReactNode;
}

const HeaderSub = (props: HeaderSubProps) => {
  return (
    <>
      <AppBar position="fixed" className="sub-header">
        <Box className="inner">
          <div className="left-area">
            <Button
              size="medium"
              className="btn-text-primary"
              startIcon={
                <ArrowNarrowLeft fontSize="medium" className="bp-icon medium" />
              }
            ></Button>
            {/* [D]logo 메인header */}
          </div>
          {/* 비플페이 look과 비슷하게 title위치를 center로 변경 */}
          {/* 다국어, 사이드 아이콘 갯수 여부에 따라서 타이틀(text) 보여지는 영역이 너무 작아 몇글자 보이지 않음 - 이슈로 left 변경 240911 kjs */}
          <div className="center-area">
            <Typography variant="h2" className="bp-title bp-ellipsis">{/* bp-ellipsis 클래스 추가(...말줄임) 240911 kjs */}
              서브타이틀(h2)
            </Typography>
          </div>
          <Box className="right-area">
            {/* [D]개발시 분기처리 */}
            {/* <IconButton
              className="btn-icon-only"
              size="small"
              aria-label="설정"
            >
              <Settings02 fontSize="small" className="bp-icon" />
            </IconButton>
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="검색"
            >
              <SearchSm fontSize="medium" />
            </IconButton>
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="결재"
            >
              <ApprovalOutlinedIcon fontSize="medium" />
            </IconButton> */}
            <AllMenuDrawer />
          </Box>
        </Box>
      </AppBar>
    </>
  );
};

export default HeaderSub;
