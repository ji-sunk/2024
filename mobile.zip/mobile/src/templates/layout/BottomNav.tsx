import { ReactNode } from "react";

import { Box, List, ListItem } from "@mui/material";
import { Link } from "react-router-dom";

interface BottomNavProps {
  children?: ReactNode;
}

// const navBtns = [
//   { id: 1, name: "가이드", url: "/guide" },
//   { id: 2, name: "작업 파일 경로", url: "/guide/path" },
// ];

const BottomNav = (props: BottomNavProps) => (
  <>
    <Box className="bottom-nav">
      <Box component="nav" className="inner">
        <List className="menu-bar" disablePadding role="navigation">
          <ListItem>
            <Link to="" className="item" aria-selected="true">
              <img
                src="/assets/images/icons/icon-home.svg"
                width={24}
                height={24}
                alt="홈"
              />
              {/* <img src="/assets/images/icons/icon-home-outline.svg" width={24} height={24} alt="홈" /> */}
              <Box className="text">홈</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-write-outline.svg"
                width={24}
                height={24}
                alt="예약"
              />
              {/* <img src="/assets/images/icons/icon-write.svg" width={24} height={24} alt="예약" /> */}
              <Box className="text">예약</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-qr-outline.svg"
                width={24}
                height={24}
                alt="QR결제"
              />
              {/* <img src="/assets/images/icons/icon-qr.svg" width={24} height={24} alt="QR결제" /> */}
              <Box className="text">QR결제</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-payment-outline.svg"
                width={24}
                height={24}
                alt="정산"
              />
              {/* <img src="/assets/images/icons/icon-payment.svg" width={24} height={24} alt="정산" /> */}
              <Box className="text">정산</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-my-outline.svg"
                width={24}
                height={24}
                alt="My"
              />
              {/* <img src="/assets/images/icons/icon-my.svg" width={24} height={24} alt="My" /> */}
              <Box className="text">My</Box>
            </Link>
          </ListItem>
        </List>
        {/* <List>
            {navBtns.map((item) => (
              <ListItem key={item.id} disablePadding>
                <Link to={item.url}>{item.name}</Link>
              </ListItem>
            ))}
          </List> */}
      </Box>
    </Box>
  </>
);

export default BottomNav;
