import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG020100 = () => {
  const [selected, setSelected] = React.useState(false);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>bizplay이용약관</title>
      </Head>
      {/* [S]bizplay이용약관 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">bizplay이용약관</Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            {/* [S]terms-details */}
            <div className="terms-details">
              <p className="text-hide">bizplay이용약관</p>
              <p className="title-chapter">제1장 총칙</p>
              <ul>
                <li>
                  <p>제1조 (목적)</p>
                  <div>
                    본 약관은 비즈플레이㈜(이하 “당사”라 한다)가 제공하는
                    “bzp출장관리” 서비스를 이용하는 고객(이하 “고객”)의 권리,
                    의무 및 책임사항을 규정함을 목적으로 합니다.
                  </div>
                </li>
                <li>
                  <p>제2조 (정의)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> “bzp출장관리”란 당사 또는
                      입점업체가 제공하는 재화 또는 용역(이하 “재화 등”이라
                      한다)을 이용자가 구매할 수 있도록 당사가 컴퓨터 등
                      정보통신실비를 기반으로 당사가 설정한 가상의
                      영업장(https://travel-m.bizplay.co.kr,
                      https://travel.vizplay.co.kr) 또는 이를 운영하는 사업자로
                      당사가 현재 운영하고 있는 사이버 사업장과 콜센터를
                      말합니다.
                    </li>
                    <li>
                      <span className="num">②</span> "입점업체"란 bzp출장관리를
                      통하여 자신이 제공하는 재화 등을 이용고객이 구매할 수
                      있도록 당사와 계약을 맺은 사업자로서 통신판매를 업으로
                      하는 사업자 또는 그와의 약정에 따라 통신판매업무를
                      수행하는 사업자를 말합니다.
                    </li>
                    <li>
                      <span className="num">③</span> "이용고객"이란
                      bzp출장관리에 접속하여 해당 약관에 따라 bzp출장관리가
                      제공하는 서비스를 받는 회원 및 비회원을 말합니다.
                    </li>
                    <li>
                      <span className="num">④</span> "서비스"라 함은
                      bzp출장관리에서 예약/구매 및 경비 정산 기능을 사용할 수
                      있도록 하는 제반 서비스를 의미합니다.
                    </li>
                    <li>
                      <span className="num">⑤</span> "회원"이란 bzp출장관리에
                      개인정보를 제공하여 회원등록을 한 자로서 이 약관을
                      승인하고 bzp출장관리를 계속적으로 이용할 수 있는 자를
                      말합니다. 회원의 ID, 비밀번호 등 회원가입 시 제공한
                      개인정보에 관한 제반사항 등은 당사에서 통합 관리합니다.
                    </li>
                    <li>
                      <span className="num">⑥</span> "비회원"이란 bzp출장관리의
                      회원 등록은 하지 아니한 채 bzp출장관리가 제공하는 서비스를
                      이용하는 자를 말합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제3조 (약관 등의 명시와 설명 및 개정)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 약관의 내용과 상호 및
                      대표자 성명, 영업소 소재지 주소(소비자의 불만을 처리할 수
                      있는 곳의 주소를 포함), 전화번호, 전자우편주소,
                      사업자등록번호, 통신판매원 신고번호, 개인정보보호책임자
                      등을 이용자가 쉽게 알 수 있도록 당사 또는 bzp출장관리의
                      전면에 게시합니다. <br />
                      다만, 약관의 내용은 이용자가 연결화면을 통하여 볼 수
                      있도록 할 수 있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용자가 약관의 동의하기에
                      앞서 약관에 정하여져 있는 내용 중 청약철회. 배송책임.
                      환불조건 등과 같은 중요한 내용을 이용자가 이해할 수 있도록
                      제공하여 이용자의 확인을 구하여야 합니다.
                    </li>
                    <li>
                      <span className="num">③</span> ‘전자금융거래법’,
                      ‘정보통신망 이용촉진 및 정보보호 등에 관한 법률’, ‘소비자
                      기본법’ 등 관련 법을 위배하지 않는 범위에서 약관을 개정할
                      수 있습니다.
                    </li>
                    <li>
                      <span className="num">④</span> 약관을 개정할 경우 적용일자
                      및 개정사유를 명시하여 현행약관과 함께 당사 또는
                      bzp출장관리 서비스화면에 그 적용일자 일주일 전부터
                      공지합니다. 다만, 이용자에게 불리하게 약관내용을 변경하는
                      경우에는 최소 한 달(30일) 이상의 사전 유예기간을 두고
                      공지합니다. 이 경우 bzp출장관리는 개정 전 내용과 개정 후
                      내용을 명확하게 비교하여 이용자가 알기 쉽도록 표시합니다.
                    </li>
                    <li>
                      <span className="num">⑤</span> 약관을 개정할 경우 해당
                      개정약관 적용일자 이후에 체결되는 계약에만 적용되고 그
                      이전에 이미 체결된 계약에 대해서는 개정 전의 약관 조항을
                      그대로 적용합니다. 다만, 이미 계약을 체결한 이용자가
                      개정약관 조항의 적용을 받기를 원하는 뜻을 제4항에 의한
                      개정약관의 공지기간 내에 bzp출장관리에 송신하여
                      bzp출장관리의 동의를 받은 경우에는 개정약관 조항이
                      적용됩니다.
                    </li>
                    <li>
                      <span className="num">⑥</span> 이 약관에서 정하지 아니한
                      사항과 이 약관의 해석에 관하여는 ‘약관의 규제 등에 관한
                      법률’, 공정거래위원회가 정하는 전자상거래 등에서의 소비자
                      보호지침 및 관계법령 또는 상관례에 따릅니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p className="title">제4조 (서비스의 제공 및 변경)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리는 다음과 같은
                      업무를 수행합니다.
                      <div className="box-indent">- 출장 여행 서비스</div>
                      <div className="box-indent">
                        - 기타 회사가 정하는 업무
                      </div>
                    </li>
                    <li>
                      <span className="num">②</span> bzp출장관리는 “재화”의 품절
                      또는 기술적 사양의 변경 등의 경우에는 장차 체결되는 계약에
                      의해 제공할 재화의 내용을 변경할 수 있습니다. 이 경우에는
                      변경된 재화 내용 및 제공일자를 명시하여 현재의 재화의
                      내용을 게시한 곳에 즉시 공지합니다.
                    </li>
                    <li>
                      <span className="num">③</span> bzp출장관리가 제공하기로
                      이용자와 계약을 체결한 서비스의 내용을 재화 등의 품절 또는
                      기술적 사양의 변경 등의 사유로 변경할 경우에는 그 사유를
                      이용자에게 통지 가능한 주소 또는 이메일로 즉시 통지합니다.
                    </li>
                    <li>
                      <span className="num">④</span> 전항의 경우 bzp출장관리는
                      이로 인하여 이용자가 입은 손해를 배상합니다. 다만,
                      입점업체가 재화 등을 공급하는 경우에는 bzp출장관리의 고의
                      또는 과실이 있거나 관련 법령 상 규정된 경우를 제외하고는
                      입점업체가 부담하기로 합니다. 이용자는 입점업체에 관한
                      정보를 bzp출장관리에 서면 요청(이메일 포함)할 수 있으며 이
                      경우 bzp출장관리는 법령이 허용하는 범위 내에서 동 정보를
                      제공하여야 합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p className="title">제5조 ((서비스의 중단))</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리는 컴퓨터 등
                      정보통신설비의 보수점검, 교체 및 고장, 통신의 두절 등의
                      사유가 발생한 경우 서비스의 제공을 일시적으로 중단할 수
                      있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> bzp출장관리는 제1항의
                      사유로 서비스의 제공이 일시적으로 중단됨으로 인하여 이용자
                      또는 제3자가 입은 손해에 대하여 배상합니다. 단,
                      bzp출장관리의 고의 또는 과실이 없음을 입증한 경우에는
                      그러하지 아니합니다.
                    </li>
                    <li>
                      <span className="num">③</span> 사업 종목의 전환, 사업의
                      포기, 업체 간의 통합 등의 이유로 서비스를 제공할 수 없게
                      되는 경우 bzp출장관리는 제8조에 정한 방법으로 이용고객에게
                      통지하고, 당초 bzp출장관리에서 제시한 조건에 따라
                      이용고객에게 보상합니다. 다만, bzp출장관리가 보상 기준
                      등을 고지하지 아니한 경우에는 이용고객들의 이용권 등을
                      bzp출장관리에 통용되는 통화가치에 상응하는 현물 또는
                      현금으로 지급합니다.
                    </li>
                  </ol>
                </li>
              </ul>

              <p className="title-chapter">제2장 회원가입계약</p>
              <ul>
                <li>
                  <p>제6조 (회원가입)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 회원가입을 원하는 자는
                      bzp출장관리가 정한 회원가입 양식에 따라 회원정보를 기입한
                      후 이 약관에 동의한다는 표시를 함으로 회원가입을
                      신청합니다.
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">②</span> 제1항과 같이 회원으로
                        가입할 것을 신청한 이용고객 중 다음 각 호에 해당되지
                        않는 한 회원으로 등록합니다.
                      </div>
                      <div className="box-indent">
                        1.가입신청자가 이 약관 제7조 제3항에 의거하여 이전에
                        회원자격을 상실한 적이 있는 경우
                      </div>
                      <div className="box-indent">
                        2. 등록 내용에 허위, 기재 누락, 오기가 있는 경우
                      </div>
                      <div className="box-indent">
                        3. 기타 회원으로 등록하는 것이 회사의 기술상 현저히
                        지장이 있다고 판단되는 경우
                      </div>
                      <div className="box-indent">
                        4. 만 14세 미만의 아동인 경우
                      </div>
                    </li>
                    <li>
                      <span className="num">③</span> 회원가입 계약의 성립시기는
                      bzp출장관리가 회원 가입을 승인한 시점으로 합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제7조 (회원 탈퇴 및 자격 상실 등)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 회원은 언제든지 탈퇴를
                      요청할 수 있으며 bzp출장관리는 즉시 회원탈퇴를 처리합니다.
                      다만, 해지의사를 통지하기 전에 모든 재화의 판매 및 구매
                      절차를 완료, 철회 또는 취소해야만 합니다. 이 경우 판매 및
                      구매의 철회 또는 취소로 인한 불이익은 회원 본인이
                      부담하여야 합니다.
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">②</span> 회원이 각 호의 사유에
                        해당하는 경우 bzp출장관리는 회원자격을 제한 및 정지시킬
                        수 있습니다.
                      </div>
                      <div className="box-indent">
                        1. 가입 신청 시에 허위 내용을 등록한 경우
                      </div>
                      <div className="box-indent">
                        2. bzp출장관리를 이용하여 구입한 재화 등의 대금, 기타
                        bzp출장관리 이용에 관련하여 회원
                        <br />이 부담하는 채무를 기일에 지급하지 않는 경우
                      </div>
                      <div className="box-indent">
                        3. 다른 사람의 서비스 이용을 방해하거나 그 정보를
                        도용하는 등 전자상거래 질서를 위협하는 경우
                      </div>
                      <div className="box-indent">
                        4. bzp출장관리를 이용하여 법령 또는 이 약관이 금지하거나
                        공서양속에 반하는 행위를 하는 경우
                      </div>
                      <div className="box-indent">
                        5. 기타 회원으로서 자격을 지속시키는 것이 부적절하다고
                        판단되는 경우
                      </div>
                    </li>
                    <li>
                      <span className="num">③</span> 회원자격을 제한. 정지시킨
                      후 동일한 행위가 2회 이상 반복되거나 30일이내에 그 사유가
                      시정되지 아니한 경우 bzp출장관리는 회원자격을 상실시킬 수
                      있습니다.
                    </li>
                    <li>
                      <span className="num">④</span> 회원자격을 상실시키는
                      경우에는 회원등록을 말소합니다. 이 경우 회원에게 이를
                      통지하고 회원등록 말소 전에 최소한의 기간을 정하여 소명화
                      기회를 부여합니다. 단, 제2항 각 호의 사유에 해당하는
                      행위를 한 회원에 대해서는 회원자격 상실일로부터 3년간
                      정보를 보유합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제8조 (회원에 대한 통지)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 불특정다수 회원에 대한
                      통지를 하는 경우 1주일이상 bzp출장관리에 게시함으로써 개별
                      통지로 갈음할 수 있습니다. 다만, 회원 본인의 거래와
                      관련하여 중대한 영향을 미치는 사항에 대하여는 개별통지를
                      할 수 있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 개별 회원에 대한 통지를
                      하는 경우, 회원이 bzp출장관리와 미리 약정하여 지정한
                      전자우편주소로 요청할 수 있습니다.
                    </li>
                  </ol>
                </li>
              </ul>

              <p className="title-chapter">제3장 구매계약</p>
              <ul>
                <li>
                  <p>제9조 (구매신청 및 개인정보 제공 동의)</p>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> bzp출장관리는 이용고객이
                        구매신청 함에 있어 다음의 각 내용을 알기 쉽게 제공하여야
                        합니다. 단, 회원의 경우 제2호 내지 제4호에 적용을 제외할
                        수 있습니다.
                      </div>
                      <div className="box-indent">
                        1. 재화 등의 검색 및 선택
                      </div>
                      <div className="box-indent">
                        2. 제3자에게 구매자 개인정보를 제공할 필요가 있는 경우
                      </div>
                      <div className="box-indent">
                        3. 약관내용, 청약철회권이 제한되는 서비스, 배송료.
                        설치비 등의 비용부담과 관련한 내용에 대한 확인
                      </div>
                      <div className="box-indent">
                        4. 이 약관에 동의하고 위3호의 사항을 확인하거나 거부하는
                        표시(예. 마우스 클릭)
                      </div>
                      <div className="box-indent">
                        5. 재화 등의 구매신청 및 이에 관한 확인 또는 bzp출장관리
                        이용 확인에 대한 동의
                      </div>
                      <div className="box-indent">6. 결제 방법의 선택</div>
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">②</span> bzp출장관리 상에서 다음
                        도는 이와 유사한 방법에 의하여 구매를 신청하며,
                        bzp출장관리는 이용 고객이 구매신청을 함에 있어서 다음의
                        각 내용을 알기 쉽게 제공하여야 합니다. 단, 회원의 경우
                        제2호 내지 제4호에 적용을 제외할 수 있습니다
                      </div>
                      <div className="box-indent">
                        1. 개인정보를 제공받는 자
                      </div>
                      <div className="box-indent">
                        2. 개인정보를 제공받는 자의 개인정보 이용목적
                      </div>
                      <div className="box-indent">
                        3. 제공하는 개인정보의 항목
                      </div>
                      <div className="box-indent">
                        4. 개인정보를 제공받는 자의 개인정보 보유 및 이용기간을
                        구매자에게 알리고 동의를 합니다.
                      </div>
                    </li>
                    <li>
                      <span className="num">③</span> 제3자에게 구매자의
                      개인정보를 취급할 수 있도록 업무를 위탁하는 경우에는
                      1)개인정보 취급위탁을 받는 자, 2)개인정보 취급위탁을 하는
                      업무의 내용을 구매자에게 알리고 동의를 받아야 합니다. 단,
                      서비스제공에 관한 계약이행 및 구매자의 편의증진과 관련된
                      경우에는 ‘정보통신망 이용촉진 및 정보보호 등에 관한
                      법률’에서 정하고 있는 방법으로 개인정보 취급방침을 통해
                      알림으로써 고지절차를 거치지 않아도 됩니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제10조 (계약의 성립)</p>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> bzp출장관리는 제9조와
                        같은 구매신청에 대하여 다음 각 호에 해당하면 승인하지
                        않을 수 있습니다.
                      </div>
                      <div className="box-indent">
                        1. 신청 내용에 허위, 기재누락, 오기가 있는 경우
                      </div>
                      <div className="box-indent">
                        2. 미성년자가 청소년 보호법에서 금지하는 재화 및 용역을
                        구매하는 경우
                      </div>
                      <div className="box-indent">
                        3. 구매신청 물품의 품절이나 기타 구매신청에 승인하는
                        것이 bzp출장관리의 기술상 현저히 지장을 주는 것으로
                        판단되는 경우
                      </div>
                      <div className="box-indent">
                        4. 기타 제반 법령 및 정부의 가이드라인에 위반되거나
                        제7조에 해당하는 경우 등
                      </div>
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">②</span> 제12조 제1항의 구매확인
                        통지형태로 bzp출장관리의 승인이 이용고객에게 도달한 후
                        계약금이 입금된 시점에 계약이 성립한 것으로 봅니다.
                      </div>
                    </li>
                    <li>
                      <span className="num">③</span> 승인의 의사표시에는
                      이용고객의 구매 신청에 대한 확인 및 판매가능 여부,
                      구매신청의 정정.취소 등에 관한 정보를 포함하여야 합니다.
                    </li>
                  </ol>
                </li>
              </ul>

              <p className="title-chapter">제4장 대금결제</p>
              <ul>
                <li>
                  <p>제11조 (지급방법)</p>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> bzp출장관리에서 구매한
                        재화 또는 용역에 대한 대금지급방법은 다음 각 호중 하나
                        또는 그 이상의 방법으로 결제할 수 있습니다.
                      </div>
                      <div className="box-indent">1. 각종 신용카드 결제</div>
                      <div className="box-indent">
                        2. 기타 bzp출장관리 및 회사가 정하는 결제수단
                      </div>
                    </li>
                    <li>
                      <span className="num">②</span> 구매대금의 결제와 관련하여
                      이용고객이 입력한 정보 및 그와 관련된 책임은 이용고객에게
                      있으며, 재화 또는 용역의 청약 후 합리적인 일정기간 내에
                      이루어지지 않는 경우 당사는 이에 해당 주문을 취소할 수
                      있습니다.
                    </li>
                    <li>
                      <span className="num">③</span> 이용고객은 구매하려는
                      재화의 내용과 거래 조건을 확인하지 않고 구매하여 발생한
                      모든 손실, 손해에 대한 책임을 부담하여야 합니다. 또한
                      이용자는 재화의 구매 시 반드시 본인 명의의 결제수단을
                      사용하여야 하며 타인의 결제수단을 임의사용 하여서는
                      안됩니다. 타인의 결제수단을 임의 사용함으로써 발생하는
                      손실과 손해에 대한 모든 책임(회사, 결제수단의 적법한
                      소유자, 전자결제대행 중개서비스 사업자에 해당)은
                      이용자에게 있습니다. 이와 관련해 회사는 정당하고 적법한
                      거래 여부를 확인하기 위해 소명자료 제출을 요청할 수 있으며
                      이용자 결제수단의 적법성 등에 대한 확인이 완료될 때까지
                      거래진행을 중지하거나 해당 거래를 취소할 수 있습니다. 그
                      밖에 구매의사 없는 반복적인 구매행위, 비정상적인 방법으로
                      서비스를 이용하거나 시스템에 접근하는 행위 역시 금지
                      됩니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제12조 (구매확인 통지, 구매신청 변경 및 취소)</p>
                  <div>
                    bzp출장관리에서 이용고객의 구매신청이 있는 경우 이용고객에게
                    구매확인 통지를 합니다. <br />
                    <br />
                    구매확인 통지를 받은 이용자는 의사표시의 불일치 등이 있는
                    경우에는 구매확인 통지를 받은 후 즉시 구매신청 변경 및
                    취소를 요청할 수 있고, bzp출장관리는 이용자의 요청이 있는
                    경우 지체 없이 요청에 따라 처리하여야 합니다. 다만, 이미
                    대금을 지불한 경우에는 제15조의 청약철회 등에 관한 규정에
                    따릅니다.
                  </div>
                </li>
              </ul>

              <p className="title-chapter">제5장 배송 • 취급 • 환급</p>
              <ul>
                <li>
                  <p>제13조 (재화 등의 공급, 배송)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리는 이용고객과
                      재화 등의 공급시기에 관하여 별도의 약정이 없는 이상
                      이용자가 청약을 한 날부터 7일 이내에 재화 등을 제공할 수
                      있도록 예약 등 기타의 필요한 조치를 취합니다. 다만,
                      bzp출장관리는 이미 재화 등의 대금의 전부 또는 일부를 받은
                      경우에는 대금의 전부 또는 일부를 받은 날부터 3영업일
                      이내에 조치를 취합니다. 이때 bzp출장관리는 이용자가 재화
                      등의 공급절차 및 진행사항을 확인할 수 있도록 적절한 조치를
                      합니다. 단, 여행상품과 같은 무형의 재화 공급은 해당 상품에
                      적용되는 별도의 약관을 교부하고 차질 없이 출발할 수 있도록
                      일련의 조치를 하여야 합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객이 구매한 재화에
                      대해 제공수단, 수단별 제공비용 부담자, 수단별 제공기간
                      등을 명시합니다. 만약 bzp출장관리가 약정제공기간을 초과한
                      경우 그로 인한 이용자의 손해를 배상하여야 합니다. 다만,
                      bzp출장관리의 고의. 과실이 없음을 입증한 경우에는 그러하지
                      아니합니다. 단, 여행상품과 같은 무형의 재화 공급은 예약한
                      상품에 대한 별도의 여행자 계약서 등을 교부하여 이용고객이
                      상품의 구매와 이용에 대해 숙지할 수 있도록 하여야 합니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>제14조 (환급)</p>
                  <div>
                    이용고객이 구매 신청한 재화 또는 용역이 품절 등의 사유로
                    재화의 인도 또는 용역의 제공을 할 수 없을 때에는 지체없이 그
                    사유를 회원에게 통지하고, 사전에 재화 또는 용역의 대금을
                    받은 경우 대금을 받은 날부터 5영업일 이내에, 그렇지 않은
                    경우 그 사유발생일로부터 5영업일 이내에 계약해제 및 환급에
                    필요한 조치를 취합니다. 단, 여행상품의 경우 상품의 특성상
                    이용자가 출발일전 모든 예약이 완료된 이후 계약을 해지할 경우
                    국내(외) 여행표준약관 및 국내(외) 소비자 피해보상규정에 의거
                    손해 배상액을 공제하고 환불하며, 기타 상품의 상품이용
                    계약체결 시 계약한 특별약관 등의 규정에 의거한 상품의 취소
                    및 환불 수수료를 공제하고 환불합니다.
                  </div>
                </li>

                <li>
                  <p>제15조 (청약철회 등)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리에서 재화 등의
                      구매에 관한 계약을 체결한 이용고객은 계약내용에 관한
                      서면을 받은 날부터 7일 이내에 청약의 철회를 할 수
                      있습니다. 다만, 여행상품의 경우 국내(외) 여행표준약관에
                      의한 환급 기준에 따라 별도의 취소수수료가 부과될 수
                      있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객은 제1항의 규정에도
                      불구하고 재화 등의 내용이 표시 광고 내용과 다르거나
                      계약내용과 다르게 이행된 때에는 당해 재화 등을 공급받은
                      날부터 3일 이내, 그 사실을 알 수 있었던 날부터 30일 이내에
                      청약철회 등을 할 수 있습니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>제16조 (청약철회 등의 효과)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리는
                      이용고객으로부터 재화 등을 반환 받은 경우 5영업일 이내에
                      이미 지급받은 재화 등의 대금을 환급합니다. bzp출장관리가
                      이용고객에게 재화 등의 환급을 지연한 때에는 지연기간에
                      대하여 공정거래위원회가 정하여 고시하는 지연이자율을
                      곱하여 산정한 지연이자를 지급합니다.
                    </li>
                    <li>
                      <span className="num">②</span> bzp출장관리는 위 대금을
                      환급함에 있어 이용고객이 신용카드 또는 전자화폐 등의
                      결제수단으로 재화 등의 대금을 지급한 때에는 지체 없이
                      결제수단을 제공한 사업자로 하여금 재화 등의 대금의 청구
                      정지 또는 취소하도록 요청합니다.
                    </li>
                    <li>
                      <span className="num">③</span> 청약철회 등의 경우 공급받은
                      재화 등의 반환에 필요한 비용은 이용고객이 부담합니다.
                      bzp출장관리는 이용고객에게 청약철회 등을 이유로 위약금
                      또는 손해배상을 청구하지 않습니다. 다만, 재화 등의 내용이
                      표시 내용과 다르거나 계약내용과 다르게 이행되어 청약철회를
                      하는 경우 재화 등의 반환에 필요한 비용은 bzp출장관리가
                      부담합니다.
                    </li>
                  </ol>
                </li>
              </ul>

              <p className="title-chapter">
                제6장 bzp출장관리와 이용고객의 의무사항
              </p>
              <ul>
                <li>
                  <p>제17조 (개인정보보호)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리는 이용고객의
                      개인정보 수집 시 서비스제공을 위하여 필요한 범위에서
                      최소한의 개인정보를 수집합니다.
                    </li>
                    <li>
                      <span className="num">②</span> bzp출장관리는
                      구매계약이행에 필요한 정보를 미리 수집하지 않습니다. 다만,
                      관계 법령상 의무이행을 위하여 구매계약 이전에 본인확인이
                      필요한 경우 최소한의 특정 개인정보를 수집할 수 있습니다.
                    </li>
                    <li>
                      <span className="num">③</span> 이용고객의 개인정보를 수집.
                      이용하는 때에는 당해 이용자에게 그 목적을 고지하고 동의를
                      받습니다.
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">④</span> 수집된 개인정보를 목적
                        외의 용도로 이용할 수 없으며 새로운 이용목적이 발생한
                        경우 또는 제3자에게 제공하는 경우에는 이용. 제공단계에서
                        당해 이용자에게 그 목적을 고지하고 동의를 받습니다.
                        다만, 다음의 경우에는 예외로 합니다.
                      </div>
                      <div className="box-indent">
                        1. 배송업무상 배송업체에게 배송에 필요한 최소한의
                        이용자의 정보(성명, 주소, 전화번호)를 알려주는 경우
                      </div>
                      <div className="box-indent">
                        2. 통계작성, 학술연구 또는 시장조사를 위하여 필요한
                        경우로서 특정 개인을 식별 할 수 없는 형태로 제공하는
                        경우
                      </div>
                      <div className="box-indent">
                        3. 관계법령에서 달리 정함이 있는 경우
                      </div>
                    </li>
                    <li>
                      <span className="num">⑤</span> 제2항과 제3항에 의해
                      이용고객의 동의를 받아야 하는 경우에는 개인정보관리
                      책임자의 신원(소속, 성명 및 전화번호, 기타 연락처), 정보의
                      수집목적 및 이용목적, 제3자에 대한 정보제공
                      관련사항(제공받은 자, 제공목적 및 제공할 정보의 내용)등
                      ‘정보통신망 이용촉진 및 정보보호 등에 관한 법률’ 제22조
                      제2항이 규정한 사항을 미리 명시하거나 고지해야 하며
                      이용고객은 언제든지 이 동의를 철회할 수 있습니다.
                    </li>
                    <li>
                      <span className="num">⑥</span> 이용고객은 언제든지
                      bzp출장관리가 가지고 있는 자신의 개인정보에 대해 열람 및
                      오류정정을 요구할 수 있으며 bzp출장관리는 이에 대해 지체
                      없이 필요한 조치를 취할 의무를 가집니다. 이용고객이 정정을
                      요구한 경우에는 bzp출장관리는 그 오류를 정정할 때까지 당해
                      개인정보를 이용하지 않습니다.
                    </li>
                    <li>
                      <span className="num">⑦</span> 개인정보보호를 위하여
                      이용고객의 개인정보를 취급하는 자를 최소한으로 제한하여야
                      하며 신용카드, 은행계좌 등을 포함한 이용자의 개인정보의
                      분실, 도난, 유출, 동의 없는 제3자 제공, 변조 등으로 인한
                      이용고객의 손해에 대하여 모든 책임을 집니다.
                    </li>
                    <li>
                      <span className="num">⑧</span> bzp출장관리 또는 그로부터
                      개인정보를 제공받은 제3자는 개인정보의 수집목적 또는
                      제공받은 목적을 달성한 때에는 당해 개인정보를 지체없이
                      파기합니다.
                    </li>
                    <li>
                      <span className="num">⑨</span>bzp출장관리는 개인정보 수집.
                      이용. 제공에 관한 동의 란을 미리 선택한 것으로 설정해두지
                      않습니다. 또한 개인정보의 수집. 이용. 제공에 관한 이용자의
                      동의 거절 시 제한되는 서비스를 구체적으로 명시하고
                      필수수집항목이 아닌 개인정보의 수집. 이용. 제공에 관한
                      이용고객의 동의 거절을 이유로 회원가입 등 서비스 제공을
                      제한하거나 거절하지 않습니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제18조 (bzp출장관리의 의무)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 법령과 해당 약관이
                      금지하거나 공서약속에 반하는 행위를 하지 않으며 이 약관이
                      정하는 바에 따라 지속적이고, 안정적으로 재화 및 용역을
                      제공하는데 최선을 다해야 합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객이 안전하게 인터넷
                      서비스를 이용할 수 있도록 이용고객의 개인정보(신용정보
                      포함)보호를 위한 보안 시스템을 갖추어야 합니다
                    </li>
                    <li>
                      <span className="num">③</span> 상품이나 용역에 대하여
                      ‘표시광고의 공정화에 관한 법률’ 제3조 소정의 부당표시
                      광고행위를 함으로써 이용고객이 손해를 입은 때에는 이를
                      배상할 책임을 집니다. 다만, 재화 등을 공급. 운영하고 있는
                      입점업체로 발생한 재화 등의 표기 및 광고 분쟁은 당사자들
                      간의 해결을 원칙으로 하며, bzp출장관리는 어떠한 책임도
                      지지 않습니다.
                    </li>
                    <li>
                      <span className="num">④</span> bzp출장관리는 이용자가
                      원하지 않는 영리목적의 광고성 전자우편을 발송하지
                      않습니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>제19조 (회원의 ID와 비밀번호에 대한 의무)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 제17조의 경우를 제외한 ID와
                      비밀번호에 관한 관리책임은 회원에게 있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 회원 자신의 ID 및
                      비밀번호를 제3자에게 이용하게 해서는 안됩니다.
                    </li>
                    <li>
                      <span className="num">③</span> 회원이 자신의 ID 및
                      비밀번호를 도난 당하거나 3자가 사용하고 있음을 인지한
                      경우에는 바로 bzp출장관리에 통보하고 안내에 따라야 합니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>제20조 (이용고객의 의무)</p>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> 이용고객은 다음 행위를
                        하여서는 안 됩니다.
                      </div>
                      <div className="box-indent">
                        1. 신청 또는 변경 시 허위 내용의 등록
                      </div>
                      <div className="box-indent">2. 타인의 정보 도용</div>
                      <div className="box-indent">
                        3. bzp출장관리에 게시된 정보의 변경
                      </div>
                      <div className="box-indent">
                        4. bzp출장관리가 정한 정보 이외의 정보(컴퓨터 프로그램
                        등)등의 송신 또는 게시
                      </div>
                      <div className="box-indent">
                        5. 기타 제3자의 저작권 등 지식재산권에 대한 침해
                      </div>
                      <div className="box-indent">
                        6. 기타 제3자의 명예를 손상시키거나 업무를 방해하는 행위
                      </div>
                      <div className="box-indent">
                        7. 외설 또는 폭력적인 메시지, 화상, 음성, 기타
                        공서양속에 반하는 정보를 bzp출장관리에 공개 또는
                        게시하는 행위
                      </div>
                    </li>
                  </ol>
                </li>
                <li>
                  <p>21조 (bzp출장관리와 입점업체 간의 관계)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 이용고객은 다음 행위를
                      하여서는 안 됩니다.
                    </li>
                    <li>
                      <span className="num">②</span> 입점업체가 독자적으로
                      제공하는 재화 등에 의하여 이용고객과 행하는 거래에서
                      발생한 분쟁은 당사자들 간의 해결을 원칙으로 하며
                      bzp출장관리는 어떠한 책임도 지지 않습니다. 이럴 경우
                      bzp출장관리는 판매하는 재화 등의 초기화면 또는 연결되는
                      시점의 팝업화면으로 입점업체 상품이라는 내용을 이용자가
                      알기 쉽도록 명확하게 표시합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>22조 (저작권의 귀속 및 이용제한)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> bzp출장관리가 작성한
                      저작물에 대한 저작권 및 기타 지적재산권은 bzp출장관리에
                      귀속합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객이 bzp출장관리를
                      이용함으로써 얻은 정보 중 bzp출장관리의 지적재산권에
                      귀속된 정보를 사전 승인없이 복제, 송신, 출판, 배포, 방송
                      기타 방법에 의하여 영리목적으로 이용하거나 제3자에게
                      이용하게 하여서는 안됩니다.
                    </li>
                    <li>
                      <span className="num">③</span> bzp출장관리는 약정에 따라
                      이용고객에게 귀속된 저작권을 사용하는 경우 당해
                      이용고객에게 통보하여야 합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>23조 (분쟁해결)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 이용고객에 제기하는 정당한
                      의견이나 불만을 반영하고 그 피해를 보상처리하기 위하여
                      피해 보상 처리 센터를 운영합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객으로부터 제출되는
                      불만사항 및 의견은 우선적으로 그 사항을 처리합니다. 다만,
                      신속한 처리가 곤란한 경우에는 이용고객에게 그 사유와
                      처리일정을 가능한 빠른 시간 안에 통보해드립니다.
                    </li>
                    <li>
                      <span className="num">③</span> 이용고객 간에 발생한
                      전자상거래 분쟁과 관련하여 이용고객의 피해구제신청이 있는
                      경우에는 공정거래위원회 또는 시. 도지사가 의뢰한
                      분쟁조정기관의 조정을 따를 수 있습니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>24조 (재판권 및 준거법)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 이용고객 간에 발생한
                      전자상거래 분쟁에 관한 소송은 제소 당시의 이용고객의
                      주소에 의하고, 주소가 없는 경우에는 기소를 관할하는
                      지방법원의 전속관할로 합니다. 다만, 제소 당시 이용고객의
                      주소 또는 거주지가 분명하지 않거나 외국 거주자의 경우
                      민사소송법의 관할법원으로 제기합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 이용고객 간에 제기된
                      전자상거래 소송에는 한국법을 적용합니다.
                    </li>
                  </ol>
                </li>

                <li>
                  <p>25조 (기타)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 해당 약관에 명시되지 아니한
                      사항 또는 계약에 해석에 관하여 다툼이 있는 경우 당사 또는
                      이용고객 간 합의하여 결정하되, 합의가 이루어지지 아니한
                      경우 전자거래기본법, 전자서명법 등 기타 관련법령 및
                      일반관례에 따릅니다.
                    </li>
                    <li>
                      <span className="num">②</span> 특수 재화 등에 정당한
                      사유가 있는 경우 표준약관의 내용과 달리 정할 수 있습니다.
                    </li>
                  </ol>
                </li>
              </ul>

              <div className="terms-footer">
                <p>부칙 (적용일자)</p>
                <div>이 약관은 2024년 6월 28일부터 시행됩니다.</div>
                <ul className="list-dot">
                  <li>- 이용약관 버전번호 : V1.1</li>
                  <li>- 이용약관 시행일자 : 2024. 6. 28</li>
                  <li>- 이용약관 최종변경일자 : 2024. 6. 28</li>
                </ul>
              </div>
            </div>
            {/* [E]terms-details */}
          </div>
        </DialogContent>
        <DialogActions className="dialog-footer">
          {/* [S]<BtnsGroup /> */}
          <Box className="btns-group">
            <Box className="inner">
              <Button variant="contained" size="large" className="btn-xlarge">
                {/* 240819 modify */}
                동의하기
              </Button>
            </Box>
          </Box>
          {/* [E]BtnsGroup */}
        </DialogActions>
      </Dialog>
      {/* [E]bizplay이용약관 */}
    </>
  );
};

export default MLG020100;
