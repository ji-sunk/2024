import {
  AppBar,
  Box,
  Card,
  Chip,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import PlaceIcon from "@mui/icons-material/Place";
import { Button, CardContent, List, ListItem } from "@mui/material";

import { Calendar, ChevronRight } from "@untitled-ui/icons-react";
import { Helmet as Head } from "react-helmet";
import ChipsGroup from "src/components/common/ChipsGroup";

import React, { useState } from "react";

import { Avatar, Tab, Tabs } from "@mui/material";
import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import { useEffect, useRef } from "react";
import NoData from "src/components/common/NoData";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  tabValue: number;
}

function BasicTabPanel(props: TabPanelProps) {
  const { children, tabValue, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={tabValue !== index}
      id={`basic-tabpanel-${index}`}
      aria-labelledby={`basic-tab-${index}`}
      {...other}
      className="tab-panel"
    >
      {tabValue === index && <div className="panel-inner">{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `basic-tab-${index}`,
    "aria-controls": `basic-tabpanel-${index}`,
  };
}

const selectOption = [
  { label: "label1", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

const MMA010000 = () => {
  const [selected, setSelected] = React.useState(false);
  const [tabValue, setTabValue] = React.useState(0);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };
  const tabHandleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // 상위 컴포넌트에서 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabs, setSubTabs] = useState([
    { label: "전체" },
    { label: "기차" },
    { label: "고속버스" },
    { label: "항공" },
  ]);

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>출장정보 상세</title>
      </Head>
      {/* [S]출장정보 상세 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">출장정보 상세</Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            <div className="ui-box">
              {/* [S]bztrip-list */}
              <div className="bztrip-list">
                <Card className="item">
                  <CardContent>
                    {/* [S]loop */}
                    <div className="item-top inner-sides">
                      <div className="left-area">
                        <ChipsGroup />
                      </div>
                      <div className="right-area"></div>
                    </div>
                    {/* [S]link-block */}
                    <div className="link-block">
                      <div className="title-area inner-sides">
                        <div className="txt">
                          도장재 품질점검 협력사 2차 방문
                        </div>
                        <Box className="right-area">
                          <ChevronRight className="bp-icon" />
                        </Box>
                      </div>
                      <List className="list-schedule">
                        <ListItem>
                          <Box className="item type-calendar">
                            <Calendar className="bp-icon small" />
                            <Box className="txt-period">
                              2024.04.08 ~ 2024.04.12
                            </Box>
                            <Box className="txt-term">4박5일</Box>
                          </Box>
                        </ListItem>
                        <ListItem>
                          <Box className="item">
                            <PlaceIcon className="bp-icon small" />
                            <div className="place-area">
                              <Box className="pin">양재본사</Box>
                              <Box className="pin">충남아산시현대로1077</Box>
                              <Box className="pin">강남대로 350</Box>
                              <Box className="pin">아산공장공장공장</Box>
                              <Box className="pin">아산공장공장2</Box>
                              <Box className="pin">아산공장23</Box>
                            </div>
                          </Box>
                        </ListItem>
                      </List>
                      <Box className="neutral-box">
                        1일차 일비 <b>40,000P</b>가 지급되었습니다.
                      </Box>
                    </div>
                    {/* [E]list-link-box */}
                    <Box className="btns-group">
                      <Box className="inner">
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium color-neutral-300"
                        >
                          목적지 주변 검색
                        </Button>
                      </Box>
                    </Box>

                    {/* [S] 경로 추가 수정 영역 kjs 241015 */}
                    <div className="tabs-box round-style">
                      <Box className="bp-tabs tabs-size-medium bp-tabs-top">
                        <Tabs
                          className="tab-list"
                          value={tabValue}
                          onChange={tabHandleChange}
                          TabIndicatorProps={{
                            sx: { backgroundColor: "#fff" },
                          }}
                          aria-label=""
                        >
                          {/* <Tab label="전체" {...a11yProps(0)} /> */}
                          <Tab label="항공" {...a11yProps(0)} />
                          <Tab label="기차" {...a11yProps(1)} />
                          <Tab label="고속버스" {...a11yProps(2)} />
                          <Tab label="지하철" {...a11yProps(3)} />
                          <Tab label="택시" {...a11yProps(4)} />
                        </Tabs>
                        <div className="ui-box">
                          <BasicTabPanel tabValue={tabValue} index={0}>
                            <div className="bztrip-list">
                              {/* 항공 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">1시간</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          항공 1시간
                                        </div>

                                        {/* <Box className="right">
                                  <Button
                                    size="small"
                                    className="btn-text-primary btn-go-back"
                                    startIcon={
                                      <ArrowLeft fontSize="small" className="bp-icon xsmall" />
                                    }
                                  >
                                    뒤로가기
                                  </Button>
                                </Box> */}
                                        {/* <div className="type-amount item-txt">
                                  <div className="number-area">
                                    295,000
                                    <span className="txt-currency">원</span>
                                  </div>
                                </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="항공"
                                        >
                                          <span className="bp-icon icon-flight"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">김포국제공항</div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">울산공항</Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>
                              {/* 기차 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">2시간 11분</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          보도 15분
                                        </div>
                                        <div className="txt-desc item-txt">
                                          환승 2회
                                        </div>
                                        <div className="txt-desc item-txt">
                                          312.8km
                                        </div>
                                        {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="기차"
                                        >
                                          <span className="bp-icon icon-train"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">서울역</div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">
                                          울산(통도사)역
                                        </Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>

                              {/* 고속버스 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">3시간 11분</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          보도 13분
                                        </div>
                                        <div className="txt-desc item-txt">
                                          환승 1회
                                        </div>
                                        <div className="txt-desc item-txt">
                                          312.8km
                                        </div>
                                        {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="고속버스"
                                        >
                                          <span className="bp-icon icon-bus"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">
                                          출발지명이 길어지면 하단으로 2줄처리
                                        </div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">
                                          도착지명이 길어지면 하단으로 2줄처리
                                        </Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          </BasicTabPanel>
                          <BasicTabPanel tabValue={tabValue} index={1}>
                            <div className="bztrip-list">
                              {/* 기차 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">2시간 11분</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          보도 15분
                                        </div>
                                        <div className="txt-desc item-txt">
                                          환승 2회
                                        </div>
                                        <div className="txt-desc item-txt">
                                          312.8km
                                        </div>
                                        {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="기차"
                                        >
                                          <span className="bp-icon icon-train"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">서울역</div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">
                                          울산(통도사)역
                                        </Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          </BasicTabPanel>
                          <BasicTabPanel tabValue={tabValue} index={2}>
                            <div className="bztrip-list">
                              {/* 고속버스 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">3시간 11분</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          보도 13분
                                        </div>
                                        <div className="txt-desc item-txt">
                                          환승 1회
                                        </div>
                                        <div className="txt-desc item-txt">
                                          312.8km
                                        </div>
                                        {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="고속버스"
                                        >
                                          <span className="bp-icon icon-bus"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">
                                          출발지명이 길어지면 하단으로 2줄처리
                                        </div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">
                                          도착지명이 길어지면 하단으로 2줄처리
                                        </Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          </BasicTabPanel>
                          <BasicTabPanel tabValue={tabValue} index={3}>
                            <div className="bztrip-list">
                              {/* 항공 */}
                              <Card className="item">
                                <CardContent>
                                  {/* [S]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <div className="inner-sides">
                                    <div className="title-area left-area">
                                      <div className="txt">3시간 11분</div>
                                      <div className="txt-detail">
                                        <div className="txt-desc item-txt">
                                          보도 13분
                                        </div>
                                        <div className="txt-desc item-txt">
                                          환승 1회
                                        </div>
                                        <div className="txt-desc item-txt">
                                          312.8km
                                        </div>
                                        {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                                      </div>
                                    </div>
                                    <div className="right-area">
                                      <IconButton>
                                        <ChevronRight className="bp-icon" />
                                      </IconButton>
                                    </div>
                                  </div>
                                  {/* [E]arrow Add 구조 맞춰 변경 20241015 kjs  */}
                                  <Box className="transportation-schedule">
                                    <Box className="trip-route-box">
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-error"
                                          aria-label="항공"
                                        >
                                          <span className="bp-icon icon-flight"></span>
                                        </Avatar>
                                      </div>
                                      <div className="item">
                                        <Avatar
                                          className="bp-avatar size-xsmall color-success"
                                          aria-label="거래처"
                                        >
                                          <PlaceIcon className="bp-icon xsmall" />
                                        </Avatar>
                                      </div>
                                    </Box>
                                  </Box>
                                  <div className="item-field">
                                    <dl className="flex-row-half">
                                      <dt className="left-area">
                                        <div className="txt">
                                          출발지명이 길어지면 하단으로 2줄처리
                                        </div>
                                      </dt>
                                      <dd className="right-area">
                                        <Box className="txt">
                                          도착지명이 길어지면 하단으로 2줄처리
                                        </Box>
                                      </dd>
                                    </dl>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          </BasicTabPanel>
                        </div>
                      </Box>
                    </div>
                    <Box className="btns-group two">
                      <Box className="inner">
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium color-neutral-300"
                        >
                          비플페이 가맹점 검색
                        </Button>
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium"
                        >
                          경로추천
                        </Button>
                      </Box>
                    </Box>

                    <div className="horizontal-scrolling">
                      <div className="list-chip-label type-medium">
                        <Chip
                          aria-selected="true"
                          label="기차"
                          size="medium"
                          variant="outlined"
                          className="bp-chip type-radius"
                          clickable
                        />
                        <Chip
                          label="고속/시외"
                          size="medium"
                          variant="outlined"
                          className="bp-chip type-radius"
                          clickable
                        />
                        <Chip
                          label="항공"
                          size="medium"
                          variant="outlined"
                          className="bp-chip type-radius"
                          clickable
                        />
                        <Chip
                          label="택시"
                          size="medium"
                          variant="outlined"
                          className="bp-chip type-radius"
                          clickable
                        />
                        <Chip
                          label="도보"
                          size="medium"
                          variant="outlined"
                          className="bp-chip type-radius"
                          clickable
                        />
                      </div>

                      <div className="ui-box course-area-line">
                        <div className="item-field">
                          {/* course-step */}
                          <ul className="course-step">
                            {/* item is-active */}
                            <li className="item is-active">
                              {/* <img src="/assets/images/icons/icon-start.svg"  alt="" />
                        <img src="/assets/images/icons/icon-locati.svg"  alt="" />
                        <img src="/assets/images/icons/icon-walk.svg"  alt="" />
                        <img src="/assets/images/icons/icon-corporate.svg"  alt="" />
                        <img src="/assets/images/icons/icon-train1.svg"  alt="" />
                        <img src="/assets/images/icons/icon-expBus.svg"  alt="" />
                        <img src="/assets/images/icons/icon-air.svg"  alt="" />
                        <img src="/assets/images/icons/icon-car1.svg"  alt="" />
                        <img src="/assets/images/icons/icon-pubBus.svg"  alt="" /> */}
                              <Box className="ico icon-start"></Box>
                              <div className="txt">출발</div>
                              <div className="course-desc">
                                <p>
                                  서울 중구 을지로 입구서울 중구 을지로 입구
                                </p>
                              </div>
                            </li>
                            <li className="item is-active">
                              <Box className="ico icon-walk"></Box>
                              <div className="txt">도보</div>
                              <div className="course-desc">
                                <strong className="color-primary-dark">
                                  고속버스 :1{" "}
                                </strong>
                                <p>
                                  서울 중구 을지로 입구서울 중구 을지로 입구서울
                                  중구 을지로 입구서울
                                </p>
                              </div>
                            </li>
                            <li className="item is-active">
                              <Box className="ico icon-expBus"></Box>
                              <div className="txt">시내버스</div>
                              <div className="course-desc">
                                <strong className="color-primary-dark"></strong>
                                <p>롯데백화점 승차</p>
                                <strong className="color-primary-dark">
                                  간선 : 143
                                </strong>
                                <p>고속터미널 하차</p>
                              </div>
                            </li>
                            <li className="item is-active">
                              <Box className="ico icon-walk"></Box>
                              <div className="txt">도보</div>
                              <div className="course-desc">
                                <p>서울 고속버스터미널 승차</p>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* [E] 경로 추가 수정 영역 kjs 241015 */}
                  </CardContent>
                </Card>

                <Card className="item">
                  <CardContent>
                    {/* [S]link-block */}
                    <div className="link-block">
                      <NoData />
                    </div>
                    {/* [E]list-link-box */}
                    <Box className="btns-group">
                      <Box className="inner">
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium"
                        >
                          목적지 숙박 검색
                        </Button>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>

                <Card className="item">
                  <CardContent>
                    {/* [S]link-block */}
                    <div className="link-block">
                      <NoData />
                    </div>
                    {/* [E]list-link-box */}
                    <Box className="btns-group">
                      <Box className="inner">
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium color-neutral-300"
                        >
                          교통수단 추천
                        </Button>
                        <Button
                          variant="contained"
                          size="medium"
                          className="btn-medium"
                        >
                          교통수단 선택
                        </Button>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>

                <Card className="item">
                  <CardContent>
                    <div className="item-top inner-sides">
                      <div className="left-area">
                        <div className="chips-group">
                          <Chip
                            label="결재완료"
                            size="small"
                            color="info"
                            className="bp-chip color-twotone color-info"
                          />
                        </div>
                      </div>
                      <div className="right-area">
                        <div className="item-prd">
                          <img
                            src="/assets/images/icons/icon-h-hotel.svg"
                            width={16}
                            height={16}
                            alt="숙박"
                          />
                          <div className="txt">신라스테이 울산</div>
                        </div>
                      </div>
                    </div>
                    <div className="item-field">
                      <div className="neutral-box info-prd">
                        <dl className="inner-sides">
                          <dt className="left-area">
                            <div className="txt">예약번호</div>
                          </dt>
                          <dd className="right-area">
                            <Box className="txt">2024042528345-H01</Box>
                          </dd>
                        </dl>
                        <dl className="inner-sides">
                          <dt className="left-area">
                            <div className="txt">이용기간</div>
                          </dt>
                          <dd className="right-area">
                            <Box className="txt">
                              2024.04.08 ~ 2024.04.12 (4박)
                            </Box>
                          </dd>
                        </dl>
                        <dl className="inner-sides">
                          <dt className="left-area">
                            <div className="txt">객실명</div>
                          </dt>
                          <dd className="right-area">
                            <Box className="txt">
                              스탠다드-디럭스 더블 무료 업그레이드
                            </Box>
                          </dd>
                        </dl>
                        <dl className="inner-sides">
                          <dt className="left-area">
                            <div className="txt">옵션</div>
                          </dt>
                          <dd className="right-area">
                            <Box className="txt">조식포함</Box>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              {/* [E]bztrip-list */}
            </div>
          </div>
        </DialogContent>
        {/* <DialogActions className="dialog-footer"></DialogActions> */}
      </Dialog>
      {/* [E]출장정보 상세 */}
    </>
  );
};

export default MMA010000;
