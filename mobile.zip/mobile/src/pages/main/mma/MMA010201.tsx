import { Box, Button, Chip, Paper } from "@mui/material";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";
import PlaceIcon from "@mui/icons-material/Place";

const selectOption = [
  { label: "일반출장 출장 출장", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

const MOC020100 = () => {
  return (
    <>
      <Head>
        <title>교통수단 | 상세경로</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper", bztrip-wrap */}
        <Paper className="ui-paper bztrip-wrap">
          {/* [S] */}
          <div className="light-box full-height">
            {/* ui-box course-area-line */}
            <div className="ui-box course-area-line">
                <div className="item-field">
                  {/* course-step */}
                  <ul className="course-step">
                    {/* item is-active */}
                    <li className="item is-active">

                                             {/* <img src="/assets/images/icons/icon-start.svg"  alt="" />
                        <img src="/assets/images/icons/icon-locati.svg"  alt="" />
                        <img src="/assets/images/icons/icon-walk.svg"  alt="" />
                        <img src="/assets/images/icons/icon-corporate.svg"  alt="" />
                        <img src="/assets/images/icons/icon-train1.svg"  alt="" />
                        <img src="/assets/images/icons/icon-expBus.svg"  alt="" />
                        <img src="/assets/images/icons/icon-air.svg"  alt="" />
                        <img src="/assets/images/icons/icon-car1.svg"  alt="" />
                        <img src="/assets/images/icons/icon-pubBus.svg"  alt="" /> */}
                      <Box className="ico icon-start">
                      </Box>
                      <div className="txt">출발</div>
                      <div className="course-desc">
                        <p>서울 중구 을지로 입구서울 중구 을지로 입구</p>
                      </div>
                    </li>
                    <li className="item is-active">
                      <Box className="ico icon-walk"></Box>
                      <div className="txt">도보</div>
                      <div className="course-desc">
                        <strong className="color-primary-dark">고속버스 :1 </strong>
                        <p>서울 중구 을지로 입구서울 중구 을지로 입구서울 중구 을지로 입구서울</p>
                      </div>
                    </li>
                    <li className="item is-active">
                      <Box className="ico icon-expBus">
                      </Box>
                      <div className="txt">시내버스</div>
                      <div className="course-desc">
                        <strong className="color-primary-dark"></strong>
                        <p>롯데백화점 승차</p>
                        <strong className="color-primary-dark">간선 : 143</strong>
                        <p>고속터미널 하차</p>
                      </div>
                    </li>
                    <li className="item is-active">
                      <Box className="ico icon-walk">
                      </Box>
                      <div className="txt">도보</div>
                      <div className="course-desc">
                        <p>서울 고속버스터미널 승차</p>
                      </div>
                    </li>
                    

                  </ul>
                </div>
              </div>
          </div>
          {/* [E] */}
        </Paper>
        {/* [E]ui-paper bztrip-wrap */}
        <Box className="btns-group">
          <Box className="inner">
            <Button variant="contained" size="large" className="btn-xlarge">
                취소
            </Button>
            <Button variant="contained" size="large" className="btn-xlarge">
              차량등록
            </Button>
          </Box>
        </Box>
      </LayoutSub>
    </>
  );
};

export default MOC020100;
