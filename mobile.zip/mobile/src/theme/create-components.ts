import {
  chipClasses,
  Components,
  createTheme,
  filledInputClasses,
  inputLabelClasses,
  outlinedInputClasses,
  paperClasses,
  tableCellClasses,
} from "@mui/material";
import { gridClasses } from "@mui/x-data-grid";
import type {} from "@mui/x-data-grid/themeAugmentation";

// Used only to create transitions
const muiTheme = createTheme();

// 새로운 버튼 사이즈를 정의하기 위해 ButtonClasses를 확장합니다.
declare module "@mui/material/Button" {
  interface ButtonClasses {
    sizeXlarge?: string; // 새로운 버튼 사이즈 추가
  }
}

export function createComponents(config): Components {
  const { palette } = config;

  return {
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundColor: "transparent",
          boxShadow: "none",
          borderRadius: "0",
          "&.MuiDrawer-paper": {
            backgroundColor: "#fff",
          },
          "&.MuiAlert-standardSuccess.MuiAlert-standard.alert-success": {
            color: "#fff",
          },
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: "#fff",
          boxShadow: "none",
          "&.sub-header": {
            boxShadow:
              "0px 4px 12px 0px rgba(0, 0, 0, 0.03), 4px -4px 12px 0px rgba(0, 0, 0, 0.03)",
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          verticalAlign: "top",
          fontSize: "1.3rem",
          lineHeight: "1.2",
          height: "20px",
          backgroundColor: "#B7BECD",
          color: "#fff",
        },
        outlined: {
          backgroundColor: "#fff",
          color: "#6C737F",
          height: "22px",
          [`&.color-neutral`]: {
            backgroundColor: "var(--color-neutral-50)",
          },
        },
        colorPrimary: {
          backgroundColor: "#002C5F",
          [`&.${chipClasses.outlined}`]: {
            borderColor: "var(--color-neutral-300)",
            height: "22px",
          },
        },
        colorSecondary: {
          backgroundColor: "#00AAD2",
        },
        colorError: {
          backgroundColor: "#F04438",
        },
        colorInfo: {
          backgroundColor: "#06AED4",
        },
        colorSuccess: {
          backgroundColor: "#15B79E",
        },
        colorWarning: {
          backgroundColor: "#F79009",
        },
        sizeSmall: {
          fontSize: "1.2rem",
          borderRadius: "0.4rem",
          fontWeight: "500",
        },
        sizeMedium: {
          fontSize: "1.2rem",
          borderRadius: "0.4rem",
          fontWeight: "500",
          height: "2.2rem",
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          padding: "0",
          fontSize: "1.2em",
          color: "#fff",
          backgroundColor: "#111927",
          borderRadius: "0,4rem",
        },
      },
    },
    MuiAvatar: {
      styleOverrides: {
        root: {
          fontSize: 14,
          fontWeight: 600,
          letterSpacing: 0,
          backgroundColor: "#F2F6FF",
          color: "#2970FF",
        },
      },
    },
    MuiTypography: {
      styleOverrides: {
        root: {
          fontSize: "1.4rem",
        },
        h1: {},
        button: {
          // fontSize: "1.3rem",
        },
      },
    },
    MuiBadge: {
      styleOverrides: {
        badge: {
          fontSize: "1rem",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: "8px",
          textTransform: "none",
          boxSizing: "border-box",
          boxShadow: "none",
        },
        sizeSmall: {
          padding: "3px 10px",
          fontSize: "1.2rem",
          lineHeight: "2.2rem",
          minWidth: "28px",
        }, //height:28px
        sizeMedium: {
          padding: "8px 16px",
          fontSize: "1.3rem",
          lineHeight: "2.4rem",
        }, //height:40px
        sizeLarge: {
          padding: "10px 4px",
          fontSize: "1.4rem",
          lineHeight: "2.8rem",
        }, //height:48px
        textSizeSmall: {
          fontSize: "1.2rem",
        },
        textSizeMedium: {},
        textSizeLarge: {},
        outlinedSizeSmall: {
          lineHeight: "2.04rem",
        },
        outlinedSizeMedium: { lineHeight: "2.24rem" },
        outlinedSizeLarge: { lineHeight: "2.44rem" },
      },
    },
    MuiButtonBase: {
      defaultProps: {
        // The props to change the default for.
        disableRipple: true, // No more ripple
      },
    },
    MuiIconButton: {
      styleOverrides: {
        sizeSmall: {
          fontSize: "1rem",
          padding: "3px",
        },
        sizeMedium: {
          fontSize: "1.3rem",
          padding: "4px",
        },
        sizeLarge: {
          fontSize: "1.5rem",
        },
      },
    },
    MuiSvgIcon: {
      styleOverrides: {
        fontSizeSmall: {
          fontSize: "2rem",
        },
        fontSizeMedium: {
          fontSize: "2.4rem",
        },
        fontSizeLarge: {
          fontSize: "2.8rem",
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          backgroundColor: "#fff",
          [`&.${paperClasses.elevation1}`]: {
            boxShadow:
              "0px 4px 12px 0px rgba(0, 0, 0, 0.03), 4px -4px 12px 0px rgba(0, 0, 0, 0.03)",
          },
          "&.card-noti": {
            borderRadius: 8,
            MuiCardContent: {
              Padding: "0",
            },
          },
        },
      },
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          padding: "0",
          "&:last-child": {
            paddingBottom: "0",
          },
        },
      },
    },
    MuiCardHeader: {
      defaultProps: {
        titleTypographyProps: {
          variant: "h2",
        },
        subheaderTypographyProps: {
          variant: "body2",
        },
      },
      styleOverrides: {
        root: {
          padding: "32px 24px 16px",
        },
      },
    },
    MuiCssBaseline: {
      styleOverrides: {
        "*": {
          boxSizing: "border-box",
        },
        html: {
          MozOsxFontSmoothing: "grayscale",
          WebkitFontSmoothing: "antialiased",
          display: "flex",
          flexDirection: "column",
          minHeight: "100%",
          width: "100%",
        },
        body: {
          display: "flex",
          flex: "1 1 auto",
          flexDirection: "column",
          minHeight: "100%",
          width: "100%",
        },
        "#root": {
          display: "flex",
          flex: "1 1 auto",
          flexDirection: "column",
          height: "100%",
          width: "100%",
        },
        "#nprogress": {
          pointerEvents: "none",
        },
        "#nprogress .bar": {
          backgroundColor: palette.primary.main,
          height: 3,
          left: 0,
          position: "fixed",
          top: 0,
          width: "100%",
          zIndex: 2000,
        },
      },
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          minHeight: "55px",
        },
        input: {
          "&::placeholder": {
            opacity: 1,
          },
          height: "100%",
          boxSizing: "border-box",
        },
        hiddenLabel: {
          paddingTop: "10px !important",
          paddingRight: "8px",
          paddingBottom: "10px !important",
        },
        sizeSmall: {
          minHeight: "40px",
          [`&.${inputLabelClasses.outlined}`]: {
            transform: "translate(12px, 16px) scale(1)",
          },
        },
      },
    },
    MuiInput: {
      styleOverrides: {
        input: {
          fontSize: "1.4rem",
          fontWeight: 500,
          lineHeight: "24px",
          "&::placeholder": {
            color: palette.text.secondary,
          },
        },
      },
    },
    MuiInputLabel: {
      styleOverrides: {
        root: {
          [`&.${inputLabelClasses.filled}`]: {
            transform: "translate(12px, 16px) scale(1)",
          },
          [`&.${inputLabelClasses.shrink}`]: {
            [`&.${inputLabelClasses.standard}`]: {
              transform: "translate(0, -1.5px) scale(0.80)",
            },
            [`&.${inputLabelClasses.filled}`]: {
              transform: "translate(12px, 6px) scale(0.80)",
            },
            [`&.${inputLabelClasses.outlined}`]: {
              transform: "translate(14px, -9px) scale(0.80)",
            },
          },
          "&.Mui-focused": {
            color: palette.text.secondary,
          },
        },
        sizeSmall: {
          [`&.${inputLabelClasses.filled}`]: {
            transform: "translate(12px, 9px) scale(1)",
          },
          [`&.${inputLabelClasses.shrink}`]: {
            [`&.${inputLabelClasses.filled}`]: {
              transform: "translate(12px, 4px) scale(0.80)",
            },
          },
        },
        shrink: {},
      },
    },
    MuiFilledInput: {
      styleOverrides: {
        root: {
          fontSize: "16px",
          paddingTop: "16px",
          paddingBottom: "0",
          paddingLeft: "8px",
          paddingRight: "8px",
          backgroundColor: "#fff",
          borderRadius: 8,
          borderStyle: "solid",
          borderWidth: 1,
          overflow: "hidden",
          borderColor: palette.neutral[200],
          transition: muiTheme.transitions.create([
            "border-color",
            "box-shadow",
          ]),
          "&:hover": {
            backgroundColor: palette.action.hover,
          },
          "&:before": {
            display: "none",
          },
          "&:after": {
            display: "none",
          },
          [`&.${filledInputClasses.disabled}`]: {
            backgroundColor: "transparent",
          },
          [`&.${filledInputClasses.focused}`]: {
            backgroundColor: "#fff",
            borderColor: "#00AAD2",
            boxShadow: `#00AAD2 0 0 0 0px`,
          },
          [`&.${filledInputClasses.error}`]: {
            borderColor: palette.error.main,
            boxShadow: `${palette.error.main} 0 0 0 0px`,
          },
        },
        input: {
          padding: "0px 4px 0 4px !important",
          fontSize: "1.6rem",
          fontWeight: 400,
          lineHeight: "2.4rem",
          "&:-webkit-autofill": {
            borderBottomRightRadius: "inherit",
            borderBottomLeftRadius: "inherit",
          },
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        root: {},
        inputRoot: {},
        popper: { fontSize: "1.4rem", marginTop: "1px !important" },
        option: {
          paddingRight: "12px !important",
          paddingLeft: "12px !important",
          borderRadius: "12px",
          fontSize: "1.6rem",
          lineHeight: 1.5,
          overflowWrap: "break-word",
          wordWrap: "break-word",
          whiteSpace: "normal",
          wordBreak: "break-all",
          '&[aria-selected="true"]': {},
          "&:hover": {},
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          boxSizing: "border-box",
        },
        select: {
          minHeight: "53px",
          paddingTop: "20px",
          paddingRight: "39px !important",
          paddingBottom: "8px",
          paddingLeft: "12px",
        },
      },
    },
    MuiPopover: {
      styleOverrides: {
        root: {},
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          fontSize: "1.6rem",
          lineHeight: "1.5",
          wordBreak: "break-all",
          whiteSpace: "normal",
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          "&:hover": {
            backgroundColor: palette.action.hover,
            [`& .${outlinedInputClasses.notchedOutline}`]: {
              borderColor: palette.neutral[200],
            },
          },
          [`&.${outlinedInputClasses.focused}`]: {
            backgroundColor: "transparent",
            [`& .${outlinedInputClasses.notchedOutline}`]: {
              borderColor: palette.primary.main,
              boxShadow: `${palette.primary.main} 0 0 0 0px`,
            },
          },
          [`&.${filledInputClasses.error}`]: {
            [`& .${outlinedInputClasses.notchedOutline}`]: {
              borderColor: palette.error.main,
              boxShadow: `${palette.error.main} 0 0 0 0px`,
            },
          },
        },
        input: {
          fontSize: 14,
          fontWeight: 500,
          lineHeight: "24px",
        },
        notchedOutline: {
          top: "0",
          borderWidth: 1,
          borderColor: palette.neutral[200],
          transition: muiTheme.transitions.create([
            "border-color",
            "box-shadow",
          ]),
          boxSizing: "border-box",
        },
      },
    },
    MuiFormLabel: {
      styleOverrides: {
        root: {
          fontSize: 16,
          fontWeight: 400,
          [`&.${inputLabelClasses.filled}`]: {
            transform: "translate(12px, 16px) scale(1)",
          },
          [`&.${inputLabelClasses.shrink}`]: {
            [`&.${inputLabelClasses.standard}`]: {
              transform: "translate(0, -1.5px) scale(0.80)",
            },
            [`&.${inputLabelClasses.filled}`]: {
              transform: "translate(12px, 6px) scale(0.80)",
            },
            [`&.${inputLabelClasses.outlined}`]: {
              transform: "translate(14px, -9px) scale(0.80)",
            },
          },
        },
      },
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          fontSize: "1.2rem",
          lineHeight: "2rem",
          fontWeight: "normal",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          fontSize: 14,
          fontWeight: 500,
          lineHeight: 1.71,
          minWidth: "auto",
          paddingLeft: 0,
          paddingRight: 0,
          textTransform: "none",
          "& + &": {
            marginLeft: 24,
          },
        },
      },
    },
    MuiTable: {
      styleOverrides: {
        root: {
          borderCollapse: "collapse",
          tableLayout: "fixed",
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          padding: "0px 8px",
          borderBottomColor: palette.divider,
          fontSize: "1.3rem",
          lineHeight: "1.2",
          boxSizing: "border-box",
        },
        sizeSmall: {
          height: "38px",
        },
        sizeMedium: {
          height: "44px",
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          borderBottom: "none",
          [`& .${tableCellClasses.root}`]: {
            borderBottom: "none",
            backgroundColor: palette.neutral[50],
            color: palette.neutral[700],
            fontSize: 12,
            fontWeight: 600,
            textTransform: "uppercase",
          },
          [`& .${tableCellClasses.paddingCheckbox}`]: {
            paddingTop: 4,
            paddingBottom: 4,
          },
        },
      },
    },
    MuiTextField: {
      defaultProps: {
        variant: "filled",
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          [`& .${gridClasses.row}.closed_status`]: {
            backgroundColor: "rgba(248, 249, 250, 1)",
          },
          [`& .${gridClasses.row}.highlighted-purple`]: {
            backgroundColor: "rgba(242, 246, 255, 1)",
          },
          "&.densityCompact": {
            MuiDataGrid: {
              virtualScrollerRenderZone: {
                minHeight: 38,
                maxHeight: "initial",
              },
            },
          },
          "&.densityStandard": {
            MuiDataGrid: {
              virtualScrollerRenderZone: {
                minHeight: 44,
                maxHeight: "initial",
              },
            },
          },
        },
        columnHeaders: {
          backgroundColor: "rgba(248, 249, 250, 1)",
          borderBottom: "none !important",
        },
        columnHeader: {
          backgroundColor: "rgba(248, 249, 250, 1)",
          ":focus-within": {
            outline: "none",
          },
        },
        row: {},
        cell: {
          paddingRight: "8px",
          paddingLeft: "8px",
          ":focus-within": {
            outline: "none",
          },
        },
        iconSeparator: { color: "rgba(0, 0, 0, 0.12)" },
        //pinnedColumns: { minWidth: "initial", maxWidth: "initial" },
        pinnedColumnHeaders: {
          backgroundColor: "rgba(248, 249, 250, 1)",
        },
        withBorderColor: {
          borderBottom: "1px solid rgba(0, 0, 0, 0.12)",
        },
      },
    },
    MuiSnackbar: {
      styleOverrides: {
        root: {
          //zIndex: 99999,
        },
      },
    },
    MuiRadio: {
      styleOverrides: {
        root: {
          // color: "#00AAD2",
          color: palette.secondary.main,
          "&.Mui-checked": {
            color: palette.secondary.main,
          },
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        root: {
          width: "40px",
          height: "24px",
          padding: "8px 8px 8px 11px",
          boxSizing: "content-box",
        },
        input: { left: "0", right: 0, width: "40px" },
        track: {
          borderRadius: "12px",
          backgroundColor: "#CFD3DD",
          opacity: "1",
        },
        thumb: {
          width: "16px",
          height: "16px",
          margin: "12px",
          transform: "translateX(2px)",
          boxShadow: "0px 1px 2px rgba(0, 0, 0, 0.08)",
        },
        switchBase: {
          padding: 0,
          "&.Mui-checked": {
            transform: "translateX(18px)",
            color: "#fff",
            "+.MuiSwitch-track": {
              opacity: "1",
              backgroundColor: "#00AAD2",
            },
            "&.Mui-disabled": {
              color: "#fff",
              opacity: "0.75",
            },
          },
          "&.Mui-disabled": {
            "+.MuiSwitch-track": { opacity: "0.75" },
          },
        },
      },
    },
    MuiListItemSecondaryAction: {
      styleOverrides: {
        root: {
          right: "4px",
        },
      },
    },
    MuiList: {
      styleOverrides: {
        root: {
          padding: "0",
        },
      },
    },
    MuiListItem: {
      styleOverrides: {
        root: {
          padding: "0",
        },
      },
    },
  };
}
