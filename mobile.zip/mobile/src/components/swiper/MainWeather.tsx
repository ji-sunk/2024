import { Box } from "@mui/material";
import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Navigation, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

// let slideInx = 0;
const MainWeather = () => {
  SwiperCore.use([Navigation, Scrollbar]);
  return (
    <>
      <div className="weather-wrap">
        <div className="swiper-container">
          <Swiper
            // autoplay={{
            //   delay: 2500,
            //   disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
            // }}
            className=""
            loop={false} // 슬라이드 루프
            centeredSlides={true}
            // spaceBetween={12} // 슬라이스 사이 간격
            slidesPerView={1} // 보여질 슬라이스 수
            navigation={true} // prev, next button
            grabCursor={true}
          >
            {/* [S] loop 지역 추가로 인한 구조 변경 241010 kjs */}
            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <div className="inner-sides gap">
                  <div className="left-area">
                    <span className="date">2024.04.08</span>
                    <span className="days">월요일</span>
                  </div>
                  <div className="right-area">
                    <span className="location">영등포구 여의도동</span>
                  </div>
                </div>
                <div className="current-temp inner-sides">
                  <img src="/assets/images/weather-sun.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">24℃ 맑음</div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      1.5 m/s
                      <img
                        src="/assets/images/weather-raining-small.svg"
                        alt=""
                      />
                      5%
                    </div>
                  </div>
                </div>
              </Box>
            </SwiperSlide>
            {/* [E] loop 지역 추가로 인한 구조 변경 241010 kjs */}

            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <div className="inner-sides gap">
                  <div className="left-area">
                    <span className="date">2024.04.09</span>
                    <span className="days">화요일</span>
                  </div>
                  <div className="right-area">
                    <span className="location">영등포구 여의도동</span>
                  </div>
                </div>
                <div className="current-temp inner-sides">
                  <img src="/assets/images/weather-raining.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">14℃ 비</div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      3.5 m/s
                      <img
                        src="/assets/images/weather-raining-small.svg"
                        alt=""
                      />
                      95%
                    </div>
                  </div>
                </div>
              </Box>
            </SwiperSlide>

            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <div className="inner-sides gap">
                  <div className="left-area">
                    <span className="date">2024.04.10</span>
                    <span className="days">수요일</span>
                  </div>
                  <div className="right-area">
                    <span className="location">영등포구 여의도동</span>
                  </div>
                </div>
                <div className="current-temp inner-sides">
                  <img src="/assets/images/weather-sun.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">28℃ 맑음</div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      2 m/s
                      <img
                        src="/assets/images/weather-raining-small.svg"
                        alt=""
                      />
                      1%
                    </div>
                  </div>
                </div>
              </Box>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  );
};

export default MainWeather;
