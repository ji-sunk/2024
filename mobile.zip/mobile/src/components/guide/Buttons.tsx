import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";
import AddOutlinedIcon from "@mui/icons-material/AddOutlined";
import AltRouteOutlinedIcon from "@mui/icons-material/AltRouteOutlined";
import AnnouncementOutlinedIcon from "@mui/icons-material/AnnouncementOutlined";
import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";
import ArrowBackOutlinedIcon from "@mui/icons-material/ArrowBackOutlined";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";
import AttachFileOutlinedIcon from "@mui/icons-material/AttachFileOutlined";
import BookmarkBorderOutlinedIcon from "@mui/icons-material/BookmarkBorderOutlined";
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import CreateNewFolderOutlinedIcon from "@mui/icons-material/CreateNewFolderOutlined";
import CreateOutlinedIcon from "@mui/icons-material/CreateOutlined";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import DriveFileRenameOutlineOutlinedIcon from "@mui/icons-material/DriveFileRenameOutlineOutlined";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import FileUploadOutlinedIcon from "@mui/icons-material/FileUploadOutlined";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import GroupAddOutlinedIcon from "@mui/icons-material/GroupAddOutlined";
import HorizontalRuleOutlinedIcon from "@mui/icons-material/HorizontalRuleOutlined";
import HowToRegOutlinedIcon from "@mui/icons-material/HowToRegOutlined";
import ImageOutlinedIcon from "@mui/icons-material/ImageOutlined";
import InputOutlinedIcon from "@mui/icons-material/InputOutlined";
import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import KeyboardArrowUpOutlinedIcon from "@mui/icons-material/KeyboardArrowUpOutlined";
import LinkOutlinedIcon from "@mui/icons-material/LinkOutlined";
import ManageSearchOutlinedIcon from "@mui/icons-material/ManageSearchOutlined";
import NoteOutlinedIcon from "@mui/icons-material/NoteOutlined";
import OpenInFullOutlinedIcon from "@mui/icons-material/OpenInFullOutlined";
import PersonSearchOutlinedIcon from "@mui/icons-material/PersonSearchOutlined";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";
import RateReviewOutlinedIcon from "@mui/icons-material/RateReviewOutlined";
import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";
import RemoveCircleOutlineOutlinedIcon from "@mui/icons-material/RemoveCircleOutlineOutlined";
import RemoveOutlinedIcon from "@mui/icons-material/RemoveOutlined";
import RestartAltOutlinedIcon from "@mui/icons-material/RestartAltOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import SyncOutlinedIcon from "@mui/icons-material/SyncOutlined";
import TaskOutlinedIcon from "@mui/icons-material/TaskOutlined";
import TextSnippetOutlinedIcon from "@mui/icons-material/TextSnippetOutlined";
import TuneOutlinedIcon from "@mui/icons-material/TuneOutlined";
import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";
import {
  Box,
  Button,
  ClickAwayListener,
  Grow,
  IconButton,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  ToggleButton,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import React, { useEffect, useRef, useState } from "react";

const Buttons = (props) => {
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState(false);
  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const [modifyOpen, setModifyOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);
  const modifyAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleModifyOpen = () => {
    setModifyOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  const handleModifyClose = (event: Event | React.SyntheticEvent) => {
    if (
      modifyAnchorRef.current &&
      modifyAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setModifyOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
      setModifyOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
      setModifyOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);

  // return focus to the button when we transitioned from !open -> open
  const prevModifyOpen = useRef(modifyOpen);
  useEffect(() => {
    if (prevModifyOpen.current === true && modifyOpen === false) {
      modifyAnchorRef.current!.focus();
    }
    prevModifyOpen.current = modifyOpen;
  }, [modifyOpen]);

  return (
    <>
      <h3 className="heading3">3-1. [공통]기본 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={6}>
          <Button size="small">Text Small</Button>
          <Button size="medium">Text Medium</Button>
          <Button size="large">Text Large</Button>
          <Button size="large" className="btn-xlarge">
            Text xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="outlined" size="small">
            Outlined Small
          </Button>
          <Button variant="outlined" size="medium">
            Outlined Medium
          </Button>
          <Button variant="outlined" size="large">
            Outlined Large
          </Button>
          <Button variant="outlined" size="large" className="btn-xlarge">
            Outlined xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="contained" size="small">
            Contained Small
          </Button>
          <Button variant="contained" size="medium">
            Contained Medium
          </Button>
          <Button variant="contained" size="large">
            Contained Large
          </Button>
          <Button variant="contained" size="large" className="btn-xlarge">
            Contained xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="outlined" disabled>
            Disabled
          </Button>
          <Button variant="outlined" href="#none">
            Link
          </Button>
        </Grid>
        <Grid xs={12}>
          <Button variant="contained" size="medium" fullWidth>
            100%넓이 버튼
          </Button>
        </Grid>
        <Grid xs={12}>
          <Button size="medium" color="primary">
            등록
          </Button>
          <Button size="medium" color="primary">
            수정
          </Button>
          <Button size="medium" color="primary">
            임시저장
          </Button>
          <Button size="medium" className="btn-text-primary">
            취소
          </Button>
          <Button size="medium" className="btn-text-secondary">
            취소
          </Button>
          <Button size="medium" color="error">
            초기화/삭제
          </Button>
          <Button variant="contained" size="medium">
            저장/확인/완료/선택완료/적용/결재요청
          </Button>
          <Button variant="outlined" size="medium">
            설정/상세설정
          </Button>
        </Grid>
      </Grid>
      <h3 className="heading3">3-2. [공통]버튼+아이콘 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ArrowBackOutlinedIcon fontSize="small" />}
          >
            뒤로가기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<FileDownloadOutlinedIcon fontSize="small" />}
          >
            저장/다운로드/양식 다운로드/양식 다운로드(신규)/양식 다운로드(기존
            자료 포함)
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<BookmarkBorderOutlinedIcon fontSize="small" />}
          >
            보관
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<PrintOutlinedIcon fontSize="small" />}
          >
            인쇄
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<CreateOutlinedIcon fontSize="small" />}
          >
            결의서 작성/수정/양식수정/그룹관리
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<FilterAltOutlinedIcon fontSize="small" />}
          >
            기본 필터
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<SettingsOutlinedIcon fontSize="small" />}
          >
            상세 필터
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<NoteOutlinedIcon fontSize="small" />}
          >
            메모
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<TuneOutlinedIcon fontSize="small" />}
          >
            보기설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<RemoveCircleOutlineOutlinedIcon fontSize="small" />}
          >
            제외/해제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<FileUploadOutlinedIcon fontSize="small" />}
          >
            업로드
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ImageOutlinedIcon fontSize="small" />}
          >
            이미지 첨부
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ShareOutlinedIcon fontSize="small" />}
          >
            회람
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<GroupAddOutlinedIcon fontSize="small" />}
          >
            임시담당자 지정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<BusinessOutlinedIcon fontSize="small" />}
          >
            회사정보
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<PersonSearchOutlinedIcon fontSize="small" />}
          >
            직원조회
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            추가/행추가
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<RemoveOutlinedIcon fontSize="small" />}
          >
            삭제/행제거
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<DeleteOutlinedIcon fontSize="small" />}
          >
            삭제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<AccessTimeOutlinedIcon fontSize="small" />}
          >
            마감/해제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ApprovalOutlinedIcon fontSize="small" />}
          >
            결재/접수결재
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<OpenInFullOutlinedIcon fontSize="small" />}
          >
            증빙내역 펼치기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<CancelOutlinedIcon fontSize="small" />}
          >
            상신취소/최종결재취소
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<DriveFileRenameOutlineOutlinedIcon fontSize="small" />}
          >
            재기안
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ManageSearchOutlinedIcon fontSize="small" />}
          >
            거래처 불러오기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<RestartAltOutlinedIcon fontSize="small" />}
          >
            초기화
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<InputOutlinedIcon fontSize="small" />}
          >
            일괄입력
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<AltRouteOutlinedIcon fontSize="small" />}
          >
            분할
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<WifiProtectedSetupOutlinedIcon fontSize="small" />}
          >
            국세청 가져오기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<CreateNewFolderOutlinedIcon fontSize="small" />}
          >
            카드그룹 생성
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<AnnouncementOutlinedIcon fontSize="small" />}
          >
            결재의견
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<InventoryOutlinedIcon fontSize="small" />}
          >
            결재정보
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<SyncOutlinedIcon fontSize="small" />}
          >
            결재선 변경
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<TaskOutlinedIcon fontSize="small" />}
          >
            양식선택
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<RateReviewOutlinedIcon fontSize="small" />}
          >
            결재란 설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<HowToRegOutlinedIcon fontSize="small" />}
          >
            양식별 결재선 설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<ContentCopyOutlinedIcon fontSize="small" />}
          >
            양식복사
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<RefreshOutlinedIcon fontSize="small" />}
          >
            최신정보 불러오기
          </Button>
          <Button
            size="small"
            color="primary"
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            대상 추가
          </Button>
          <Button
            size="medium"
            color="primary"
            className="btn-view"
            endIcon={<ArrowForwardIosRoundedIcon className="xsmall" />}
          >
            전체 보기
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<DashboardCustomizeOutlinedIcon fontSize="small" />}
          >
            위젯설정
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<RefreshOutlinedIcon fontSize="small" />}
          >
            새로고침
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            추가
          </Button>
          <Button variant="contained" size="small">
            추가(서브)
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            등록
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<CreateOutlinedIcon fontSize="small" />}
          >
            작성
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<CreateOutlinedIcon fontSize="small" />}
          >
            수정
          </Button>
          <Button variant="outlined" size="small">
            수정(서브)
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<SettingsOutlinedIcon fontSize="small" />}
          >
            설정
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<SettingsOutlinedIcon fontSize="small" />}
          >
            상세설정
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            용도/대상/예산
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-file"
            startIcon={
              <AttachFileOutlinedIcon fontSize="small" className="icon-file" />
            }
          >
            파일
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<AddOutlinedIcon fontSize="small" />}
          >
            그룹추가
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-file"
            startIcon={
              <AttachFileOutlinedIcon fontSize="small" className="icon-file" />
            }
          >
            파일
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<TextSnippetOutlinedIcon fontSize="small" />}
          >
            원안문서
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-basic"
            startIcon={<FileDownloadOutlinedIcon fontSize="small" />}
          >
            다운
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-basic"
            startIcon={<LinkOutlinedIcon fontSize="small" />}
          >
            연결
          </Button>
        </Grid>
      </Grid>
      <h3 className="heading3">3-3. [공통]아이콘 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <IconButton
            className="btn-icon-only btn-circle btn-bg-fill-reverse"
            size="small"
            color="primary"
            aria-label="추가"
          >
            <AddOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only btn-circle btn-bg-fill-reverse"
            size="small"
            color="error"
            aria-label="제거"
          >
            <HorizontalRuleOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="뒤로가기"
          >
            <ArrowBackOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="저장/다운로드"
          >
            <FileDownloadOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="보관">
            <BookmarkBorderOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="인쇄">
            <PrintOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결의서 작성/수정/양식수정"
          >
            <CreateOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="필터">
            <FilterAltOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="상세 필터"
          >
            <SettingsOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="메모">
            <NoteOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="보기설정"
          >
            <TuneOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="제외/해제"
          >
            <RemoveCircleOutlineOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="업로드"
          >
            <FileUploadOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="이미지 첨부"
          >
            <ImageOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="회람">
            <ShareOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="임시담당자 지정"
          >
            <GroupAddOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="회사정보"
          >
            <BusinessOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="직원조회"
          >
            <PersonSearchOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="추가/행추가"
          >
            <AddOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="삭제/행제거"
          >
            <RemoveOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="삭제">
            <DeleteOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="마감/해제"
          >
            <AccessTimeOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결재/접수결재"
          >
            <ApprovalOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="증빙내역 펼치기"
          >
            <OpenInFullOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="상신취소/최종결재취소"
          >
            <CancelOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="재기안"
          >
            <DriveFileRenameOutlineOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="거래처 불러오기"
          >
            <ManageSearchOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="초기화"
          >
            <RestartAltOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="일괄입력"
          >
            <InputOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="분할">
            <AltRouteOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="국세청 가져오기"
          >
            <WifiProtectedSetupOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="카드그룹 생성"
          >
            <CreateNewFolderOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결재의견"
          >
            <AnnouncementOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결재정보"
          >
            <InventoryOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결재선 변경"
          >
            <SyncOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="양식선택"
          >
            <TaskOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="결재란 설정"
          >
            <RateReviewOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="양식별 결재선 설정"
          >
            <HowToRegOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="양식복사"
          >
            <ContentCopyOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="최신정보 불러오기"
          >
            <RefreshOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="파일">
            <AttachFileOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="medium"
            aria-label="아래로"
          >
            <KeyboardArrowDownRoundedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="위로">
            <KeyboardArrowUpOutlinedIcon fontSize="small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="medium" aria-label="연결">
            <LinkOutlinedIcon fontSize="small" />
          </IconButton>
        </Grid>
      </Grid>
      <h3 className="heading3">3-4. [공통]Toggle 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <ToggleButton
            value="check"
            selected={selected}
            onChange={() => {
              setSelected(!selected);
            }}
            className="btn-icon-toggle icon-bookmark"
          >
            <StarRateRoundedIcon fontSize="medium" />
          </ToggleButton>
        </Grid>
      </Grid>
      <h3 className="heading3">3-5. [공통]Dropdown 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Box className="btn-dropdown">
            <Button
              variant="outlined"
              size="medium"
              id="modify-button"
              onClick={handleModifyOpen}
              ref={modifyAnchorRef}
              aria-controls={modifyOpen ? "modify-menu" : undefined}
              aria-expanded={modifyOpen ? "true" : undefined}
              aria-haspopup="true"
              startIcon={<CreateOutlinedIcon fontSize="small" />}
              endIcon={<KeyboardArrowDownRoundedIcon fontSize="small" />}
            >
              수정
            </Button>
            <Popper
              open={modifyOpen}
              anchorEl={modifyAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleModifyClose}>
                      <MenuList
                        autoFocusItem={modifyOpen}
                        id="modify-menu"
                        aria-labelledby="modify-button"
                        onKeyDown={handleListKeyDown}
                      >
                        <MenuItem onClick={handleModifyClose}>
                          수정하기
                        </MenuItem>
                        <MenuItem onClick={handleModifyClose}>
                          분할하기
                        </MenuItem>
                        <MenuItem onClick={handleModifyClose}>
                          세액수정
                        </MenuItem>
                      </MenuList>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
          <Box className="btn-dropdown">
            <Button
              variant="contained"
              size="medium"
              id="write-button"
              onClick={handleWriteOpen}
              ref={writeAnchorRef}
              aria-controls={writeOpen ? "write-menu" : undefined}
              aria-expanded={writeOpen ? "true" : undefined}
              aria-haspopup="true"
              startIcon={<CreateOutlinedIcon fontSize="small" />}
              endIcon={<KeyboardArrowDownRoundedIcon fontSize="small" />}
            >
              작성
            </Button>
            <Popper
              open={writeOpen}
              anchorEl={writeAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleWriteClose}>
                      <MenuList
                        autoFocusItem={writeOpen}
                        id="write-menu"
                        aria-labelledby="write-button"
                        onKeyDown={handleListKeyDown}
                      >
                        <MenuItem onClick={handleWriteClose}>단건등록</MenuItem>
                        <MenuItem onClick={handleWriteClose}>일괄등록</MenuItem>
                      </MenuList>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default Buttons;
