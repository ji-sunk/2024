import { KeyboardReturn } from "@mui/icons-material";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";
import AddOutlinedIcon from "@mui/icons-material/AddOutlined";
import AltRouteOutlinedIcon from "@mui/icons-material/AltRouteOutlined";
import AnnouncementOutlinedIcon from "@mui/icons-material/AnnouncementOutlined";
import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";
import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";
import ArrowBackOutlinedIcon from "@mui/icons-material/ArrowBackOutlined";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";
import ArrowForwardOutlinedIcon from "@mui/icons-material/ArrowForwardOutlined";
import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";
import AttachFileOutlinedIcon from "@mui/icons-material/AttachFileOutlined";
import BookmarkBorderOutlinedIcon from "@mui/icons-material/BookmarkBorderOutlined";
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import CachedIcon from "@mui/icons-material/Cached";
import CampaignIcon from "@mui/icons-material/Campaign";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import CheckRounded from "@mui/icons-material/CheckRounded";
import CloseIcon from "@mui/icons-material/Close";
import ContactEmergencyOutlinedIcon from "@mui/icons-material/ContactEmergencyOutlined";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import CreateNewFolderOutlinedIcon from "@mui/icons-material/CreateNewFolderOutlined";
import CreateOutlinedIcon from "@mui/icons-material/CreateOutlined";
import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";
import DriveFileRenameOutlineOutlinedIcon from "@mui/icons-material/DriveFileRenameOutlineOutlined";
import EditNoteOutlinedIcon from "@mui/icons-material/EditNoteOutlined";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import FileUploadOutlinedIcon from "@mui/icons-material/FileUploadOutlined";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import GroupAddOutlinedIcon from "@mui/icons-material/GroupAddOutlined";
import HowToRegOutlinedIcon from "@mui/icons-material/HowToRegOutlined";
import ImageOutlinedIcon from "@mui/icons-material/ImageOutlined";
import InputOutlinedIcon from "@mui/icons-material/InputOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import KeyboardArrowUpOutlinedIcon from "@mui/icons-material/KeyboardArrowUpOutlined";
import LinkOutlinedIcon from "@mui/icons-material/LinkOutlined";
import ManageSearchOutlinedIcon from "@mui/icons-material/ManageSearchOutlined";
import MoreHorizOutlinedIcon from "@mui/icons-material/MoreHorizOutlined";
import MoreVertOutlinedIcon from "@mui/icons-material/MoreVertOutlined";
import NoteOutlinedIcon from "@mui/icons-material/NoteOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import OpenInFullOutlinedIcon from "@mui/icons-material/OpenInFullOutlined";
import PauseCircleOutlinedIcon from "@mui/icons-material/PauseCircleOutlined";
import PauseRoundedIcon from "@mui/icons-material/PauseRounded";
import PersonIcon from "@mui/icons-material/Person";
import PersonSearchOutlinedIcon from "@mui/icons-material/PersonSearchOutlined";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";
import RateReviewOutlinedIcon from "@mui/icons-material/RateReviewOutlined";
import ReceiptIcon from "@mui/icons-material/Receipt";
import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";
import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";
import RemoveCircleOutlineOutlinedIcon from "@mui/icons-material/RemoveCircleOutlineOutlined";
import RemoveOutlinedIcon from "@mui/icons-material/RemoveOutlined";
import ReorderRoundedIcon from "@mui/icons-material/ReorderRounded";
import RestartAltOutlinedIcon from "@mui/icons-material/RestartAltOutlined";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";
import SyncOutlinedIcon from "@mui/icons-material/SyncOutlined";
import SyncRoundedIcon from "@mui/icons-material/SyncRounded";
import TaskIcon from "@mui/icons-material/Task";
import TaskOutlinedIcon from "@mui/icons-material/TaskOutlined";
import TuneOutlinedIcon from "@mui/icons-material/TuneOutlined";
import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import { ReactNode } from "react";
import styles from "./Guide.module.css";

interface IconsProps {
  children?: ReactNode;
  name?: string;
  txt?: string;
  impoTxt?: string;
}

const iconList = [
  {
    id: 1,
    name: "SearchOutlinedIcon",
    txt: "검색",
    impoTxt:
      'import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";',
  },
  {
    id: 2,
    name: "ArrowBackOutlinedIcon",
    txt: "뒤로가기",
    impoTxt:
      'import ArrowBackOutlinedIcon from "@mui/icons-material/ArrowBackOutlined";',
  },
  {
    id: 54,
    name: "ArrowForwardOutlinedIcon",
    txt: "바로가기",
    impoTxt:
      'import ArrowForwardOutlinedIcon from "@mui/icons-material/ArrowForwardOutlined";',
  },
  {
    id: 3,
    name: "CreditCardRoundedIcon",
    txt: "법인카드",
    impoTxt:
      'import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";',
  },
  {
    id: 4,
    name: "ContactEmergencyOutlinedIcon",
    txt: "개인카드",
    impoTxt:
      'import ContactEmergencyOutlinedIcon from "@mui/icons-material/ContactEmergencyOutlined";',
  },
  {
    id: 5,
    name: "ReceiptLongOutlinedIcon",
    txt: "기타증빙",
    impoTxt:
      'import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";',
  },
  {
    id: 6,
    name: "MoreHorizOutlinedIcon",
    txt: "대기/더보기 아이콘 버튼",
    impoTxt:
      'import MoreHorizOutlinedIcon from "@mui/icons-material/MoreHorizOutlined";',
  },
  {
    id: 7,
    name: "PriorityHighRoundedIcon",
    txt: "반송",
    impoTxt:
      'import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";',
  },
  {
    id: 8,
    name: "SyncRoundedIcon",
    txt: "진행",
    impoTxt: 'import SyncRoundedIcon from "@mui/icons-material/SyncRounded";',
  },
  {
    id: 9,
    name: "CheckRounded",
    txt: "완료",
    impoTxt: 'import CheckRounded from "@mui/icons-material/CheckRounded";',
  },
  {
    id: 10,
    name: "PauseRoundedIcon",
    txt: "보류",
    impoTxt: 'import PauseRoundedIcon from "@mui/icons-material/PauseRounded";',
  },
  {
    id: 11,
    name: "ArrowForwardIosRoundedIcon",
    txt: "바로가기 아이콘 버튼",
    impoTxt:
      'import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";',
  },
  {
    id: 12,
    name: "PauseCircleOutlinedIcon",
    txt: "일시 정지 아이콘 버튼",
    impoTxt:
      'import PauseCircleOutlinedIcon from "@mui/icons-material/PauseCircleOutlined";',
  },
  {
    id: 13,
    name: "PersonIcon",
    txt: "사람",
    impoTxt: 'import PersonIcon from "@mui/icons-material/Person";',
  },
  {
    id: 14,
    name: "EditNoteOutlinedIcon",
    txt: "글쓰기/수정",
    impoTxt:
      'import EditNoteOutlinedIcon from "@mui/icons-material/EditNoteOutlined";',
  },
  {
    id: 15,
    name: "RefreshOutlinedIcon",
    txt: "새로고침",
    impoTxt:
      'import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";',
  },
  {
    id: 16,
    name: "MoreVertOutlinedIcon",
    txt: "더보기/레이어 열기",
    impoTxt:
      'import MoreVertOutlinedIcon from "@mui/icons-material/MoreVertOutlined";',
  },
  {
    id: 17,
    name: "FileDownloadOutlinedIcon",
    txt: "저장/다운로드",
    impoTxt:
      'import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";',
  },
  {
    id: 18,
    name: "BookmarkBorderOutlinedIcon",
    txt: "보관",
    impoTxt:
      'import BookmarkBorderOutlinedIcon from "@mui/icons-material/BookmarkBorderOutlined";',
  },
  {
    id: 19,
    name: "PrintOutlinedIcon",
    txt: "인쇄",
    impoTxt:
      'import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";',
  },
  {
    id: 20,
    name: "CreateOutlinedIcon",
    txt: "결의서 작성/수정/양식수정",
    impoTxt:
      'import CreateOutlinedIcon from "@mui/icons-material/ContactEmergencyOutlined";',
  },
  {
    id: 21,
    name: "FilterAltOutlinedIcon",
    txt: "필터",
    impoTxt:
      'import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";',
  },
  {
    id: 22,
    name: "SettingsOutlinedIcon",
    txt: "상세 필터",
    impoTxt:
      'import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";',
  },
  {
    id: 23,
    name: "NoteOutlinedIcon",
    txt: "메모",
    impoTxt: 'import NoteOutlinedIcon from "@mui/icons-material/NoteOutlined";',
  },
  {
    id: 24,
    name: "TuneOutlinedIcon",
    txt: "보기설정",
    impoTxt: 'import NoteOutlinedIcon from "@mui/icons-material/TuneOutlined";',
  },
  {
    id: 25,
    name: "RemoveCircleOutlineOutlinedIcon",
    txt: "제외/해제",
    impoTxt:
      'import RemoveCircleOutlineOutlinedIcon from "@mui/icons-material/RemoveCircleOutlineOutlined";',
  },
  {
    id: 26,
    name: "FileUploadOutlinedIcon",
    txt: "업로드",
    impoTxt:
      'import FileUploadOutlinedIcon from "@mui/icons-material/FileUploadOutlined";',
  },
  {
    id: 27,
    name: "ImageOutlinedIcon",
    txt: "이미지 첨부",
    impoTxt:
      'import ImageOutlinedIcon from "@mui/icons-material/ImageOutlined";',
  },
  {
    id: 28,
    name: "ShareOutlinedIcon",
    txt: "회람",
    impoTxt:
      'import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";',
  },
  {
    id: 29,
    name: "GroupAddOutlinedIcon",
    txt: "임시담당자 지정",
    impoTxt:
      'import GroupAddOutlinedIcon from "@mui/icons-material/GroupAddOutlined";',
  },
  {
    id: 30,
    name: "BusinessOutlinedIcon",
    txt: "회사정보",
    impoTxt:
      'import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";',
  },
  {
    id: 31,
    name: "PersonSearchOutlinedIcon",
    txt: "직원조회",
    impoTxt:
      'import PersonSearchOutlinedIcon from "@mui/icons-material/PersonSearchOutlined";',
  },
  {
    id: 32,
    name: "AddOutlinedIcon",
    txt: "추가/행추가",
    impoTxt: 'import AddOutlinedIcon from "@mui/icons-material/AddOutlined";',
  },
  {
    id: 33,
    name: "RemoveOutlinedIcon",
    txt: "삭제/행제거",
    impoTxt:
      'import RemoveOutlinedIcon from "@mui/icons-material/RemoveOutlined";',
  },
  {
    id: 34,
    name: "DeleteOutlinedIcon",
    txt: "삭제",
    impoTxt:
      'import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";',
  },
  {
    id: 35,
    name: "AccessTimeOutlinedIcon",
    txt: "마감/해제",
    impoTxt:
      'import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";',
  },
  {
    id: 36,
    name: "ApprovalOutlinedIcon",
    txt: "결재/접수결재",
    impoTxt:
      'import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";',
  },
  {
    id: 37,
    name: "OpenInFullOutlinedIcon",
    txt: "증빙내역 펼치기",
    impoTxt:
      'import OpenInFullOutlinedIcon from "@mui/icons-material/OpenInFullOutlined";',
  },
  {
    id: 38,
    name: "CancelOutlinedIcon",
    txt: "상신취소/최종결재취소",
    impoTxt:
      'import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";',
  },
  {
    id: 39,
    name: "DriveFileRenameOutlineOutlinedIcon",
    txt: "재기안",
    impoTxt:
      'import DriveFileRenameOutlineOutlinedIcon from "@mui/icons-material/DriveFileRenameOutlineOutlined";',
  },
  {
    id: 40,
    name: "ManageSearchOutlinedIcon",
    txt: "거래처 불러오기",
    impoTxt:
      'import ManageSearchOutlinedIcon from "@mui/icons-material/ManageSearchOutlined";',
  },
  {
    id: 41,
    name: "RestartAltOutlinedIcon",
    txt: "초기화",
    impoTxt:
      'import ManageSearchOutlinedIcon from "@mui/icons-material/RestartAltOutlined";',
  },
  {
    id: 42,
    name: "InputOutlinedIcon",
    txt: "일괄입력",
    impoTxt:
      'import InputOutlinedIcon from "@mui/icons-material/InputOutlined";',
  },
  {
    id: 43,
    name: "AltRouteOutlinedIcon",
    txt: "분할",
    impoTxt:
      'import AltRouteOutlinedIcon from "@mui/icons-material/AltRouteOutlined";',
  },
  {
    id: 44,
    name: "WifiProtectedSetupOutlinedIcon",
    txt: "국세청 가져오기",
    impoTxt:
      'import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";',
  },
  {
    id: 45,
    name: "CreateNewFolderOutlinedIcon",
    txt: "카드그룹 생성",
    impoTxt:
      'import CreateNewFolderOutlinedIcon from "@mui/icons-material/CreateNewFolderOutlined";',
  },
  {
    id: 46,
    name: "AnnouncementOutlinedIcon",
    txt: "결재의견",
    impoTxt:
      'import AnnouncementOutlinedIcon from "@mui/icons-material/AnnouncementOutlined";',
  },
  {
    id: 47,
    name: "InventoryOutlinedIcon",
    txt: "결재정보",
    impoTxt:
      'import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";',
  },
  {
    id: 48,
    name: "SyncOutlinedIcon",
    txt: "결재선 변경",
    impoTxt: 'import SyncOutlinedIcon from "@mui/icons-material/SyncOutlined";',
  },
  {
    id: 49,
    name: "TaskOutlinedIcon",
    txt: "양식선택",
    impoTxt: 'import TaskOutlinedIcon from "@mui/icons-material/TaskOutlined";',
  },
  {
    id: 50,
    name: "RateReviewOutlinedIcon",
    txt: "결재란 설정",
    impoTxt:
      'import RateReviewOutlinedIcon from "@mui/icons-material/RateReviewOutlined";',
  },
  {
    id: 51,
    name: "HowToRegOutlinedIcon",
    txt: "양식별 결재선 설정",
    impoTxt:
      'import HowToRegOutlinedIcon from "@mui/icons-material/HowToRegOutlined";',
  },
  {
    id: 52,
    name: "ContentCopyOutlinedIcon",
    txt: "양식복사",
    impoTxt:
      'import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";',
  },
  {
    id: 53,
    name: "RefreshOutlinedIcon",
    txt: "최신정보 불러오기",
    impoTxt:
      'import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";',
  },
  {
    id: 55,
    name: "AttachFileOutlinedIcon",
    txt: "파일",
    impoTxt:
      'import AttachFileOutlinedIcon from "@mui/icons-material/AttachFileOutlined";',
  },
  {
    id: 56,
    name: "KeyboardArrowDownRoundedIcon",
    txt: "열기/아래로",
    impoTxt:
      'import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";',
  },
  {
    id: 57,
    name: "KeyboardArrowUpOutlinedIcon",
    txt: "위로",
    impoTxt:
      'import KeyboardArrowUpOutlinedIcon from "@mui/icons-material/KeyboardArrowUpOutlined";',
  },
  {
    id: 58,
    name: "ArrowDropDownIcon",
    txt: "열기",
    impoTxt:
      'import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";',
  },
  {
    id: 59,
    name: "LinkOutlinedIcon",
    txt: "연결",
    impoTxt: 'import LinkOutlinedIcon from "@mui/icons-material/LinkOutlined";',
  },
  {
    id: 60,
    name: "NotificationsNoneOutlinedIcon",
    txt: "알림",
    impoTxt:
      'import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";',
  },
  {
    id: 61,
    name: "KeyboardReturn",
    txt: "되돌리기",
    impoTxt: 'import { KeyboardReturn } from "@mui/icons-material";',
  },
  {
    id: 62,
    name: "CloseIcon",
    txt: "닫기",
    impoTxt: 'import CloseIcon from "@mui/icons-material/Close";',
  },
  {
    id: 63,
    name: "CloseIcon",
    txt: "상태변경",
    impoTxt: 'import CachedIcon from "@mui/icons-material/Cached";',
  },
];

const iconLnbList = [
  {
    id: 1,
    name: "SpaceDashboardIcon",
    txt: "HOME",
    impoTxt:
      'import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";',
  },
  {
    id: 2,
    name: "ReceiptIcon",
    txt: "경비",
    impoTxt: 'import ReceiptIcon from "@mui/icons-material/Receipt";',
  },
  {
    id: 3,
    name: "ApprovalRoundedIcon",
    txt: "결재",
    impoTxt:
      'import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";',
  },
  {
    id: 4,
    name: "TaskIcon",
    txt: "리포트",
    impoTxt: 'import TaskIcon from "@mui/icons-material/Task";',
  },
  {
    id: 5,
    name: "DirectionsCarIcon",
    txt: "업무차량",
    impoTxt:
      'import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";',
  },
  {
    id: 6,
    name: "ReorderRoundedIcon",
    txt: "기초정보관리",
    impoTxt:
      'import ReorderRoundedIcon from "@mui/icons-material/ReorderRounded";',
  },
  {
    id: 7,
    name: "ArticleRoundedIcon",
    txt: "전표관리",
    impoTxt:
      'import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";',
  },
  {
    id: 8,
    name: "SettingsRoundedIcon",
    txt: "관리자설정/사용자설정",
    impoTxt:
      'import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";',
  },
  {
    id: 9,
    name: "InsertDriveFileOutlinedIcon",
    txt: "Documentation",
    impoTxt:
      'import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";',
  },
];

const iconBreadcrumbsList = [
  {
    id: 1,
    name: "SpaceDashboardIcon",
    txt: "HOME",
    impoTxt:
      'import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";',
  },
  {
    id: 2,
    name: "CampaignIcon",
    txt: "현재 위치",
    impoTxt: 'import CampaignIcon from "@mui/icons-material/Campaign";',
  },
];

const Icons = (props: IconsProps) => {
  return (
    <>
      <div style={{ display: "none" }}>
        <h3 className="heading3">2-1. 공통 아이콘</h3>
        <List className={styles.list}>
          {iconList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SearchOutlinedIcon" && <SearchOutlinedIcon />}
                  {icon.name === "ArrowBackOutlinedIcon" && (
                    <ArrowBackOutlinedIcon />
                  )}
                  {icon.name === "ArrowForwardOutlinedIcon" && (
                    <ArrowForwardOutlinedIcon />
                  )}
                  {icon.name === "CreditCardRoundedIcon" && (
                    <CreditCardRoundedIcon />
                  )}
                  {icon.name === "ContactEmergencyOutlinedIcon" && (
                    <ContactEmergencyOutlinedIcon />
                  )}
                  {icon.name === "ReceiptLongOutlinedIcon" && (
                    <ReceiptLongOutlinedIcon />
                  )}
                  {icon.name === "MoreHorizOutlinedIcon" && (
                    <MoreHorizOutlinedIcon />
                  )}
                  {icon.name === "PriorityHighRoundedIcon" && (
                    <PriorityHighRoundedIcon />
                  )}
                  {icon.name === "SyncRoundedIcon" && <SyncRoundedIcon />}
                  {icon.name === "CheckRounded" && <CheckRounded />}
                  {icon.name === "PauseRoundedIcon" && <PauseRoundedIcon />}
                  {icon.name === "ArrowForwardIosRoundedIcon" && (
                    <ArrowForwardIosRoundedIcon />
                  )}
                  {icon.name === "PauseCircleOutlinedIcon" && (
                    <PauseCircleOutlinedIcon />
                  )}
                  {icon.name === "PersonIcon" && (
                    <PersonIcon className="icon-avatar" />
                  )}
                  {icon.name === "AltRouteOutlinedIcon" && (
                    <AltRouteOutlinedIcon />
                  )}
                  {icon.name === "EditNoteOutlinedIcon" && (
                    <EditNoteOutlinedIcon />
                  )}
                  {icon.name === "MoreVertOutlinedIcon" && (
                    <MoreVertOutlinedIcon />
                  )}
                  {icon.name === "FileDownloadOutlinedIcon" && (
                    <FileDownloadOutlinedIcon />
                  )}
                  {icon.name === "BookmarkBorderOutlinedIcon" && (
                    <BookmarkBorderOutlinedIcon />
                  )}
                  {icon.name === "PrintOutlinedIcon" && <PrintOutlinedIcon />}
                  {icon.name === "CreateOutlinedIcon" && <CreateOutlinedIcon />}
                  {icon.name === "FilterAltOutlinedIcon" && (
                    <FilterAltOutlinedIcon />
                  )}
                  {icon.name === "SettingsOutlinedIcon" && (
                    <SettingsOutlinedIcon />
                  )}
                  {icon.name === "NoteOutlinedIcon" && <NoteOutlinedIcon />}
                  {icon.name === "TuneOutlinedIcon" && <TuneOutlinedIcon />}
                  {icon.name === "RemoveCircleOutlineOutlinedIcon" && (
                    <RemoveCircleOutlineOutlinedIcon />
                  )}
                  {icon.name === "FileUploadOutlinedIcon" && (
                    <FileUploadOutlinedIcon />
                  )}
                  {icon.name === "ImageOutlinedIcon" && <ImageOutlinedIcon />}
                  {icon.name === "ShareOutlinedIcon" && <ShareOutlinedIcon />}
                  {icon.name === "GroupAddOutlinedIcon" && (
                    <GroupAddOutlinedIcon />
                  )}
                  {icon.name === "BusinessOutlinedIcon" && (
                    <BusinessOutlinedIcon />
                  )}
                  {icon.name === "PersonSearchOutlinedIcon" && (
                    <PersonSearchOutlinedIcon />
                  )}
                  {icon.name === "AddOutlinedIcon" && <AddOutlinedIcon />}
                  {icon.name === "RemoveOutlinedIcon" && <RemoveOutlinedIcon />}
                  {icon.name === "DeleteOutlinedIcon" && <DeleteOutlinedIcon />}
                  {icon.name === "AccessTimeOutlinedIcon" && (
                    <AccessTimeOutlinedIcon />
                  )}
                  {icon.name === "ApprovalOutlinedIcon" && (
                    <ApprovalOutlinedIcon />
                  )}
                  {icon.name === "OpenInFullOutlinedIcon" && (
                    <OpenInFullOutlinedIcon />
                  )}
                  {icon.name === "CancelOutlinedIcon" && <CancelOutlinedIcon />}
                  {icon.name === "DriveFileRenameOutlineOutlinedIcon" && (
                    <DriveFileRenameOutlineOutlinedIcon />
                  )}
                  {icon.name === "ManageSearchOutlinedIcon" && (
                    <ManageSearchOutlinedIcon />
                  )}
                  {icon.name === "RestartAltOutlinedIcon" && (
                    <RestartAltOutlinedIcon />
                  )}
                  {icon.name === "InputOutlinedIcon" && <InputOutlinedIcon />}
                  {icon.name === "WifiProtectedSetupOutlinedIcon" && (
                    <WifiProtectedSetupOutlinedIcon />
                  )}
                  {icon.name === "CreateNewFolderOutlinedIcon" && (
                    <CreateNewFolderOutlinedIcon />
                  )}
                  {icon.name === "AnnouncementOutlinedIcon" && (
                    <AnnouncementOutlinedIcon />
                  )}
                  {icon.name === "InventoryOutlinedIcon" && (
                    <InventoryOutlinedIcon />
                  )}
                  {icon.name === "SyncOutlinedIcon" && <SyncOutlinedIcon />}
                  {icon.name === "TaskOutlinedIcon" && <TaskOutlinedIcon />}
                  {icon.name === "RateReviewOutlinedIcon" && (
                    <RateReviewOutlinedIcon />
                  )}
                  {icon.name === "HowToRegOutlinedIcon" && (
                    <HowToRegOutlinedIcon />
                  )}
                  {icon.name === "ContentCopyOutlinedIcon" && (
                    <ContentCopyOutlinedIcon />
                  )}
                  {icon.name === "RefreshOutlinedIcon" && (
                    <RefreshOutlinedIcon />
                  )}
                  {icon.name === "AttachFileOutlinedIcon" && (
                    <AttachFileOutlinedIcon />
                  )}
                  {icon.name === "KeyboardArrowDownRoundedIcon" && (
                    <KeyboardArrowDownRoundedIcon />
                  )}
                  {icon.name === "KeyboardArrowUpOutlinedIcon" && (
                    <KeyboardArrowUpOutlinedIcon />
                  )}
                  {icon.name === "ArrowDropDownIcon" && <ArrowDropDownIcon />}
                  {icon.name === "LinkOutlinedIcon" && <LinkOutlinedIcon />}
                  {icon.name === "NotificationsNoneOutlinedIcon" && (
                    <NotificationsNoneOutlinedIcon />
                  )}
                  {icon.name === "KeyboardReturn" && <KeyboardReturn />}
                  {icon.name === "CloseIcon" && <CloseIcon />}
                  {icon.name === "CachedIcon" && <CachedIcon />}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
        <h3 className="heading3">2-2. LNB 메뉴 아이콘</h3>
        <List className={styles.list}>
          {iconLnbList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SpaceDashboardIcon" && <SpaceDashboardIcon />}
                  {icon.name === "ReceiptIcon" && <ReceiptIcon />}
                  {icon.name === "ApprovalRoundedIcon" && (
                    <ApprovalRoundedIcon />
                  )}
                  {icon.name === "TaskIcon" && <TaskIcon />}
                  {icon.name === "DirectionsCarIcon" && <DirectionsCarIcon />}
                  {icon.name === "ReorderRoundedIcon" && <ReorderRoundedIcon />}
                  {icon.name === "ArticleRoundedIcon" && <ArticleRoundedIcon />}
                  {icon.name === "SettingsRoundedIcon" && (
                    <SettingsRoundedIcon />
                  )}
                  {icon.name === "InsertDriveFileOutlinedIcon" && (
                    <InsertDriveFileOutlinedIcon />
                  )}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
        <h3 className="heading3">2-3. Breadcrumbs 아이콘</h3>
        <List className={styles.list}>
          {iconBreadcrumbsList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SpaceDashboardIcon" && <SpaceDashboardIcon />}
                  {icon.name === "CampaignIcon" && <CampaignIcon />}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
      </div>
    </>
  );
};

export default Icons;
