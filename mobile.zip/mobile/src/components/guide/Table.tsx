import DeleteIcon from "@mui/icons-material/Delete";
import FilterListIcon from "@mui/icons-material/FilterList";
import {
  Box,
  Button,
  Checkbox,
  IconButton,
  Paper,
  Radio,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  Toolbar,
  Tooltip,
  Typography,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import { DataGrid } from "@mui/x-data-grid";
import * as React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";

interface Data {
  id: number;
  name: string;
  tblTitle01: number;
  tblTitle02: number;
  tblTitle03: number;
  tblTitle04: number;
}

function createData2(
  id: number,
  name: string,
  tblTitle01: number,
  tblTitle02: number,
  tblTitle03: number,
  tblTitle04: number,
): Data {
  return {
    id,
    name,
    tblTitle01,
    tblTitle02,
    tblTitle03,
    tblTitle04,
  };
}

const rows2 = [
  createData2(1, "Cupcake", 305, 3.7, 67, 4.3),
  createData2(2, "Donut", 452, 25.0, 51, 4.9),
  createData2(3, "Eclair", 262, 16.0, 24, 6.0),
];

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

type Order = "asc" | "desc";

function getComparator<Key extends keyof any>(
  order: Order,
  orderBy: Key,
): (
  a: { [key in Key]: number | string },
  b: { [key in Key]: number | string },
) => number {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort<T>(
  array: readonly T[],
  comparator: (a: T, b: T) => number,
) {
  const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

interface HeadCell {
  id: keyof Data;
  label: string;
  numeric: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "name",
    numeric: true,
    label: "종류",
  },
  {
    id: "tblTitle01",
    numeric: true,
    label: "사용내역상태",
  },
  {
    id: "tblTitle02",
    numeric: true,
    label: "결의상태",
  },
  {
    id: "tblTitle03",
    numeric: true,
    label: "사용금액",
  },
  {
    id: "tblTitle04",
    numeric: true,
    label: "사용일시",
  },
];

interface EnhancedTableProps {
  numSelected: number;
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof Data,
  ) => void;
  onSelectAllClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
}

function EnhancedTableHead(props: EnhancedTableProps) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;
  const createSortHandler =
    (property: keyof Data) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        <TableCell padding="checkbox">
          <Checkbox
            color="primary"
            indeterminate={numSelected > 0 && numSelected < rowCount}
            checked={rowCount > 0 && numSelected === rowCount}
            onChange={onSelectAllClick}
            inputProps={{
              "aria-label": "전체 선택",
            }}
          />
        </TableCell>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "left" : "center"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              className="tbl-cell-inner th-cell"
              onClick={createSortHandler(headCell.id)}
            >
              <span className="cell-text bp-ellipsis">{headCell.label}</span>
              {orderBy === headCell.id ? (
                <span className="cell-buttons">
                  {order === "desc" ? "" : ""}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

interface EnhancedTableToolbarProps {
  numSelected: number;
}

function EnhancedTableToolbar(props: EnhancedTableToolbarProps) {
  const { numSelected } = props;

  return (
    <Toolbar>
      {numSelected > 0 ? (
        <Typography
          sx={{ flex: "1 1 100%" }}
          color="inherit"
          variant="subtitle1"
          component="div"
        >
          {numSelected} selected
        </Typography>
      ) : (
        <Typography
          sx={{ flex: "1 1 100%" }}
          variant="h6"
          id="tableTitle"
          component="div"
        >
          Nutrition
        </Typography>
      )}
      {numSelected > 0 ? (
        <Tooltip title="Delete">
          <IconButton>
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      ) : (
        <Tooltip title="Filter list">
          <IconButton>
            <FilterListIcon />
          </IconButton>
        </Tooltip>
      )}
    </Toolbar>
  );
}

export default function BpTable() {
  const [selectedRadio, setSelectedRadio] = useState(null);
  const [order, setOrder] = React.useState<Order>("asc");
  const [orderBy, setOrderBy] = React.useState<keyof Data>("tblTitle01");
  const [selected, setSelected] = React.useState<readonly number[]>([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleChangeRadio = (event, id) => {
    setSelectedRadio(id);
  };

  const getRowId = (row) => row.id;

  const getRowClassName = (params) => {
    return params.row.id === 2 ? "is-disabled" : "";
  };

  function createData(
    id: number,
    corporateName: string,
    businessNumber: string,
  ) {
    return { id, corporateName, businessNumber, radioValue: `corporate${id}` };
  }

  const rows = [
    createData(
      1,
      "비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이비즈플레이",
      "123-45-67891",
    ),
    createData(2, "웹케시", "123-45-67891"),
    createData(3, "쿠콘", "123-45-67891"),
    createData(4, "쿠콘", "123-45-67891"),
    createData(5, "쿠콘", "123-45-67891"),
    createData(6, "쿠콘", "123-45-67891"),
  ];

  const getRowHeightCompact = (params) => {
    return 38;
  };
  const getRowHeightStandard = (params) => {
    return 44;
  };

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof Data,
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelected = rows2.map((n) => n.id);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event: React.MouseEvent<unknown>, id: number) => {
    const selectedIndex = selected.indexOf(id);
    let newSelected: readonly number[] = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const isSelected = (id: number | string) =>
    selected.indexOf(id as number) !== -1;

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows2.length) : 0;

  const visibleRows = React.useMemo(
    () =>
      stableSort(rows2, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage,
      ),
    [order, orderBy, page, rowsPerPage],
  );

  return (
    <>
      <h3 className="heading3">7-1. [공통]기본 Table</h3>
      <Grid container spacing={2}>
        <Grid xs={12} md={6}>
          <h4 className="heading4">7-1-1. [공통]기본 Table 샘플</h4>
          <div className="bp-tbl-wrap">
            <div className="bp-tbl-top">
              <Box className="left"></Box>
              <Box className="right">
                <Button variant="outlined" size="medium" color="error">
                  삭제
                </Button>
              </Box>
            </div>
            <Stack spacing={0} className="bp-tbl tbl-default">
              <TableContainer component={Paper} sx={{ height: 238 }}>
                <Table
                  size="small" // small | medium
                  aria-label="회사 선택"
                  padding="normal" // normal | none | checkbox
                  stickyHeader
                >
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ width: "50px" }}>
                        <div className="tbl-cell-inner th-cell">
                          <div className="cell-text bp-ellipsis">&nbsp;</div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                      <TableCell sx={{ width: "calc(50%)" }}>
                        <div className="tbl-cell-inner th-cell">
                          <div className="cell-text bp-ellipsis">회사명</div>
                          {/* className="bp-llipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                      <TableCell sx={{ width: "calc(50%)" }}>
                        <div className="tbl-cell-inner th-cell">
                          <div className="cell-text bp-ellipsis">
                            사업자등록번호
                          </div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow
                        key={row.id}
                        className={getRowClassName({ row })}
                      >
                        <TableCell scope="row" align="center">
                          <Radio
                            checked={selectedRadio === row.radioValue}
                            onChange={(e) =>
                              handleChangeRadio(e, row.radioValue)
                            }
                            value={row.radioValue}
                            name="search-corporate"
                            disabled={row.id === 2}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.corporateName}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.businessNumber}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Stack>
            <div className="bp-tbl-bottom">
              <Box className="left">2 개체, 3.22MB</Box>
              <Box className="right">최대 20개, 11.00mb</Box>
            </div>
          </div>
        </Grid>
        <Grid xs={12} md={6}>
          <Stack spacing={0} className="bp-tbl tbl-default">
            <TableContainer component={Paper} sx={{ height: 238 }}>
              <Table
                size="medium" // small | medium
                aria-label="회사 선택"
                padding="normal" // normal | none | checkbox
                stickyHeader
              >
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ width: "50px" }}>&nbsp;</TableCell>
                    <TableCell sx={{ width: "calc(50%)" }}>
                      <div className="tbl-cell-inner">
                        <div className="cell-text bp-ellipsis">
                          회사명회사명회사명회사명회사명회사명
                        </div>
                        {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                        <div className="cell-buttons">아이콘이 있을 경우</div>
                      </div>
                    </TableCell>
                    <TableCell sx={{ width: "calc(50%)" }}>
                      사업자등록번호
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow key={row.id} className={getRowClassName({ row })}>
                      <TableCell scope="row" align="center">
                        <Radio
                          checked={selectedRadio === row.radioValue}
                          onChange={(e) => handleChangeRadio(e, row.radioValue)}
                          value={row.radioValue}
                          name="search-corporate"
                          disabled={row.id === 2}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="tbl-cell-inner td-cell">
                          <div className="cell-text bp-ellipsis">
                            {row.corporateName}
                          </div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="tbl-cell-inner td-cell">
                          <div className="cell-text bp-ellipsis">
                            {row.businessNumber}
                          </div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Stack>
        </Grid>
        <Grid xs={12} md={6}>
          <h4 className="heading4">7-1-2. [공통]기본 Table 샘플</h4>
          <Stack spacing={0} className="bp-tbl tbl-default">
            <TableContainer component={Paper} sx={{ height: 238 }}>
              <Table
                aria-labelledby="회사 선택"
                //size={dense ? "small" : "medium"}
                size="medium" // small | medium
                aria-label="회사 선택"
                padding="normal" // normal | none | checkbox
                stickyHeader
              >
                <EnhancedTableHead
                  numSelected={selected.length}
                  order={order}
                  orderBy={orderBy}
                  onSelectAllClick={handleSelectAllClick}
                  onRequestSort={handleRequestSort}
                  rowCount={rows2.length}
                />
                <TableBody>
                  {visibleRows.map((row, index) => {
                    const isItemSelected = isSelected(row.id);
                    const labelId = `enhanced-table-checkbox-${index}`;
                    return (
                      <TableRow
                        hover
                        onClick={(event) =>
                          handleClick(event, row.id as number)
                        }
                        role="checkbox"
                        aria-checked={isItemSelected}
                        tabIndex={-1}
                        key={row.id}
                        selected={isItemSelected}
                        sx={{ cursor: "pointer" }}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox
                            color="primary"
                            checked={isItemSelected}
                            inputProps={{
                              "aria-labelledby": labelId,
                            }}
                          />
                        </TableCell>
                        <TableCell component="th" id={labelId} scope="row">
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.name}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.tblTitle01}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.tblTitle02}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.tblTitle03}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="tbl-cell-inner td-cell">
                            <div className="cell-text bp-ellipsis2">
                              {row.tblTitle04}
                            </div>
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            <div className="cell-buttons"></div>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {emptyRows > 0 && (
                    <TableRow
                      style={{
                        height: (dense ? 33 : 53) * emptyRows,
                      }}
                    >
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={rows2.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Stack>
        </Grid>
        <Grid xs={12} md={6}>
          <h4 className="heading4">7-1-3. [공통]좌우 Fixed Table 샘플</h4>
          <Stack spacing={0} className="bp-tbl tbl-default tbl-fixed">
            <TableContainer
              component={Paper}
              sx={{ height: 238, maxWidth: 600 }}
            >
              <Table
                size="medium" // small | medium
                aria-label="회사 선택"
                padding="normal" // normal | none | checkbox
                stickyHeader
              >
                <TableHead>
                  <TableRow>
                    <TableCell
                      className="sticky-cell sticky-left"
                      sx={{ width: "180px" }}
                    >
                      sticky left
                    </TableCell>
                    <TableCell sx={{ width: "50px" }}>&nbsp;</TableCell>
                    <TableCell sx={{ width: "180px" }}>
                      <div className="tbl-cell-inner">
                        <div className="cell-text bp-ellipsis">
                          회사명회사명회사명회사명회사명회사명
                        </div>
                        {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                        <div className="cell-buttons">아이콘이 있을 경우</div>
                      </div>
                    </TableCell>
                    <TableCell sx={{ width: "200px" }}>
                      사업자등록번호
                    </TableCell>
                    <TableCell
                      className="sticky-cell sticky-right"
                      sx={{ width: "180px" }}
                    >
                      sticky right
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow key={row.id} className={getRowClassName({ row })}>
                      <TableCell className="sticky-cell sticky-left">
                        sticky
                      </TableCell>
                      <TableCell scope="row" align="center">
                        <Radio
                          checked={selectedRadio === row.radioValue}
                          onChange={(e) => handleChangeRadio(e, row.radioValue)}
                          value={row.radioValue}
                          name="search-corporate"
                          disabled={row.id === 2}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="tbl-cell-inner td-cell">
                          <div className="cell-text bp-ellipsis">
                            {row.corporateName}
                          </div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="tbl-cell-inner td-cell">
                          <div className="cell-text bp-ellipsis">
                            {row.businessNumber}
                          </div>
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          <div className="cell-buttons"></div>
                        </div>
                      </TableCell>
                      <TableCell
                        className="sticky-cell sticky-right"
                        sx={{ width: "180px" }}
                      >
                        sticky right
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Stack>
        </Grid>
      </Grid>

      <h3 className="heading3">7-2. [공통]기본 Table(Data Grid)</h3>
      <Grid container spacing={2}>
        <Grid xs={12} md={6}>
          <div className="bp-tbl-wrap">
            <div className="bp-tbl-top">
              <Box className="left"></Box>
              <Box className="right">
                <Button variant="outlined" size="medium" color="error">
                  삭제
                </Button>
              </Box>
            </div>
            <Stack spacing={0} className="bp-tbl tbl-grid">
              <div style={{ height: 238 }}>
                <DataGrid
                  rows={rows}
                  columns={[
                    {
                      field: "radioValue",
                      headerName: "",
                      sortable: false,
                      width: 40,
                      align: "center",
                      renderCell: (params) => (
                        <Radio
                          checked={selectedRadio === params.row.radioValue}
                          onChange={(e) =>
                            handleChangeRadio(e, params.row.radioValue)
                          }
                          value={params.row.radioValue}
                          name="search-corporate"
                          disabled={params.row.id === 2}
                        />
                      ),
                    },
                    {
                      field: "corporateName",
                      headerName: "회사명",
                      flex: 5,
                      sortable: false,
                      renderCell: (cellValues) => {
                        return (
                          <Link to="#" className="bp-ellipsis">
                            {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                            {cellValues.value}
                          </Link>
                        );
                      },
                    },
                    {
                      field: "businessNumber",
                      headerName: "사업자등록번호",
                      flex: 5,
                      sortable: false,
                    },
                  ]}
                  density="compact"
                  //getRowHeight={() => "auto"}
                  getRowHeight={getRowHeightCompact}
                  disableColumnMenu
                  hideFooterPagination
                  hideFooter
                  getRowId={getRowId}
                  getRowClassName={getRowClassName}
                  //autoHeight={false}
                />
              </div>
            </Stack>
            <div className="bp-tbl-bottom">
              <Box className="left">2 개체, 3.22MB</Box>
              <Box className="right">최대 20개, 11.00mb</Box>
            </div>
          </div>
        </Grid>
        <Grid xs={12} md={6}>
          <Stack spacing={0} className="bp-tbl tbl-grid">
            <div style={{ height: 238 }}>
              <DataGrid
                rows={rows}
                columns={[
                  {
                    field: "radioValue",
                    headerName: "",
                    sortable: false,
                    width: 40,
                    align: "center",
                    renderCell: (params) => (
                      <Radio
                        checked={selectedRadio === params.row.radioValue}
                        onChange={(e) =>
                          handleChangeRadio(e, params.row.radioValue)
                        }
                        value={params.row.radioValue}
                        name="search-corporate"
                        disabled={params.row.id === 2}
                      />
                    ),
                  },
                  {
                    field: "corporateName",
                    headerName: "회사명",
                    flex: 5,
                    sortable: false,
                    renderCell: (cellValues) => {
                      return (
                        <Link to="#" className="bp-ellipsis">
                          {/* className="bp-ellipsis(한줄) | bp-ellipsis2(두줄) | bp-ellipsis3(세줄)" */}
                          {cellValues.value}
                        </Link>
                      );
                    },
                  },
                  {
                    field: "businessNumber",
                    headerName: "사업자등록번호",
                    flex: 5,
                    sortable: false,
                  },
                ]}
                density="standard"
                //getRowHeight={() => "auto"}
                getRowHeight={getRowHeightStandard}
                disableColumnMenu
                hideFooterPagination
                hideFooter
                getRowId={getRowId}
                getRowClassName={getRowClassName}
                //autoHeight={false}
                rowHeight={44}
              />
            </div>
          </Stack>
        </Grid>
      </Grid>
    </>
  );
}
