import { DateRange } from "@mui/icons-material";
import ArrowDropDownOutlinedIcon from "@mui/icons-material/ArrowDropDownOutlined";
import CancelIcon from "@mui/icons-material/Cancel";
import ScheduleIcon from "@mui/icons-material/Schedule";
import {
  Autocomplete,
  Box,
  Button,
  Checkbox,
  Chip,
  ClickAwayListener,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  FormLabel,
  Grow,
  IconButton,
  InputAdornment,
  InputLabel,
  List,
  ListItem,
  MenuItem,
  MenuList,
  OutlinedInput,
  Paper,
  Popper,
  Radio,
  RadioGroup,
  Stack,
  Switch,
  TextField,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import { DateRangePicker } from "@mui/x-date-pickers-pro/DateRangePicker";
import { SingleInputDateRangeField } from "@mui/x-date-pickers-pro/SingleInputDateRangeField";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { Calendar, ChevronRight, SearchSm } from "@untitled-ui/icons-react";
import dayjs, { Dayjs } from "dayjs";
import * as React from "react";
import { useRef, useState } from "react";
import { Scrollbar } from "src/components/scrollbar";
import styles from "./Guide.module.css";

const selectOption = [
  { label: "label1", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

/* 기간 달력 */
type DateRange<T> = [T | null, T | null];

interface CustomPickersShortcutsItem<T> {
  label: string;
  name?: string;
  getValue: () => T;
}

const shortcutsItems: CustomPickersShortcutsItem<DateRange<Dayjs>>[] = [
  {
    label: "1주",
    name: "week-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("week"), today.endOf("week")];
    },
  },
  {
    label: "1개월",
    name: "month-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month")];
    },
  },
  {
    label: "3개월",
    name: "three-months-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month").add(2, "months")];
    },
  },
  {
    label: "일별",
    name: "day-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today, today];
    },
  },
  {
    label: "월별",
    name: "month-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month")];
    },
  },
];
const renderShortcutButton = (shortcut) => (
  <>
    <Stack>
      <Button variant="outlined" className={`${shortcut.name}`}>
        {shortcut.label}
      </Button>
    </Stack>
  </>
);
const CustomActionBar = () => (
  <>
    <Stack spacing={0} className="btns-footer-area" direction="row">
      <div className="left"></div>
      <div className="right">
        <Button size="medium" className="btn-text-primary">
          취소
        </Button>
        <Button variant="contained" size="medium">
          확인
        </Button>
      </div>
    </Stack>
  </>
);

const Forms = () => {
  const [filteredLocations, setFilteredLocations] = useState("");
  const [RadioValue, setRadioValue] = useState("a");
  const label = { inputProps: { "aria-label": "Switch demo" } };
  const [RadioValue02, setRadioValue02] = useState("radio02-01");
  const [checked, setChecked] = useState([true, false]);
  const [agreeChecked, setAgreeChecked] = useState([false, false, false]);
  const [openDialog, setOpenDialog] = React.useState(false);

  const handleClickOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const clearSearch = () => {
    setFilteredLocations("");
  };

  const filterResults = (e) => {
    setFilteredLocations(e.target.value);
  };

  const handleChangeRadio = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRadioValue(event.target.value);
  };

  const handleChangeRadio02 = (event) => {
    setRadioValue02(event.target.value);
  };

  const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([event.target.checked, event.target.checked]);
  };

  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([event.target.checked, checked[1]]);
  };

  const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([checked[0], event.target.checked]);
  };

  const indeterminateChildren = (
    <FormGroup>
      <FormControlLabel
        label="Child 1"
        control={<Checkbox checked={checked[0]} onChange={handleChange2} />}
      />
      <FormControlLabel
        label="Child 2"
        control={<Checkbox checked={checked[1]} onChange={handleChange3} />}
      />
    </FormGroup>
  );

  const handleDelete = () => {
    console.info("You clicked the delete icon.");
  };

  const handleChangeAgreeAll = (event) => {
    const isChecked = event.target.checked;
    setAgreeChecked([isChecked, isChecked, isChecked]);
  };

  const handleChangeAgree1 = () => {
    setAgreeChecked([!agreeChecked[0], agreeChecked[1], agreeChecked[2]]);
  };

  const handleChangeAgree2 = () => {
    setAgreeChecked([agreeChecked[0], !agreeChecked[1], agreeChecked[2]]);
  };

  const handleChangeAgree3 = () => {
    setAgreeChecked([agreeChecked[0], agreeChecked[1], !agreeChecked[2]]);
  };
  const agreeChildren = (
    <List disablePadding className="bp-check-list list-agree">
      <ListItem>
        <FormControlLabel
          label="[필수] 서비스 이용약관 동의"
          control={
            <Checkbox checked={agreeChecked[0]} onChange={handleChangeAgree1} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
      <ListItem>
        <FormControlLabel
          label="[필수] 개인정보처리방침 동의"
          control={
            <Checkbox checked={agreeChecked[1]} onChange={handleChangeAgree2} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
      <ListItem>
        <FormControlLabel
          label="[선택] 이벤트 · 혜택 정보 수신"
          control={
            <Checkbox checked={agreeChecked[2]} onChange={handleChangeAgree3} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
    </List>
  );

  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
    }
  }

  return (
    <>
      <h3 className={styles.heading3}>4-1. [공통]기본 Input text(TextField)</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="small"
            label="small"
            placeholder=""
            fullWidth
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="small"
            placeholder="small Label hidden"
            fullWidth
            hiddenLabel
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            label="medium"
            placeholder=""
            fullWidth
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            placeholder="medium Label hidden"
            fullWidth
            hiddenLabel
          />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <FormControl fullWidth>
            <InputLabel htmlFor="component-simple">Name</InputLabel>
            <OutlinedInput
              id="component-outlined"
              defaultValue="Composed TextField"
              label="Name"
            />
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <TextField label="입력 전" placeholder="" fullWidth />
        </Grid>
        <Grid xs={3}>
          <TextField label="필수 입력" placeholder="" fullWidth required />
        </Grid>
        <Grid xs={3}>
          <TextField label="비활성화 상태" placeholder="" fullWidth disabled />
        </Grid>
        <Grid xs={3}>
          <TextField label="기본 열림 상태" placeholder="" fullWidth focused />
        </Grid>
        <Grid xs={3}>
          <TextField
            label="Multiline"
            placeholder="Multiline Text"
            fullWidth
            multiline
            maxRows={4}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            label="label Text"
            placeholder="placeholder Text"
            fullWidth
            helperText="validation Text"
            error
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            label="Text Type Value"
            placeholder="placeholder Text"
            fullWidth
            defaultValue="기본값 type='text' 고정"
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            type="password"
            label="Password Type Value"
            placeholder="placeholder Text"
            fullWidth
            defaultValue="기본값 type='password' 고정"
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            type="number"
            label="Number Type Value"
            placeholder="placeholder Text"
            fullWidth
            defaultValue="0000"
            InputLabelProps={{ shrink: true }}
          />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            data-cy="searchBox"
            placeholder="검색어를 입력해 주세요."
            className="bp-search"
            fullWidth
            hiddenLabel
            value={filteredLocations}
            onChange={filterResults}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start" className="btn-groups">
                  <SearchSm
                    fontSize="medium"
                    className="bp-icon medium icon-search"
                  />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            placeholder="검색어를 입력해 주세요."
            className="bp-search"
            fullWidth
            defaultValue="Hello World"
            hiddenLabel
            value={filteredLocations}
            onChange={filterResults}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                  <IconButton
                    aria-label="Search"
                    size="small"
                    className="btn-search"
                  >
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            placeholder="(readOnly 샘플)검색어를 입력해 주세요."
            className="bp-search"
            fullWidth
            hiddenLabel
            value={filteredLocations}
            onChange={filterResults}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                  <IconButton
                    aria-label="Search"
                    size="small"
                    className="btn-search"
                  >
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            placeholder="(readOnly 샘플)사용자명을 검색해 주세요."
            className="bp-search"
            fullWidth
            label="사용자"
            defaultValue=""
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                  <IconButton
                    aria-label="Search"
                    size="small"
                    className="btn-search"
                    onClick={handleClickOpenDialog}
                  >
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <Dialog
            open={openDialog}
            onClose={handleCloseDialog}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">타이틀</DialogTitle>
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                팝업 임시 샘플
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog}>취소</Button>
              <Button onClick={handleCloseDialog} autoFocus>
                확인
              </Button>
            </DialogActions>
          </Dialog>
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="medium"
            placeholder="(readOnly 샘플)사용자명을 검색해 주세요."
            className="bp-search search-chip"
            fullWidth
            label="chip 타입"
            defaultValue=""
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start" className="chips-groups">
                  {/* [D] Chip이 없는 기본값일 경우 startAdornment 없음  */}
                  <Chip label="chips1" size="small" onDelete={handleDelete} />
                  <Chip label="chips2" size="small" onDelete={handleDelete} />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                  <IconButton
                    aria-label="Search"
                    size="small"
                    className="btn-search"
                    onClick={handleClickOpenDialog}
                  >
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            size="small"
            placeholder="검색어를 입력해 주세요."
            className="bp-search"
            fullWidth
            hiddenLabel
            value={filteredLocations}
            onChange={filterResults}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end" className="btn-groups">
                  {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                    <IconButton
                      size="small"
                      className="btn-clear"
                      onClick={clearSearch}
                    >
                      <CancelIcon fontSize="small" className="bp-icon small" />
                    </IconButton>
                  )}
                  <IconButton
                    aria-label="Search"
                    size="small"
                    className="btn-search"
                  >
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid xs={3}>
          <DatePicker
            label="Helper text example"
            className="bp-datePicker fullWidth"
            format="yyyy/MM/dd"
            slotProps={{
              textField: {
                helperText: "YYYY/MM/DD",
              },
            }}
            slots={{ openPickerIcon: Calendar }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          <DatePicker
            className="bp-datePicker size-small fullWidth"
            format="yyyy/MM/dd"
            slotProps={{
              textField: {
                helperText: "YYYY/MM/DD",
              },
            }}
            slots={{ openPickerIcon: Calendar }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          <TimePicker
            label="Helper text example"
            className="bp-timePicker fullWidth"
            slotProps={{
              textField: {
                helperText: "hh/mm aa",
              },
            }}
            slots={{ openPickerIcon: ScheduleIcon }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          <TimePicker
            className="bp-timePicker size-small fullWidth"
            slotProps={{
              textField: {
                helperText: "hh/mm aa",
              },
            }}
            slots={{ openPickerIcon: ScheduleIcon }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          <DateTimePicker
            label="Date Time Picker"
            views={["year", "month", "day", "hours", "minutes", "seconds"]}
            format="YYYY/MM/DD HH:mm:ss"
            className="bp-dateTimePicker fullWidth"
            slotProps={{
              textField: {
                helperText: "YYYY/MM/DD hh/mm aa",
              },
            }}
            slots={{ openPickerIcon: Calendar }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          <DateTimePicker
            className="bp-dateTimePicker size-small fullWidth"
            views={["year", "month", "day", "hours", "minutes", "seconds"]} // 이 라인을 추가하여 표시할 수 있는 뷰를 설정합니다.
            format="YYYY/MM/DD HH:mm:ss"
            slotProps={{
              textField: {
                helperText: "YYYY/MM/DD hh/mm aa",
              },
            }}
            slots={{ openPickerIcon: Calendar }}
          />
          {/*  open */}
        </Grid>
        <Grid xs={3}>
          {/* 달력 컴퍼넌트는 MUI를 쓸지 다른걸 사용할지 결정필요함, 임의 작성해둠 */}
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DateRangePicker
              label="기간(1주/1개월/3개월/일별/월별)"
              className="bp-dateRangePicker dateRangePicker-term fullWidth"
              format="YYYY/MM/DD"
              slots={{
                field: SingleInputDateRangeField,
                //actionBar: () => <CustomActionBar />,
                shortcuts: ({ items }) => (
                  <>
                    <Stack direction="row" spacing={2} className="date-header">
                      {items.map((shortcut, index) => (
                        <React.Fragment key={index}>
                          {renderShortcutButton(shortcut)}
                        </React.Fragment>
                      ))}
                    </Stack>
                  </>
                ),
              }}
              slotProps={{
                popper: {
                  className: "pop-dateRangePicker-term", // popper-dateRangePicker-term 클래스 추가
                },
                shortcuts: {
                  items: shortcutsItems,
                },
                textField: {
                  InputProps: {
                    startAdornment: (
                      <InputAdornment position="start" className="txt">
                        <strong>일별</strong> |
                      </InputAdornment>
                    ),
                    endAdornment: <Calendar />,
                  },
                  helperText: "YYYY/MM/DD",
                },
                actionBar: {
                  actions: [],
                },
              }}
              //open
            />
          </LocalizationProvider>
        </Grid>
        <Grid xs={3}>
          <DateRangePicker
            label="기간"
            className="bp-dateRangePicker fullWidth"
            format="yyyy/MM/dd"
            slots={{
              field: SingleInputDateRangeField,
            }}
            slotProps={{
              textField: {
                InputProps: {
                  startAdornment: (
                    <InputAdornment position="start" className="txt">
                      <strong>일별</strong> |
                    </InputAdornment>
                  ),
                  endAdornment: <Calendar className="bp-icon medium" />,
                },
                helperText: "YYYY/MM/DD",
              },
            }}
          />
        </Grid>
        <Grid xs={3}>
          <DateRangePicker
            className="bp-dateRangePicker size-small fullWidth"
            format="yyyy/MM/dd"
            slots={{
              field: SingleInputDateRangeField,
            }}
            slotProps={{
              textField: {
                InputProps: {
                  startAdornment: (
                    <InputAdornment position="start" className="txt">
                      <strong>일별</strong> |
                    </InputAdornment>
                  ),
                  endAdornment: <Calendar className="bp-icon medium" />,
                },
                helperText: "YYYY/MM/DD",
              },
            }}
          />
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>
        4-2. [공통]기본 Selectbox(Autocomplete)
      </h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="small"
            id="select0-1"
            fullWidth
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="small"
                label="small"
                placeholder=""
                {...params}
              />
            )}
          />
          {/* [D]clear버튼 사용 안할 경우:disableClearable */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="small"
            id="select0-2"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="small"
                placeholder="small Label hidden"
                hiddenLabel
                {...params}
              />
            )}
          />
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select0-3"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="medium"
                placeholder=""
                {...params}
              />
            )}
          />
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select0-4"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                placeholder="medium Label hidden"
                hiddenLabel
                {...params}
              />
            )}
          />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-1"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="입력 전"
                {...params}
              />
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-1"
            className="label-fixed"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <FormControl fullWidth variant="filled" size="medium">
                <InputLabel htmlFor="select1-1">
                  label 고정 타입
                  <span
                    aria-hidden="true"
                    className="MuiFormLabel-asterisk MuiInputLabel-asterisk"
                  >
                     *
                  </span>
                </InputLabel>
                <TextField
                  {...params}
                  label=""
                  required
                  placeholder="용도를 선택해 주세요."
                />
              </FormControl>
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-2"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="필수 입력"
                required
                {...params}
              />
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-3"
            fullWidth
            autoHighlight
            disabled
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="비활성화 상태"
                {...params}
              />
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-4"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="기본 열림 상태"
                focused
                {...params}
              />
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            includeInputInList
            size="medium"
            id="select1-5"
            fullWidth
            autoHighlight
            options={selectOption}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="label Text"
                placeholder="placeholder Text"
                error
                helperText="validation Text"
                {...params}
              />
            )}
          />
          {/* 테스트 시 : open */}
        </Grid>
        <Grid xs={3}>
          <Autocomplete
            multiple
            size="medium"
            id="has-chip-2"
            className="bp-search search-chip"
            fullWidth
            autoHighlight
            disableClearable
            freeSolo
            options={selectOption}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Search input"
                InputProps={{
                  ...params.InputProps,
                  type: "search",
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      <IconButton aria-label="Search" className="btn-search">
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            )}
            renderTags={(value, getTagProps) =>
              value.map((option, index) => (
                <Chip
                  size="small"
                  label={option.label}
                  key={index}
                  {...getTagProps({ index })}
                />
              ))
            }
          />
        </Grid>
        <Grid xs={12}>
          <Autocomplete
            multiple
            size="medium"
            id="has-chip"
            fullWidth
            autoHighlight
            options={selectOption}
            getOptionLabel={(option) => option.label}
            defaultValue={[selectOption[3]]}
            renderInput={(params) => (
              <TextField
                variant="filled"
                size="medium"
                label="label  Text"
                placeholder=""
                {...params}
              />
            )}
            renderTags={(value, getTagProps) =>
              value.map((option, index) => (
                <Chip
                  size="small"
                  label={option.title}
                  key={index}
                  {...getTagProps({ index })}
                />
              ))
            }
          />
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-3. [공통]기본 textarea</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <TextField
            variant="filled"
            label="textarea"
            placeholder="Placeholder"
            fullWidth
            multiline
            maxRows={4}
          />
        </Grid>
        <Grid xs={3}>
          <TextField
            variant="filled"
            placeholder="textarea Label hidden"
            fullWidth
            hiddenLabel
            multiline
            maxRows={4}
          />
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-4. [공통]기본 Checkbox</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Checkbox defaultChecked />
          <Checkbox />
          <Checkbox disabled />
          <Checkbox disabled checked />
        </Grid>
        <Grid xs={9}>
          <FormControl component="fieldset" variant="standard">
            <FormGroup className="flex-row">
              <FormControlLabel
                control={<Checkbox defaultChecked />}
                label="옵션1 Checked"
              />
              <FormControlLabel
                required
                control={<Checkbox />}
                label="옵션2 Required"
              />
              <FormControlLabel
                disabled
                control={<Checkbox />}
                label="옵션3 Disabled"
              />
              <FormControlLabel
                disabled
                checked
                control={<Checkbox />}
                label="옵션4 Checkbox Disabled"
              />
            </FormGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControl component="fieldset" variant="standard">
            <FormLabel component="legend">Assign responsibility</FormLabel>
            <FormGroup>
              <FormControlLabel
                control={<Checkbox defaultChecked />}
                label="Checkbox Checked"
              />
              <FormControlLabel
                required
                control={<Checkbox />}
                label="Checkbox Required"
              />
              <FormControlLabel
                disabled
                control={<Checkbox />}
                label="Checkbox Disabled"
              />
              <FormControlLabel
                disabled
                checked
                control={<Checkbox />}
                label="Checkbox Disabled"
              />
            </FormGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControlLabel
            label="Parent"
            control={
              <Checkbox
                checked={checked[0] && checked[1]}
                indeterminate={checked[0] !== checked[1]}
                onChange={handleChange1}
              />
            }
          />
          {indeterminateChildren}
        </Grid>
        <Grid xs={3}>
          <FormControl
            component="fieldset"
            variant="standard"
            className="fullWidth"
          >
            <FormGroup className="bp-btns-group fullWidth" row>
              <FormControlLabel
                className="btn-form-type"
                control={<Checkbox defaultChecked />}
                label="전체"
              />
              <FormControlLabel
                className="btn-form-type"
                control={<Checkbox />}
                label="금액"
              />
              <FormControlLabel
                className="btn-form-type"
                disabled
                control={<Checkbox />}
                label="건수"
              />
            </FormGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControl
            component="fieldset"
            variant="standard"
            className="fullWidth"
          >
            <FormGroup className="bp-btns-group group-type fullWidth" row>
              <FormControlLabel
                className="btn-form-type"
                control={<Checkbox defaultChecked />}
                label="법인"
              />
              <FormControlLabel
                className="btn-form-type"
                control={<Checkbox />}
                label="개인"
              />
              <FormControlLabel
                className="btn-form-type"
                control={<Checkbox />}
                label="비활성화"
                disabled
              />
            </FormGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={6}>
          <FormControl
            component="fieldset"
            variant="standard"
            className="bp-group-list"
            fullWidth
            error
          >
            <FormGroup className="bp-group-box">
              <FormControlLabel
                label="전체 동의하기"
                control={
                  <Checkbox
                    checked={
                      agreeChecked[0] && agreeChecked[1] && agreeChecked[2]
                    }
                    indeterminate={agreeChecked[0] !== agreeChecked[1]}
                    onChange={handleChangeAgreeAll}
                  />
                }
              />
              {agreeChildren}
            </FormGroup>
            <FormHelperText className="bk-message-helper" error>
              에러 메시지 입니다.
            </FormHelperText>
          </FormControl>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-5. [공통]기본 Radio</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Radio
            checked={RadioValue === "a"}
            onChange={handleChangeRadio}
            value="a"
            name="radio-buttons"
            inputProps={{ "aria-label": "A" }}
          />
          <Radio
            checked={RadioValue === "b"}
            onChange={handleChangeRadio}
            value="b"
            name="radio-buttons"
            inputProps={{ "aria-label": "B" }}
          />
          <Radio
            checked={RadioValue === "c"}
            onChange={handleChangeRadio}
            value="c"
            name="radio-buttons"
            inputProps={{ "aria-label": "C" }}
            disabled
          />
        </Grid>
        <Grid xs={9}>
          <FormControl>
            <RadioGroup
              aria-labelledby="radio-buttons-group"
              defaultValue="radio01"
              name="radio buttons group"
              className="flex-row"
            >
              <FormControlLabel
                control={<Radio value="radio01-01" />}
                label="Radio Checked"
              />
              <FormControlLabel
                required
                control={<Radio value="radio01-02" />}
                label="Radio Required"
              />
              <FormControlLabel
                disabled
                control={<Radio value="radio01-03" />}
                label="Radio Disabled"
              />
            </RadioGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControl>
            <RadioGroup
              aria-labelledby="radio-buttons-group"
              defaultValue="radio01"
              name="radio buttons group"
            >
              <FormControlLabel
                control={<Radio value="radio01-01" />}
                label="Radio Checked"
              />
              <FormControlLabel
                required
                control={<Radio value="radio01-02" />}
                label="Radio Required"
              />
              <FormControlLabel
                disabled
                control={<Radio value="radio01-03" />}
                label="Radio Disabled"
              />
            </RadioGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControl
            component="fieldset"
            variant="standard"
            className="fullWidth"
          >
            <RadioGroup
              aria-labelledby="radio-buttons-group"
              defaultValue="radio01"
              name="radio buttons group"
              className="bp-btns-group fullWidth"
              row
            >
              <FormControlLabel
                className="btn-form-type"
                control={<Radio value="radio03-01" />}
                label="검색"
              />
              <FormControlLabel
                className="btn-form-type"
                control={<Radio value="radio03-02" />}
                label="금액"
              />
              <FormControlLabel
                className="btn-form-type"
                disabled
                control={<Radio value="radio03-03" />}
                label="건수"
              />
            </RadioGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={3}>
          <FormControl
            component="fieldset"
            variant="standard"
            className="fullWidth"
          >
            <RadioGroup
              aria-labelledby="radio-buttons-group"
              defaultValue="radio01"
              name="radio buttons group"
              className="bp-btns-group group-type fullWidth"
              row
            >
              <FormControlLabel
                className="btn-form-type"
                control={<Radio value="radio03-01" />}
                label="사용"
              />
              <FormControlLabel
                className="btn-form-type"
                control={<Radio value="radio03-02" />}
                label="미사용"
              />
            </RadioGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
        <Grid xs={12}>
          <FormControl>
            <RadioGroup
              aria-labelledby="radio-buttons-group"
              defaultValue="radio01"
              name="radio buttons group"
              value={RadioValue02}
              onChange={handleChangeRadio02}
              className="bp-form-group"
            >
              <FormLabel
                className={`bp-label ${
                  RadioValue02 === "radio02-01" ? "is-active" : ""
                }`}
              >
                <Radio value="radio02-01" />
                <dl className="item-label">
                  <dt className="title">사용내역 제외</dt>
                  <dd>선택된 사용내역을 경비 처리 내역에서 제외처리합니다.</dd>
                </dl>
              </FormLabel>
              <FormLabel
                className={`bp-label ${
                  RadioValue02 === "radio02-02" ? "is-active" : ""
                }`}
              >
                <Radio value="radio02-02" />
                <dl className="item-label">
                  <dt className="title">사용내역 제외 해제</dt>
                  <dd>기존에 제외 처리된 항목을 해제합니다.</dd>
                </dl>
              </FormLabel>
            </RadioGroup>
            <FormHelperText>You can display an error</FormHelperText>
          </FormControl>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-6. [공통]기본 Switch</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Switch {...label} defaultChecked />
          <Switch {...label} />
          <Switch {...label} disabled defaultChecked />
          <Switch {...label} disabled />
        </Grid>
        <Grid xs={3}>
          <FormGroup>
            <FormControlLabel
              control={<Switch defaultChecked />}
              label="Label"
            />
            <FormControlLabel required control={<Switch />} label="Required" />
            <FormControlLabel disabled control={<Switch />} label="Disabled" />
          </FormGroup>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-7. [공통]검색</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack
            direction="row"
            spacing={1}
            className="bp-flex-group bp-search-group"
          >
            <div className="left">
              <TextField
                variant="filled"
                size="small"
                data-cy="searchBox"
                placeholder="그룹코드를 입력해 주세요."
                className="bp-search"
                fullWidth
                hiddenLabel
                value={filteredLocations}
                onChange={filterResults}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start" className="btn-groups">
                      <SearchSm
                        fontSize="medium"
                        className="bp-icon medium icon-search"
                      />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon />
                        </IconButton>
                      )}
                    </InputAdornment>
                  ),
                }}
              />
            </div>
            <div className="right">
              <Button variant="contained" size="large" fullWidth>
                검색
              </Button>
            </div>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <div className="search-area">
            <TextField
              variant="filled"
              size="medium"
              placeholder="검색어를 입력해 주세요."
              className="bp-search"
              fullWidth
              hiddenLabel
              value={filteredLocations}
              onChange={filterResults}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start" className="btn-groups">
                    <SearchSm
                      fontSize="medium"
                      className="bp-icon medium icon-search"
                    />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end" className="btn-groups">
                    {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                      <IconButton
                        size="small"
                        className="btn-clear"
                        onClick={clearSearch}
                      >
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    )}
                  </InputAdornment>
                ),
              }}
            />
          </div>
        </Grid>
        <Grid xs={12}>
          <Stack
            direction="row"
            spacing={1}
            className="search-area bp-flex-group bp-search-group"
          >
            <div className="left">
              <TextField
                variant="filled"
                size="medium"
                placeholder="검색어를 입력해 주세요."
                className="bp-search"
                data-cy="searchBox"
                fullWidth
                hiddenLabel
                value={filteredLocations}
                onChange={filterResults}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start" className="btn-groups">
                      <SearchSm className="icon-search" />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon />
                        </IconButton>
                      )}
                    </InputAdornment>
                  ),
                }}
              />
            </div>
            <div className="right">
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="flex-row">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="법인카드"
                  />
                  <FormControlLabel control={<Checkbox />} label="기타증빙" />
                  <FormControlLabel control={<Checkbox />} label="계산서" />
                </FormGroup>
              </FormControl>
            </div>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack
            direction="row"
            spacing={1}
            className="search-area bp-flex-group bp-search-group has-pick"
          >
            <div className="left">
              <Autocomplete
                includeInputInList
                size="medium"
                id="select1-1"
                className="label-fixed"
                fullWidth
                autoHighlight
                options={selectOption}
                renderInput={(params) => (
                  <FormControl fullWidth variant="filled" size="medium">
                    <InputLabel htmlFor="select1-1">상태</InputLabel>
                    <TextField
                      {...params}
                      label=""
                      required
                      placeholder="상태를 선택해 주세요."
                    />
                  </FormControl>
                )}
              />
              {/* 테스트 시 : open */}
            </div>
            <div className="right">
              <TextField
                variant="filled"
                size="medium"
                placeholder="검색어를 입력해 주세요."
                className="bp-search"
                data-cy="searchBox"
                fullWidth
                hiddenLabel
                value={filteredLocations}
                onChange={filterResults}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start" className="btn-groups">
                      <SearchSm className="icon-search" />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon />
                        </IconButton>
                      )}
                    </InputAdornment>
                  ),
                }}
              />
            </div>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <div className="bp-search-wrap">
            <Grid container spacing={2} className="search-grid search-grid-row">
              <Grid xs={3}>
                <dl className="item-data data-report type-row">
                  {/* [D]상하 중앙 정렬:type-valign-center */}
                  <dt>분류</dt>
                  <dd className="txt-data">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select1-1"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="전체"
                          {...params}
                          hiddenLabel
                        />
                      )}
                    />
                    {/* 테스트 시 : open */}
                  </dd>
                </dl>
              </Grid>
              <Grid xs={3}>
                <dl className="item-data data-report type-row">
                  {/* [D]상하 중앙 정렬:type-valign-center */}
                  <dt>상태</dt>
                  <dd className="txt-data">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select1-1"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="전체"
                          {...params}
                          hiddenLabel
                        />
                      )}
                    />
                    {/* 테스트 시 : open */}
                  </dd>
                </dl>
              </Grid>
              <Grid xs={6}>
                <dl className="item-data data-report type-row">
                  {/* [D]상하 중앙 정렬:type-valign-center */}
                  <dt>기간</dt>
                  <dd className="txt-data">
                    <Grid
                      container
                      spacing={2}
                      className="bp-grid-field field-date"
                    >
                      <Grid xs={6} className="bp-dash">
                        <div className="field-date-group">
                          <DatePicker
                            className="bp-datePicker size-small fullWidth"
                            format="yyyy/MM/dd"
                            slotProps={{
                              textField: {
                                //helperText: "YYYY/MM/DD",
                              },
                            }}
                            slots={{
                              openPickerIcon: Calendar,
                            }}
                          />
                          {/*  open */}
                        </div>
                      </Grid>
                      <Grid xs={6}>
                        <div className="field-date-group">
                          <DatePicker
                            className="bp-datePicker size-small fullWidth"
                            slotProps={{
                              textField: {
                                //helperText: "YYYY/MM/DD",
                              },
                            }}
                            slots={{
                              openPickerIcon: Calendar,
                            }}
                          />
                          {/*  open */}
                        </div>
                      </Grid>
                    </Grid>
                  </dd>
                </dl>
              </Grid>
            </Grid>
            <Grid container spacing={2} className="search-grid search-grid-row">
              <Grid xs={12}>
                <Stack
                  direction="row"
                  spacing={1}
                  className="bsearch-area bp-flex-group bp-search-box has-pick"
                >
                  <div className="left">
                    <dl className="item-data data-search type-row">
                      {/* [D]상하 중앙 정렬:type-valign-center */}
                      <dt className="ir">검색 선택</dt>
                      <dd className="txt-data data-before">
                        <Autocomplete
                          includeInputInList
                          size="small"
                          id="select1-1"
                          fullWidth
                          options={selectOption}
                          renderInput={(params) => (
                            <TextField
                              variant="filled"
                              size="small"
                              placeholder="제목"
                              {...params}
                              hiddenLabel
                            />
                          )}
                        />
                        {/* 테스트 시 : open */}
                      </dd>
                      <dd className="txt-data">
                        <TextField
                          variant="filled"
                          size="small"
                          data-cy="searchBox"
                          placeholder="검색내용을 입력하세요."
                          className="bp-search"
                          fullWidth
                          hiddenLabel
                          value={filteredLocations}
                          onChange={filterResults}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment
                                position="start"
                                className="btn-groups"
                              >
                                <SearchSm
                                  fontSize="medium"
                                  className="bp-icon medium icon-search"
                                />
                              </InputAdornment>
                            ),
                            endAdornment: (
                              <InputAdornment
                                position="end"
                                className="btn-groups"
                              >
                                {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                                  <IconButton
                                    size="small"
                                    className="btn-clear"
                                    onClick={clearSearch}
                                  >
                                    <CancelIcon />
                                  </IconButton>
                                )}
                              </InputAdornment>
                            ),
                          }}
                        />
                      </dd>
                    </dl>
                  </div>
                  <div className="right">
                    <Button
                      variant="outlined"
                      size="large"
                      className=""
                      startIcon={
                        <SearchSm
                          fontSize="small"
                          className="bp-icon small icon-search"
                        />
                      }
                      fullWidth
                    >
                      조회
                    </Button>
                  </div>
                </Stack>
              </Grid>
            </Grid>
          </div>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>4-8. [공통]Dropdown Nation</h3>
      <Grid container spacing={2}>
        <Grid xs={3}>
          <Box
            className={`btn-dropdown dropdown-nation ${writeOpen ? "is-open" : ""}`}
          >
            <Button
              variant="outlined"
              size="large"
              className="btn-xlarge btn-basic"
              fullWidth
              id="write-button"
              onClick={handleWriteOpen}
              ref={writeAnchorRef}
              aria-controls={writeOpen ? "write-menu" : undefined}
              aria-expanded={writeOpen ? "true" : undefined}
              aria-haspopup="true"
              endIcon={
                <ArrowDropDownOutlinedIcon
                  fontSize="small"
                  className="bp-icon small"
                />
              }
            >
              +82
            </Button>
            <Popper
              open={writeOpen}
              anchorEl={writeAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth dropdown-Division"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleWriteClose}>
                      <Scrollbar className="ui-scroll">
                        <MenuList
                          autoFocusItem={writeOpen}
                          id="write-menu"
                          aria-labelledby="write-button"
                          onKeyDown={handleListKeyDown}
                        >
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/KR.png"
                                  width={24}
                                  height={16}
                                  alt="대한민국(Republic of Korea) +82"
                                />
                              </span>
                              <span className="txt">
                                대한민국(Republic of Korea) +82
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/US.png"
                                  width={24}
                                  height={16}
                                  alt="미국(United States of America)
                                                  +1"
                                />
                              </span>
                              <span className="txt">
                                미국(United States of America) +1
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/CN.png"
                                  width={24}
                                  height={16}
                                  alt="중국(China) +86"
                                />
                              </span>
                              <span className="txt">중국(China) +86</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/JP.png"
                                  width={24}
                                  height={16}
                                  alt="일본(Japan) +81"
                                />
                              </span>
                              <span className="txt">일본(Japan) +81</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/VN.png"
                                  width={24}
                                  height={16}
                                  alt="베트남(Vietnam) +84"
                                />
                              </span>
                              <span className="txt">베트남(Vietnam) +84</span>
                            </div>
                          </MenuItem>
                        </MenuList>
                      </Scrollbar>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
        </Grid>
        <Grid xs={3}>
          <Box
            className={`btn-dropdown dropdown-nation ${writeOpen ? "is-open" : ""}`}
          >
            <Button
              variant="outlined"
              size="large"
              className="btn-basic"
              fullWidth
              id="write-button"
              onClick={handleWriteOpen}
              ref={writeAnchorRef}
              aria-controls={writeOpen ? "write-menu" : undefined}
              aria-expanded={writeOpen ? "true" : undefined}
              aria-haspopup="true"
              endIcon={
                <ArrowDropDownOutlinedIcon
                  fontSize="small"
                  className="bp-icon small"
                />
              }
            >
              +82
            </Button>
            <Popper
              open={writeOpen}
              anchorEl={writeAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth dropdown-Division"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleWriteClose}>
                      <Scrollbar className="ui-scroll">
                        <MenuList
                          autoFocusItem={writeOpen}
                          id="write-menu"
                          aria-labelledby="write-button"
                          onKeyDown={handleListKeyDown}
                        >
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/KR.png"
                                  width={24}
                                  height={16}
                                  alt="대한민국(Republic of Korea) +82"
                                />
                              </span>
                              <span className="txt">
                                대한민국(Republic of Korea) +82
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/US.png"
                                  width={24}
                                  height={16}
                                  alt="미국(United States of America)
                                                  +1"
                                />
                              </span>
                              <span className="txt">
                                미국(United States of America) +1
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/CN.png"
                                  width={24}
                                  height={16}
                                  alt="중국(China) +86"
                                />
                              </span>
                              <span className="txt">중국(China) +86</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/JP.png"
                                  width={24}
                                  height={16}
                                  alt="일본(Japan) +81"
                                />
                              </span>
                              <span className="txt">일본(Japan) +81</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/VN.png"
                                  width={24}
                                  height={16}
                                  alt="베트남(Vietnam) +84"
                                />
                              </span>
                              <span className="txt">베트남(Vietnam) +84</span>
                            </div>
                          </MenuItem>
                        </MenuList>
                      </Scrollbar>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
        </Grid>
        <Grid xs={3}>
          <Box
            className={`btn-dropdown dropdown-nation ${writeOpen ? "is-open" : ""}`}
          >
            <Button
              variant="outlined"
              size="medium"
              className="btn-basic"
              fullWidth
              id="write-button"
              onClick={handleWriteOpen}
              ref={writeAnchorRef}
              aria-controls={writeOpen ? "write-menu" : undefined}
              aria-expanded={writeOpen ? "true" : undefined}
              aria-haspopup="true"
              endIcon={
                <ArrowDropDownOutlinedIcon
                  fontSize="small"
                  className="bp-icon small"
                />
              }
            >
              +82
            </Button>
            <Popper
              open={writeOpen}
              anchorEl={writeAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth dropdown-Division"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleWriteClose}>
                      <Scrollbar className="ui-scroll">
                        <MenuList
                          autoFocusItem={writeOpen}
                          id="write-menu"
                          aria-labelledby="write-button"
                          onKeyDown={handleListKeyDown}
                        >
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/KR.png"
                                  width={24}
                                  height={16}
                                  alt="대한민국(Republic of Korea) +82"
                                />
                              </span>
                              <span className="txt">
                                대한민국(Republic of Korea) +82
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/US.png"
                                  width={24}
                                  height={16}
                                  alt="미국(United States of America)
                                                  +1"
                                />
                              </span>
                              <span className="txt">
                                미국(United States of America) +1
                              </span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/CN.png"
                                  width={24}
                                  height={16}
                                  alt="중국(China) +86"
                                />
                              </span>
                              <span className="txt">중국(China) +86</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/JP.png"
                                  width={24}
                                  height={16}
                                  alt="일본(Japan) +81"
                                />
                              </span>
                              <span className="txt">일본(Japan) +81</span>
                            </div>
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            <div className="nation-box">
                              <span className="flag">
                                <img
                                  src="/assets/nation-image/VN.png"
                                  width={24}
                                  height={16}
                                  alt="베트남(Vietnam) +84"
                                />
                              </span>
                              <span className="txt">베트남(Vietnam) +84</span>
                            </div>
                          </MenuItem>
                        </MenuList>
                      </Scrollbar>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default Forms;
