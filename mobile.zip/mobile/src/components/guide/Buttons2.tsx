import { HelpOutline, KeyboardReturn, LinkOff } from "@mui/icons-material";
import AddOutlinedIcon from "@mui/icons-material/AddOutlined";
import AltRouteOutlinedIcon from "@mui/icons-material/AltRouteOutlined";
import AltRouteRoundedIcon from "@mui/icons-material/AltRouteRounded";
import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";
import CachedIcon from "@mui/icons-material/Cached";
import CloseIcon from "@mui/icons-material/Close";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import HorizontalRuleOutlinedIcon from "@mui/icons-material/HorizontalRuleOutlined";
import LeaderboardOutlinedIcon from "@mui/icons-material/LeaderboardOutlined";
import ListAltRoundedIcon from "@mui/icons-material/ListAltRounded";
import PieChartOutlineIcon from "@mui/icons-material/PieChartOutline";
import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";
import {
  Box,
  Button,
  ClickAwayListener,
  Grow,
  IconButton,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  ToggleButton,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import {
  ArrowLeft,
  Bookmark,
  Building05,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ClipboardCheck,
  Clock,
  Columns02,
  Copy06,
  Download01,
  Download02,
  Edit02,
  Edit05,
  Expand01,
  FileAttachment04,
  FileCheck01,
  FileSearch02,
  FolderPlus,
  Image03,
  InfoCircle,
  Link03,
  LinkExternal01,
  Loading01,
  MessageAlertCircle,
  Minus,
  MinusCircle,
  Paperclip,
  PauseCircle,
  PencilLine,
  Printer,
  RefreshCcw01,
  RefreshCcw04,
  ReverseLeft,
  Settings02,
  Settings04,
  Share07,
  StickerCircle,
  Trash02,
  Upload01,
  UserCheck01,
  UserPlus01,
  Users03,
  XCircle,
  XSquare,
} from "@untitled-ui/icons-react";
import FilterFunnel01 from "@untitled-ui/icons-react/build/esm/FilterFunnel01";
import Plus from "@untitled-ui/icons-react/build/esm/Plus";
import React, { useEffect, useRef, useState } from "react";
import styles from "./Guide.module.css";

const Buttons2 = (props) => {
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState(false);
  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const [modifyOpen, setModifyOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);
  const modifyAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleModifyOpen = () => {
    setModifyOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  const handleModifyClose = (event: Event | React.SyntheticEvent) => {
    if (
      modifyAnchorRef.current &&
      modifyAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setModifyOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
      setModifyOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
      setModifyOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);

  // return focus to the button when we transitioned from !open -> open
  const prevModifyOpen = useRef(modifyOpen);
  useEffect(() => {
    if (prevModifyOpen.current === true && modifyOpen === false) {
      modifyAnchorRef.current!.focus();
    }
    prevModifyOpen.current = modifyOpen;
  }, [modifyOpen]);

  return (
    <>
      <h3 className={styles.heading3}>3-1. [공통]기본 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={6}>
          <Button size="small">Text Small</Button>
          <Button size="medium">Text Medium</Button>
          <Button size="large">Text Large</Button>
          <Button size="large" className="btn-xlarge">
            Text xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="outlined" size="small">
            Outlined Small
          </Button>
          <Button variant="outlined" size="medium">
            Outlined Medium
          </Button>
          <Button variant="outlined" size="large">
            Outlined Large
          </Button>
          <Button variant="outlined" size="large" className="btn-xlarge">
            Outlined xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="contained" size="small">
            Contained Small
          </Button>
          <Button variant="contained" size="medium">
            Contained Medium
          </Button>
          <Button variant="contained" size="large">
            Contained Large
          </Button>
          <Button variant="contained" size="large" className="btn-xlarge">
            Contained xLarge
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button variant="outlined" disabled>
            Disabled
          </Button>
          <Button variant="outlined" href="#none">
            Link
          </Button>
        </Grid>
        <Grid xs={12}>
          <Button variant="contained" size="medium" fullWidth>
            100%넓이 버튼
          </Button>
        </Grid>
        <Grid xs={12}>
          <Button size="medium" color="primary">
            등록
          </Button>
          <Button size="medium" color="primary">
            수정
          </Button>
          <Button size="medium" color="primary">
            임시저장
          </Button>
          <Button size="medium" className="btn-text-primary">
            취소
          </Button>
          <Button size="medium" className="btn-text-secondary">
            취소
          </Button>
          <Button size="medium" color="error">
            초기화/삭제
          </Button>
          <Button variant="contained" size="medium">
            저장/확인/완료/선택완료/적용/결재요청
          </Button>
          <Button variant="outlined" size="medium">
            설정/상세설정
          </Button>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>3-2. [공통]버튼+아이콘 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <ArrowLeft fontSize="small" className="bp-icon xsmall" />
            }
          >
            뒤로가기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Download02 fontSize="small" className="bp-icon xsmall" />
            }
          >
            저장/다운로드/양식 다운로드/양식 다운로드(신규)/양식 다운로드(기존
            자료 포함)
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Bookmark fontSize="small" className="bp-icon xsmall" />}
          >
            보관
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Printer fontSize="small" className="bp-icon xsmall" />}
          >
            인쇄
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Edit02 fontSize="small" className="bp-icon xsmall" />}
          >
            결의서 작성/수정/양식수정/그룹관리
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <FilterFunnel01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            기본 필터
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Settings02 fontSize="small" className="bp-icon xsmall" />
            }
          >
            상세 필터/설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <StickerCircle fontSize="small" className="bp-icon xsmall" />
            }
          >
            메모
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Settings04 fontSize="small" className="bp-icon xsmall" />
            }
          >
            보기설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <RefreshCcw01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            초기화/최신정보 불러오기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <MinusCircle fontSize="small" className="bp-icon xsmall" />
            }
          >
            제외/해제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Upload01 fontSize="small" className="bp-icon xsmall" />}
          >
            업로드
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Image03 fontSize="small" className="bp-icon xsmall" />}
          >
            이미지 첨부
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Share07 fontSize="small" className="bp-icon xsmall" />}
          >
            회람
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <UserPlus01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            임시담당자 지정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Building05 fontSize="small" className="bp-icon xsmall" />
            }
          >
            회사정보
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Users03 fontSize="small" className="bp-icon xsmall" />}
          >
            직원조회
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Plus fontSize="small" className="bp-icon xsmall" />}
          >
            추가/행추가
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Minus fontSize="small" className="bp-icon xsmall" />}
          >
            삭제/행제거
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Trash02 fontSize="small" className="bp-icon xsmall" />}
          >
            삭제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Clock fontSize="small" className="bp-icon xsmall" />}
          >
            마감/해제
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <ApprovalRoundedIcon
                fontSize="small"
                className="bp-icon xsmall"
              />
            }
          >
            결재/접수결재
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Expand01 fontSize="small" className="bp-icon xsmall" />}
          >
            증빙내역 펼치기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<XCircle fontSize="small" className="bp-icon xsmall" />}
          >
            상신취소
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<XSquare fontSize="small" className="bp-icon xsmall" />}
          >
            최종결재취소
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <PencilLine fontSize="small" className="bp-icon xsmall" />
            }
          >
            재기안
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <FileSearch02 fontSize="small" className="bp-icon xsmall" />
            }
          >
            거래처 불러오기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Download01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            일괄입력
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <AltRouteOutlinedIcon
                fontSize="small"
                className="bp-icon xsmall"
              />
            }
          >
            분할
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <WifiProtectedSetupOutlinedIcon
                fontSize="small"
                className="bp-icon xsmall"
              />
            }
          >
            국세청 가져오기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <FolderPlus fontSize="small" className="bp-icon xsmall" />
            }
          >
            카드그룹 생성
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <MessageAlertCircle fontSize="small" className="bp-icon xsmall" />
            }
          >
            결재의견
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <ClipboardCheck fontSize="small" className="bp-icon xsmall" />
            }
          >
            결재정보
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <RefreshCcw04 fontSize="small" className="bp-icon xsmall" />
            }
          >
            결재선 변경
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <FileCheck01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            양식선택
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <Columns02 fontSize="small" className="bp-icon xsmall" />
            }
          >
            결재란 설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <UserCheck01 fontSize="small" className="bp-icon xsmall" />
            }
          >
            양식별 결재선 설정
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Copy06 fontSize="small" className="bp-icon xsmall" />}
          >
            양식복사
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <ReverseLeft fontSize="small" className="bp-icon xsmall" />
            }
          >
            반려
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <CachedIcon fontSize="small" className="bp-icon small" />
            }
          >
            상태 변경하기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <ListAltRoundedIcon fontSize="small" className="bp-icon small" />
            }
          >
            보관함 선택
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={<Loading01 fontSize="small" className="bp-icon small" />}
          >
            대기
          </Button>
          <Button
            size="small"
            className="btn-text-primary"
            startIcon={
              <PauseCircle fontSize="small" className="bp-icon small" />
            }
          >
            계정 이용 중지
          </Button>
          <Button
            size="small"
            color="primary"
            startIcon={
              <AddOutlinedIcon fontSize="small" className="bp-icon xsmall" />
            }
          >
            대상 추가
          </Button>
          <Button
            size="medium"
            color="primary"
            className="btn-view"
            endIcon={
              <ArrowForwardIosRoundedIcon
                fontSize="small"
                className="bp-icon xsmall"
              />
            }
          >
            전체 보기
          </Button>
          <Button
            variant="contained"
            size="large"
            className=""
            endIcon={
              <ArrowForwardIosRoundedIcon
                fontSize="small"
                className="bp-icon xsmall"
              />
            }
          >
            설정하기
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={
              <DashboardCustomizeOutlinedIcon
                fontSize="small"
                className="bp-icon small"
              />
            }
          >
            위젯설정
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={
              <RefreshCcw01 fontSize="small" className="bp-icon small" />
            }
          >
            새로고침
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<Plus fontSize="small" className="bp-icon small" />}
          >
            추가
          </Button>
          <Button variant="contained" size="small">
            추가(서브)
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<Plus fontSize="small" className="bp-icon small" />}
          >
            등록
          </Button>
          <Button
            variant="contained"
            size="medium"
            className=""
            startIcon={<Edit02 fontSize="small" className="bp-icon small" />}
          >
            작성
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<Edit02 fontSize="small" className="bp-icon small" />}
          >
            수정
          </Button>
          <Button variant="outlined" size="small">
            수정(서브)
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={
              <Settings02 fontSize="small" className="bp-icon small" />
            }
          >
            설정
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={
              <Settings02 fontSize="small" className="bp-icon small" />
            }
          >
            상세설정
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<Plus fontSize="small" className="bp-icon small" />}
          >
            용도/대상/예산
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-file"
            startIcon={<Paperclip fontSize="small" className="bp-icon small" />}
          >
            파일
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={<Plus fontSize="small" className="bp-icon small" />}
          >
            그룹추가
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className=""
            startIcon={
              <FileAttachment04 fontSize="small" className="bp-icon small" />
            }
          >
            원안문서
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-basic"
            startIcon={
              <Download02 fontSize="small" className="bp-icon small" />
            }
          >
            다운
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-basic"
            startIcon={<Link03 fontSize="small" className="bp-icon small" />}
          >
            연결
          </Button>
          <Button
            variant="outlined"
            size="medium"
            className="btn-basic"
            startIcon={
              <CachedIcon fontSize="small" className="bp-icon small" />
            }
          >
            상태 변경하기
          </Button>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>3-3. [공통]아이콘 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <IconButton
            className="btn-icon-only btn-circle btn-bg-fill-reverse"
            size="small"
            color="primary"
            aria-label="추가"
          >
            <AddOutlinedIcon fontSize="small" className="bp-icon small" />
          </IconButton>
          <IconButton
            className="btn-icon-only btn-circle btn-bg-fill-reverse"
            size="small"
            color="error"
            aria-label="제거"
          >
            <HorizontalRuleOutlinedIcon
              fontSize="small"
              className="bp-icon small"
            />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="뒤로가기"
          >
            <ArrowLeft fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="저장/다운로드"
          >
            <Download02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="보관">
            <Bookmark fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="인쇄">
            <Printer fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결의서 작성/수정/양식수정"
          >
            <Edit02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="필터">
            <FilterFunnel01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="상세 필터/설정"
          >
            <Settings02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="메모">
            <StickerCircle fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="보기설정"
          >
            <Settings04 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="제외/해제"
          >
            <MinusCircle fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="업로드"
          >
            <Upload01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="이미지 첨부"
          >
            <Image03 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="회람">
            <Share07 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="임시담당자 지정"
          >
            <UserPlus01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="회사정보"
          >
            <Building05 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="직원조회"
          >
            <Users03 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="추가/행추가"
          >
            <Plus fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="삭제/행제거"
          >
            <Minus fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="삭제">
            <Trash02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="마감/해제"
          >
            <Clock fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결재/접수결재"
          >
            <ApprovalRoundedIcon fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="증빙내역 펼치기"
          >
            <Expand01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="상신취소"
          >
            <XCircle fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="재기안"
          >
            <PencilLine fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="최종결재취소"
          >
            <XSquare fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="거래처 불러오기"
          >
            <FileSearch02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="초기화"
          >
            <RefreshCcw01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="일괄입력"
          >
            <Download01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="분할">
            <AltRouteRoundedIcon fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="국세청 가져오기"
          >
            <WifiProtectedSetupOutlinedIcon
              fontSize="small"
              className="bp-icon xsmall"
            />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="카드그룹 생성"
          >
            <FolderPlus fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결재의견"
          >
            <MessageAlertCircle fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결재정보"
          >
            <ClipboardCheck fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결재선 변경"
          >
            <RefreshCcw04 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="양식선택"
          >
            <FileCheck01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="결재란 설정"
          >
            <Columns02 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="양식별 결재선 설정"
          >
            <UserCheck01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="양식복사"
          >
            <Copy06 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="최신정보 불러오기"
          >
            <RefreshCcw01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="파일">
            <Paperclip fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="아래로"
          >
            <ChevronDown fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="위로">
            <ChevronUp fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="연결">
            <Link03 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="편집">
            <Edit05 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="되돌리기"
          >
            <KeyboardReturn
              fontSize="small"
              className="bp-icon xsmall"
              color="error"
            />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="설명">
            <HelpOutline fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="설명">
            <InfoCircle fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="이전">
            <ChevronLeft fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="다음">
            <ChevronRight fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="닫기">
            <CloseIcon fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="해지">
            <Loading01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
          <IconButton
            className="btn-icon-only btn-chart is-active"
            size="small"
            aria-label="Bar Chart"
          >
            <LeaderboardOutlinedIcon
              fontSize="small"
              className="bp-icon small"
            />
          </IconButton>
          {/* [D]선택시:is-active */}
          <IconButton
            className="btn-icon-only btn-chart"
            size="small"
            aria-label="Pie Chart"
          >
            <PieChartOutlineIcon fontSize="small" className="bp-icon small" />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="취소">
            <XCircle
              fontSize="small"
              className="bp-icon xsmall"
              color="error"
            />
          </IconButton>
          <IconButton className="btn-icon-only" size="small" aria-label="해지">
            <LinkOff fontSize="small" className="bp-icon small" color="error" />
          </IconButton>
          <IconButton
            className="btn-icon-only"
            size="small"
            aria-label="내보내기"
          >
            <LinkExternal01 fontSize="small" className="bp-icon xsmall" />
          </IconButton>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>3-4. [공통]Toggle 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <ToggleButton
            value="check"
            selected={selected}
            onChange={() => {
              setSelected(!selected);
            }}
            className="btn-icon-toggle icon-bookmark"
          >
            <StarRateRoundedIcon fontSize="medium" />
          </ToggleButton>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>3-5. [공통]Dropdown 버튼</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Box className="btn-dropdown">
            <Button
              variant="contained"
              size="medium"
              id="write-button"
              onClick={handleWriteOpen}
              ref={writeAnchorRef}
              aria-controls={writeOpen ? "write-menu" : undefined}
              aria-expanded={writeOpen ? "true" : undefined}
              aria-haspopup="true"
              startIcon={<Edit02 fontSize="small" className="bp-icon xsmall" />}
              endIcon={
                <ChevronDown fontSize="small" className="bp-icon xsmall" />
              }
            >
              작성/수정(타이틀 영역에서 사용)
            </Button>
            <Popper
              open={writeOpen}
              anchorEl={writeAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleWriteClose}>
                      <MenuList
                        autoFocusItem={writeOpen}
                        id="write-menu"
                        aria-labelledby="write-button"
                        onKeyDown={handleListKeyDown}
                      >
                        <MenuItem onClick={handleWriteClose}>단건등록</MenuItem>
                        <MenuItem onClick={handleWriteClose}>일괄등록</MenuItem>
                      </MenuList>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
          <Box className="btn-dropdown">
            <Button
              variant="outlined"
              size="medium"
              id="modify-button"
              onClick={handleModifyOpen}
              ref={modifyAnchorRef}
              aria-controls={modifyOpen ? "modify-menu" : undefined}
              aria-expanded={modifyOpen ? "true" : undefined}
              aria-haspopup="true"
              startIcon={<Edit02 fontSize="small" className="bp-icon xsmall" />}
              endIcon={
                <ChevronDown fontSize="small" className="bp-icon xsmall" />
              }
            >
              작성/수정
            </Button>
            <Popper
              open={modifyOpen}
              anchorEl={modifyAnchorRef.current}
              role={undefined}
              placement="bottom-start"
              transition
              disablePortal
              className="popper-dropdown fullWidth"
            >
              {({ TransitionProps, placement }) => (
                <Grow
                  {...TransitionProps}
                  style={{
                    transformOrigin:
                      placement === "bottom-start" ? "left top" : "left bottom",
                  }}
                >
                  <Paper>
                    <ClickAwayListener onClickAway={handleModifyClose}>
                      <MenuList
                        autoFocusItem={modifyOpen}
                        id="modify-menu"
                        aria-labelledby="modify-button"
                        onKeyDown={handleListKeyDown}
                      >
                        <MenuItem onClick={handleModifyClose}>
                          수정하기
                        </MenuItem>
                        <MenuItem onClick={handleModifyClose}>
                          분할하기
                        </MenuItem>
                        <MenuItem onClick={handleModifyClose}>
                          세액수정
                        </MenuItem>
                      </MenuList>
                    </ClickAwayListener>
                  </Paper>
                </Grow>
              )}
            </Popper>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default Buttons2;
