import { Close } from "@mui/icons-material";
import {
  Avatar,
  Box,
  IconButton,
  List,
  ListItem,
  Typography,
} from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import {
  Briefcase02,
  Building05,
  Bus,
  ChevronRight,
  CreditCardEdit,
  Dotpoints01,
  Edit03,
  Edit05,
  File02,
  File05,
  Menu04,
  Percent03,
  Plane,
  ReceiptCheck,
  Settings02,
  Train,
  UserCircle,
  UserEdit,
} from "@untitled-ui/icons-react";
import { ReactNode, useState } from "react";
import { Link } from "react-router-dom";

interface AllMenuDrawerProps {
  children?: ReactNode;
}
const AllMenuDrawer = (props: AllMenuDrawerProps) => {
  // [Drawer]
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    drawer1: false,
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (event && (event.key === "Tab" || event.key === "Shift")) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  return (
    <>
      {/* 상단 사이드 메뉴 */}
      <IconButton
        onClick={toggleDrawer("drawer1", true)}
        className="btn-icon-only"
        size="medium"
        aria-label="전체메뉴"
      >
        <Menu04 fontSize="medium" />
      </IconButton>
      <SwipeableDrawer
        anchor="right"
        open={isDrawerOpen.drawer1}
        onClose={toggleDrawer("drawer1", false)}
        onOpen={toggleDrawer("drawer1", true)}
        className="bp-drawer drawer-right bp-allmenu"
      >
        <div className="drawer-header" id="drawer-header">
          <div className="inner">
            <Box className="left-area">
              <Typography variant="h2">전체메뉴</Typography>
            </Box>
            <Box className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="설정"
              >
                <Settings02 fontSize="small" className="bp-icon" />
              </IconButton>
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={toggleDrawer("drawer1", false)}
              >
                <Close fontSize="small" className="bp-icon" />
              </IconButton>
            </Box>
          </div>
        </div>
        <Box className="drawer-body ui-scroll" sx={{}}>
          <Box className="drawer-cont">
            {/* [S]allmenu-wrap */}
            <div className="allmenu-wrap">
              {/* [S]user profile */}
              <div className="item-field">
                <div className="inner-sides">
                  <dl className="item-user-info">
                    <dt className="photo">
                      <Avatar
                        alt="최현대"
                        src="/assets/images/tmp-profile2.png"
                        className="user-avatar"
                      />
                    </dt>
                    <dd>
                      <div className="user-info-row">
                        <div className="user-name">최현대 과장(1341341)</div>
                      </div>
                      <div className="user-info-row">
                        <div className="user-team">라이프디자인팀 (TBCM-1)</div>
                      </div>
                    </dd>
                  </dl>
                  <div className="right-area">
                    <IconButton>
                      <ChevronRight className="bp-icon" />
                    </IconButton>
                  </div>
                </div>
              </div>
              {/* [E]user profile */}

              {/* [S]direct-link */}
              {/* [S]아이콘 추가 240912 kjs */}
              <div className="item-field">
                <div className="direct-link-list all-menu-lst">
                  {/* all-menu-lst 클래스 추가 240912 kjs */}
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <File05 color="active" className="medium" />
                      <Box className="txt">출장계획 내역</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <CreditCardEdit
                        color="--color-secondary"
                        className="medium"
                      />
                      <Box className="txt">예약/결제내역</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <ReceiptCheck color="active" className="medium" />
                      <Box className="txt">출장정산서 목록</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <UserCircle color="active" className="medium" />
                      <Box className="txt">마이페이지</Box>
                    </Link>
                  </div>
                </div>
                <div className="menu-link-list"></div>
              </div>
              {/* [E]아이콘 추가 240912 kjs */}
              {/* [E]direct-link */}

              {/* [S]menu-list depth-link */}
              {/* [S]전체적으로 문구 + 카테고리 추가 240912 kjs */}
              <div className="menu-list depth-link-list">
                <List className="depth1">
                  {/* <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">국내출장</Box>
                    </Link>
                  </ListItem> */}

                  {/* [S]아이콘 추가 241002 kjs */}
                  <ListItem className="item">
                    <Box className="item-menu">
                      <Box className="txt">출장 계획</Box>
                    </Box>
                    <List className="depth2">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <File02 className="bp-icon medium" />
                          <Box className="txt">출장계획서 목록</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Edit05 className="bp-icon medium" />
                          <Box className="txt">출장계획서 작성</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <UserEdit className="bp-icon medium" />
                          <Box className="txt">출장계획서 대리작성</Box>
                        </Link>
                      </ListItem>
                      {/* [S]메뉴 아이콘 추가 241004 kjs */}
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Dotpoints01 className="bp-icon medium" />
                          <Box className="txt">부서 출장계획서 목록</Box>
                        </Link>
                      </ListItem>
                      {/* [E]메뉴 아이콘 추가 241004 kjs */}
                    </List>
                  </ListItem>
                  <ListItem className="item">
                    <Box className="item-menu">
                      <Box className="txt">상품 예약</Box>
                    </Box>
                    <List className="depth2">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Building05 className="bp-icon medium" />
                          <Box className="txt">숙박</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Train className="bp-icon medium" />
                          <Box className="txt">열차</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Bus className="bp-icon medium" />
                          <Box className="txt">고속버스</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Plane className="bp-icon medium" />
                          <Box className="txt">항공</Box>
                        </Link>
                      </ListItem>
                    </List>
                  </ListItem>
                  <ListItem className="item">
                    <Box className="item-menu">
                      <Box className="txt">출장 정산</Box>
                    </Box>
                    <List className="depth2">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Percent03 className="bp-icon medium" />
                          <Box className="txt">출장정산서 목록</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Edit03 className="bp-icon medium" />
                          <Box className="txt">출장정산서 작성</Box>
                        </Link>
                      </ListItem>
                    </List>
                  </ListItem>

                  <ListItem className="item">
                    <Box className="item-menu">
                      <Box className="txt">대메뉴명</Box>
                    </Box>
                    <List className="depth2">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Briefcase02 className="bp-icon medium" />
                          {/* 기본 아이콘 */}
                          <Box className="txt">소메뉴명</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Briefcase02 className="bp-icon medium" />
                          {/* 기본 아이콘 */}
                          <Box className="txt">소메뉴명</Box>
                        </Link>
                      </ListItem>
                    </List>
                  </ListItem>
                  {/* [E]아이콘 추가 241002 kjs */}
                </List>
              </div>
              {/* [E]전체적으로 문구 + 카테고리 추가 240912 kjs */}
              {/* [E]menu-list depth-link */}

              {/* [S]menu-list footer-link */}
              <div className="menu-list footer-link-list">
                <List className="depth1">
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">출장비 지급 규정안내</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">공지사항</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">FAQ</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">1:1 문의하기</Box>
                    </Link>
                  </ListItem>
                </List>
              </div>
              {/* [E]menu-list footer-link */}

              {/* [S]menu-list security-link */}
              <div className="menu-list security-link-list">
                <List className="depth1">
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">이용약관</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">개인정보처리방침</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">시스템 공지</Box>
                      {/* [S]전체적으로 문구 + 카테고리 추가 240912 kjs */}
                    </Link>
                  </ListItem>
                </List>
              </div>
              {/* [E]menu-list security-link */}
            </div>
            {/* [E]allmenu-wrap */}
          </Box>
        </Box>
      </SwipeableDrawer>
    </>
  );
};

export default AllMenuDrawer;
