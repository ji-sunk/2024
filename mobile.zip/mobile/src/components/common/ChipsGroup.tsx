import { Chip, IconButton } from "@mui/material";

const ChipsGroup = () => (
  <>
    <div className="chips-group">
      <Chip label="BEST" size="small" variant="outlined" className="bp-chip" />
      <Chip
        label="작성문서/결재요청/정산신청서"
        size="medium"
        variant="outlined"
        className="bp-chip color-blue-lightest"
      />
      <Chip
        label="결재진행/승인완료"
        size="small"
        color="success"
        className="bp-chip color-twotone color-success"
      />
      <Chip
        label="결재완료"
        size="small"
        color="info"
        className="bp-chip color-twotone color-info"
      />
      <Chip
        label="교통"
        size="small"
        color="info"
        variant="outlined"
        className="bp-chip color-twotone color-info"
      />
      <Chip
        label="결재반려"
        size="small"
        color="error"
        className="bp-chip color-twotone color-error"
      />
      <Chip
        label="일비"
        size="small"
        color="error"
        variant="outlined"
        className="bp-chip color-twotone color-error"
      />
      <Chip
        label="승인대기/결재대기/결재요청/미작성"
        size="small"
        color="warning"
        className="bp-chip color-twotone color-warning"
      />
      <Chip
        label="유류/유류비"
        size="small"
        color="warning"
        variant="outlined"
        className="bp-chip color-twotone color-warning"
      />
      <Chip label="임시저장" size="small" color="default" className="bp-chip" />
      <Chip
        label="승인 취소"
        size="small"
        color="default"
        className="bp-chip color-twotone"
      />
      <Chip
        label="출장 취소"
        size="small"
        color="default"
        className="bp-chip color-twotone color-dark"
      />
      <Chip
        label="출장 초대"
        size="small"
        color="warning"
        className="bp-chip"
      />
      <Chip
        label="동반 신청"
        size="small"
        color="success"
        className="bp-chip"
      />
      <Chip label="출장종료" size="small" color="info" className="bp-chip" />
      <Chip label="답변완료" size="small" color="info" className="bp-chip" />
      <Chip label="예약완료" size="small" className="bp-chip color-blue" />

      <Chip
        label="로그인 정상"
        size="small"
        color="primary"
        className="bp-chip"
      />
      <Chip label="출장중" size="small" color="primary" className="bp-chip" />
      <Chip label="결재요청" size="small" color="error" className="bp-chip" />
      <Chip label="D-17" size="small" color="success" className="bp-chip" />
      <Chip label="동반신청" size="small" className="bp-chip color-indigo" />
      <Chip
        label="출장비회수요청"
        size="small"
        color="warning"
        className="bp-chip"
      />
      {/* [S] 출장의견 아이콘 추가 /chips-group 안에 위치해야 함 241002  kjs */}
      <IconButton className="icon-cmd">
        <img src="/assets/images/icons/Icon-cmnt-red.svg" alt="의견" />
      </IconButton>
      {/* [E] 출장의견 아이콘 추가 /chips-group 안에 위치해야 함 241002 kjs */}
    </div>
  </>
);

export default ChipsGroup;
