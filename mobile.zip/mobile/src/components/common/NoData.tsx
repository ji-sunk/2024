import { WarningRounded } from "@mui/icons-material";
import { Box } from "@mui/material";
import { FC } from "react";

type NoDataProps = {};
const NoData: FC<NoDataProps> = () => {
  return (
    <>
      <div className="no-data">
        <div className="message-group">
          <WarningRounded fontSize="large" className="bp-icon xlarge" />
          <Box className="message">
            검색 결과가 없습니다.
            <br />더 이상 내역이 없습니다.
            <br />
            이용내역이 없습니다.
            {/* 등록된 카드가 없습니다. */}
          </Box>
          {/* <Box className="message text-small">
            조회하실 카드를 등록 후 이용해주시기 바랍니다.
          </Box> */}
        </div>
      </div>
    </>
  );
};

export default NoData;
