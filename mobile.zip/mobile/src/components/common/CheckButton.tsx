import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
} from "@mui/material";
import { FC } from "react";

type CheckButtonProps = {};
const CheckButton: FC<CheckButtonProps> = () => {
  return (
    <>
      <FormControl
        component="fieldset"
        variant="standard"
        className="fullWidth"
      >
        <FormGroup className="bp-btns-group fullWidth type-thirds" row>
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.01(월)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.02(화)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.03(수)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.04(목)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.05(금)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.06(토)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.07(일)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.08(월)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.09(화)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.10(수)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.11(목)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.12(금)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.13(토)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.14(일)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.15(MON)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.16(TUE)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.17(WED)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.18(THU)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.19(FRI)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.20(SAT)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.21(SUN)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.22(월)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.23(화)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox defaultChecked />}
            label={<Box className="txt-label">2024.01.24(수)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.25(목)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.26(금)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.27(토)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.28(일)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.29(월)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.30(화)</Box>}
          />
          <FormControlLabel
            className="btn-form-type"
            // disabled
            control={<Checkbox />}
            label={<Box className="txt-label">2024.01.31(수)</Box>}
          />
        </FormGroup>
        {/* <FormHelperText>You can display an error</FormHelperText> */}
      </FormControl>
    </>
  );
};

export default CheckButton;
