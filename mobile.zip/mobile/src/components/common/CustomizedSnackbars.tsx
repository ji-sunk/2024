import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { Alert, Button, Snackbar } from "@mui/material";
import Fade from "@mui/material/Fade";
import Slide, { SlideProps } from "@mui/material/Slide";
import { TransitionProps } from "@mui/material/transitions";
import { CheckCircle } from "@untitled-ui/icons-react";
import * as React from "react";
import { useEffect, useRef, useState } from "react";

const CustomizedSnackbars = () => {
  const [state, setState] = React.useState({
    snackbar1: {
      open: false,
      Transition: Fade,
    },
    snackbar2: {
      open: false,
      Transition: Fade,
    },
  });

  const [selected, setSelected] = React.useState(false);

  function SlideTransition1(props: SlideProps) {
    return <Slide {...props} direction="up" />;
  }
  const handleClick =
    (
      snackbarId: string,
      Transition: React.ComponentType<
        TransitionProps & {
          children: React.ReactElement<any, any>;
        }
      >,
    ) =>
    () => {
      setState((prev) => {
        return {
          ...prev,
          [snackbarId]: {
            open: true,
            Transition,
          },
        };
      });
    };

  const handleClose = (snackbarId: string) => {
    setState((prev) => {
      return {
        ...prev,
        [snackbarId]: {
          open: false,
          Transition: prev[snackbarId].Transition,
        },
      };
    });
  };
  // [snackbar]alert
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    drawerAlert1: false, //Alert
    drawerAlert2: false, //Alert
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);

  return (
    <>
      <div>
        <Button onClick={handleClick("snackbar1", SlideTransition1)}>
          [snackbar-alert-simple] error - 입력하신 금액이 결제 비용보다 큼
        </Button>
        <Snackbar
          className="snackbar-alert alert-simple"
          TransitionComponent={state.snackbar1.Transition}
          open={state.snackbar1.open}
          onClose={() => handleClose("snackbar1")}
          message=""
          key={state.snackbar1.Transition.name}
          autoHideDuration={2500}
        >
          <Alert
            severity="error"
            className="bp-alert alert-error"
            icon={
              <InfoOutlinedIcon fontSize="medium" className="bp-icon medium" />
            }
          >
            <div className="alert-header">
              <div className="left">
                <h1 className="title">입력하신 금액이 결제 비용보다 큽니다.</h1>
              </div>
              <div className="right"></div>
            </div>
          </Alert>
        </Snackbar>
      </div>

      <div>
        <Button onClick={handleClick("snackbar2", SlideTransition1)}>
          [snackbar-alert-simple] success : 카드등록이 완료
        </Button>
        <Snackbar
          className="snackbar-alert alert-simple"
          TransitionComponent={state.snackbar2.Transition}
          open={state.snackbar2.open}
          onClose={() => handleClose("snackbar2")}
          message=""
          key={state.snackbar2.Transition.name}
          autoHideDuration={2500}
        >
          <Alert
            severity="success"
            className="bp-alert alert-success"
            icon={<CheckCircle fontSize="medium" className="bp-icon medium" />}
          >
            <div className="alert-header">
              <div className="left">
                <h1 className="title">카드등록이 완료되었습니다.</h1>
              </div>
              <div className="right"></div>
            </div>
          </Alert>
        </Snackbar>
      </div>

      <div>
        <Button onClick={toggleDrawer("drawerAlert1", true)}>
          [snackbar-alert] error - 출장일정 종료 안내
        </Button>
        <Snackbar
          autoHideDuration={12500}
          open={isDrawerOpen.drawerAlert1}
          onClose={toggleDrawer("drawerAlert1", false)}
          className="snackbar-alert"
        >
          <Alert
            severity="error"
            className="bp-alert alert-error"
            icon={
              <InfoOutlinedIcon fontSize="medium" className="bp-icon medium" />
            }
          >
            <div className="alert-header">
              <div className="left">
                <h1 className="title">error - 출장일정이 종료되었습니다.</h1>
              </div>
              <div className="right"></div>
            </div>
            <div className="alert-body">
              출장비 178,240원이 계좌로 입금되었습니다.
            </div>
          </Alert>
        </Snackbar>
      </div>

      <div>
        <Button onClick={toggleDrawer("drawerAlert2", true)}>
          [snackbar-alert] success - 출장일정 종료 안내
        </Button>
        <Snackbar
          autoHideDuration={12500}
          open={isDrawerOpen.drawerAlert2}
          onClose={toggleDrawer("drawerAlert2", false)}
          className="snackbar-alert"
        >
          <Alert
            severity="success"
            className="bp-alert alert-success"
            icon={<CheckCircle fontSize="medium" className="bp-icon medium" />}
          >
            <div className="alert-header">
              <div className="left">
                <h1 className="title">출장일정이 종료되었습니다.</h1>
              </div>
              <div className="right"></div>
            </div>
            <div className="alert-body">
              출장비 178,240원이 계좌로 입금되었습니다.
            </div>
          </Alert>
        </Snackbar>
      </div>
    </>
  );
};

export default CustomizedSnackbars;
