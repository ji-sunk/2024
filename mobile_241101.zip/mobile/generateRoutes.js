// scripts/generateRoutes.js
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// 현재 파일의 디렉토리 이름을 가져옵니다.
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const pagesDir = path.join(__dirname, "src/pages");
const outputFilePath = path.join(__dirname, "src/Routes.tsx");

const getRoutes = (dir, prefix = "") => {
  let routes = [];
  const files = fs.readdirSync(dir);

  files.forEach((file) => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      routes = routes.concat(getRoutes(fullPath, `${prefix}/${file}`));
    } else if (file.endsWith(".tsx")) {
      const routePath = `${prefix}/${file.replace(".tsx", "")}`
        .replace(/\/index$/, "")
        .replace(/\[([^\]]+)\]/g, ":$1");
      routes.push({
        path: routePath || "/",
        component: `./pages${prefix}/${file}`,
      });
    }
  });

  return routes;
};

function convertPathToPascalCase(path) {
  const segments = path.split("/").filter(Boolean);
  const lastTwoSegments = segments.slice(-2);
  return lastTwoSegments
    .map((segment) => {
      const componentName =
        segment.charAt(0).toUpperCase() + segment.slice(1).toLowerCase();
      return componentName.replace(".tsx", "");
    })
    .join("");
}

const routes = getRoutes(pagesDir);

const routesFileContent = `
import React from 'react';
import { Route, Routes } from 'react-router-dom';

${routes.map((route) => `import ${convertPathToPascalCase(route.component)} from '${route.component}';`).join("\n")}

const PageRoutes = () => (
  <Routes>
    ${routes.map((route) => `<Route path="${route.path}" element={<${convertPathToPascalCase(route.component)} />} />`).join("\n")}
  </Routes>
);

export default PageRoutes;
`;

fs.writeFileSync(outputFilePath, routesFileContent);
console.log("Routes file generated successfully.");
