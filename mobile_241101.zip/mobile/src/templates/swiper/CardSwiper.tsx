import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Autoplay, Navigation, Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

const slideData = [
  {
    id: 1,
    text: "결제 카드 1",
  },
  {
    id: 2,
    text: "결제 카드 2",
  },
  {
    id: 3,
    text: "결제 카드 3",
  },
  {
    id: 4,
    text: "결제 카드 4",
  },
  {
    id: 5,
    text: "결제 카드 5",
  },
];
let slideInx = 0;
const CardSwiper = () => {
  SwiperCore.use([Navigation, Scrollbar, Autoplay, Pagination]);
  return (
    <div className="swiper-container">
      <Swiper
        loop={true} // 슬라이드 루프
        centeredSlides={true}
        spaceBetween={12} // 슬라이스 사이 간격
        slidesPerView={1.3} // 보여질 슬라이스 수
        navigation={false} // prev, next button
        grabCursor={true}
        pagination={true}
        initialSlide={slideInx}
        // modules={[Thumbs]}
        watchSlidesProgress
        // onSwiper={setThumbsSwiper}
        // autoplay={{
        //   delay: 2500,
        //   disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
        // }}
      >
        {slideData.map((slide) => (
          <SwiperSlide key={slide.id}>
            <div>
              <div>{slide.text}</div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default CardSwiper;
