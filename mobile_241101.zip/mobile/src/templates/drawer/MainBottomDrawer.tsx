import { Box, Button, IconButton, Paper, TextField } from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import { GridCloseIcon } from "@mui/x-data-grid";
import { Menu04 } from "@untitled-ui/icons-react";
import { useState } from "react";

type Anchor = "top" | "left" | "bottom" | "right";

const MainBottomDrawer = () => {
  // [Drawer]
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    drawerAlert: false, //Alert
    drawer1: false, //기본 샘플-등록/수정
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  return (
    <>
      <IconButton
        onClick={toggleDrawer("drawer1", true)}
        className="btn-icon-only"
        size="medium"
        aria-label="전체메뉴"
      >
        <Menu04 fontSize="medium" />
      </IconButton>
      <SwipeableDrawer
        anchor="bottom"
        open={isDrawerOpen.drawer1}
        onClose={toggleDrawer("drawer1", false)}
        onOpen={toggleDrawer("drawer1", true)}
        className="bp-drawer drawer-bottom"
      >
        <div className="drawer-header" id="drawer-header">
          <div className="inner">
            <Box className="left-area"></Box>
            <Box className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={toggleDrawer("drawer1", false)}
              >
                <GridCloseIcon fontSize="small" className="bp-icon" />
              </IconButton>
            </Box>
          </div>
        </div>
        <Paper className="drawer-body">
          <Box className="drawer-cont">
            <TextField label="입력 전" placeholder="" fullWidth />
            <Box className="btns-group">
              <Box className="inner">
                <Button variant="contained" size="large" className="btn-xlarge">
                  확인
                </Button>
              </Box>
            </Box>
          </Box>
        </Paper>
      </SwipeableDrawer>
    </>
  );
};

export default MainBottomDrawer;
