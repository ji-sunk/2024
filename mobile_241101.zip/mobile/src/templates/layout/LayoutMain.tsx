import { Box } from "@mui/material";
import { FC, ReactNode } from "react";
import BottomNav from "./BottomNav";
import HeaderMain from "./HeaderMain";

type LayoutMainProps = {
  children: ReactNode;
};

const LayoutMain: FC<LayoutMainProps> = (props) => {
  const { children } = props;

  return (
    <Box className="wrapper">
      <HeaderMain />
      {/* <BzpAlert /> */}
      <Box component="main" className="container">
        {children}
      </Box>
      <BottomNav />
    </Box>
  );
};

export default LayoutMain;
