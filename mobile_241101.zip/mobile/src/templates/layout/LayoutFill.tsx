import { Box } from "@mui/material";
import { FC, ReactNode } from "react";

type LayoutFillProps = {
  children: ReactNode;
};

const LayoutFill: FC<LayoutFillProps> = (props) => {
  const { children } = props;

  return (
    <Box className="wrapper fill-wrap">
      <Box component="section" className="container">
        {children}
      </Box>
    </Box>
  );
};

export default LayoutFill;
