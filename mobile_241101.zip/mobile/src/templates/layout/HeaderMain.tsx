import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";
import { AppBar, Box, IconButton, Typography } from "@mui/material";
import { SearchSm } from "@untitled-ui/icons-react";
import { ReactNode } from "react";
import AlarmButton from "src/components/common/AlarmButton";
import AllMenuDrawer from "src/components/common/AllMenuDrawer";

interface HeaderMainProps {
  children?: ReactNode;
}
const HeaderMain = (props: HeaderMainProps) => {
  return (
    <>
      <AppBar position="fixed">
        <Box className="inner">
          <div className="left-area">
            <Typography variant="h1" className="logo">
              <img
                src="/assets/images/logo-hyundai.svg"
                width={145}
                height={20}
                alt="현대자동차"
              />
            </Typography>
          </div>
          <div className="center-area">{/* layout을 위해 빈태그 유지 */}</div>
          <div className="right-area">
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="검색"
            >
              <SearchSm fontSize="medium" />
            </IconButton>
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="결재"
            >
              <ApprovalOutlinedIcon fontSize="medium" />
            </IconButton>
            <AlarmButton />
            <AllMenuDrawer />
          </div>
        </Box>
      </AppBar>
    </>
  );
};

export default HeaderMain;
