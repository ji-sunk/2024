import {
  Box,
  Card,
  CardContent,
  List,
  ListItem,
  Typography,
} from "@mui/material";
import { ReactNode } from "react";
import { Link } from "react-router-dom";

interface DirectlyCardProps {
  children?: ReactNode;
}

const DirectlyCard = (props: DirectlyCardProps) => (
  <>
    <Card className="card-wrap card-directly">
      <Box className="card-header">
        <Link to="#">
          <div className="inner-sides">
            <Box className="left-area">
              <Typography variant="h2">예약바로가기</Typography>
            </Box>
            {/* arrow delete 241018 kjs */}
            {/* <Box className="right-area">
              <ChevronRight className="bp-icon" />
            </Box> */}
          </div>
        </Link>
      </Box>
      <CardContent className="card-cont">
        <List
          className="list-directly"
          style={{ "--item-count": "5" } as React.CSSProperties}
        >
          {/* 아이템 개수에 따라 조정 추가 241018 kjs */}
          {/* [S]loop */}
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-hotel.svg"
                width={28}
                height={28}
                alt="숙박"
              />
              <Box className="text">숙박</Box>
            </Link>
          </ListItem>
          {/* [E]loop */}
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-train.svg"
                width={28}
                height={28}
                alt="열차"
              />
              <Box className="text">열차</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-bus-express.svg"
                width={28}
                height={28}
                alt="고속버스"
              />
              <Box className="text">고속버스</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-airline.svg"
                width={28}
                height={28}
                alt="항공"
              />
              <Box className="text">항공</Box>
            </Link>
          </ListItem>
          {/* disabled class add 241018 kjs */}
          <ListItem>
            <Link to="#" className="item disabled">
              <img
                src="/assets/images/icons/icon-h-srt.svg"
                width={28}
                height={28}
                alt="SRT"
              />
              <Box className="text">SRT</Box>
            </Link>
          </ListItem>

          {/* <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-bus.svg"
                width={28}
                height={28}
                alt="시외버스"
              />
              <Box className="text">시외버스</Box>
            </Link>
          </ListItem> */}

          {/* <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-ship.svg"
                width={28}
                height={28}
                alt="선박"
              />
              <Box className="text">선박</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-car.svg"
                width={28}
                height={28}
                alt="선박"
              />
              <Box className="text">자차</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-car-rental.svg"
                width={28}
                height={28}
                alt="자차"
              />
              <Box className="text">렌트카</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-car-corporate.svg"
                width={28}
                height={28}
                alt="법인차"
              />
              <Box className="text">법인차</Box>
            </Link>
          </ListItem>
          <ListItem>
            <Link to="" className="item">
              <img
                src="/assets/images/icons/icon-h-taxi.svg"
                width={28}
                height={28}
                alt="택시"
              />
              <Box className="text">택시</Box>
            </Link>
          </ListItem> */}
        </List>
      </CardContent>
    </Card>
  </>
);

export default DirectlyCard;
