import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import { ChevronDown } from "@untitled-ui/icons-react";
import * as React from "react";
import ChooseUseRadio from "./ChooseUseRadio";

const AccordionUseRadio = () => {
  const label = { inputProps: { "aria-label": "Switch demo" } };
  // 아코디언 Multi
  const [expandedMulti, setExpandedMulti] = React.useState(false);
  const handleExpansionMulti = () => {
    setExpandedMulti((prevExpanded) => !prevExpanded);
  };
  // 아코디언 Single
  const [expandedSingle, setExpandedSingle] = React.useState<string | false>(
    "panel2-1",
  );
  const handleExpansionSingle =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
      setExpandedSingle(newExpanded ? panel : false);
    };

  return (
    <>
      <div className="bp-accordion type-use">
        <Typography variant="h3" className="bp-title title-sec">
          전체
        </Typography>
        <Accordion
          disableGutters
          elevation={0}
          expanded={expandedSingle === "panel2-1"}
          onChange={handleExpansionSingle("panel2-1")}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            onClick={() =>
              setExpandedSingle(
                expandedSingle === "panel2-1" ? false : "panel2-1",
              )
            }
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    식대
                  </Stack>
                </Stack>
              </Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">
              <ChooseUseRadio />
            </div>
          </AccordionDetails>
        </Accordion>
        <Accordion
          disableGutters
          elevation={0}
          expanded={expandedSingle === "panel2-2"}
          onChange={handleExpansionSingle("panel2-2")}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            onClick={() =>
              setExpandedSingle(
                expandedSingle === "panel2-2" ? false : "panel2-2",
              )
            }
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    교통비그룹
                  </Stack>
                </Stack>
              </Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">
              <ChooseUseRadio />
            </div>
          </AccordionDetails>
        </Accordion>
      </div>
    </>
  );
};

export default AccordionUseRadio;
