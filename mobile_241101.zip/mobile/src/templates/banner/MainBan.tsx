import { Card } from "@mui/material";
import { ReactNode } from "react";
interface MainBanProps {
  children?: ReactNode;
}

const MainBan = (props: MainBanProps) => (
  <>
    <Card>sdf</Card>
  </>
);

export default MainBan;
