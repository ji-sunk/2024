import CloseIcon from "@mui/icons-material/Close";
import { Card, CardContent, IconButton } from "@mui/material";
import { ChevronRight } from "@untitled-ui/icons-react";
import { Link } from "react-router-dom";

const CardBann = () => (
  <>
    <Card className="card-wrap card-bann">
      <CardContent className="card-cont">
        <div className="inner-sides">
          <div className="left-area">
            {/* [D]"txt" added "bp-ellipsis" 말줄임 */}
            <Link to="">
              <div className="txt">출장 플랫폼 사용법 보기</div>
            </Link>
          </div>
          <div className="right-area">
            <IconButton
              className="btn-icon-only"
              size="small"
              aria-label="닫기"
            >
              <CloseIcon fontSize="small" className="bp-icon small" />
            </IconButton>
          </div>
        </div>
      </CardContent>
    </Card>

    <Card className="card-wrap card-bann type-primary">
      <CardContent className="card-cont">
        <Link to="" className="inner-sides">
          <div className="left-area">
            {/* [D]"txt" added "bp-ellipsis" 말줄임 */}
            <div className="txt">출장계획서 작성하기</div>
          </div>
          <div className="right-area">
            <ChevronRight className="bp-icon" />
          </div>
        </Link>
      </CardContent>
    </Card>

    <Card className="card-wrap card-bann type-warn">
      <CardContent className="card-cont">
        <div className="inner-sides">
          <div className="left-area">
            <div className="txt">주의하세요!</div>
            <dl>
              <dt>출장지 인근 지진발생</dt>
              <dd>5.15 00:59 울산시 60Km 지역 규모 4.0 지진발생</dd>
            </dl>
          </div>
          <div className="right-area">
            <img
              src="/assets/images/icons/icon-bann-warn.png"
              alt="주의"
              width={82}
              tabIndex={-1}
            />
            <IconButton
              className="btn-icon-only"
              size="small"
              aria-label="닫기"
            >
              <CloseIcon fontSize="small" className="bp-icon small" />
            </IconButton>
          </div>
        </div>
      </CardContent>
    </Card>
  </>
);

export default CardBann;
