import { Info } from "@mui/icons-material";
import {
  Box,
  FormControl,
  FormControlLabel,
  Paper,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";
import { Helmet as Head } from "react-helmet";
import BtnsGroup from "src/components/common/BtnsGroup";
import LayoutSub from "src/templates/layout/LayoutSub";

const selectOption = [
  { label: "label1", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

const MMA010300 = () => {
  return (
    <>
      <Head>
        <title>차량정보 입력</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , flex-wrap */}
        <Paper className="ui-paper flex-wrap">
          {/* [S] */}
          <div className="light-box full-height">
            {/* [S]car-info-area */}
            <div className="car-info-area">
              <div className="ui-box">
                <div className="inner-sides">
                  <Box className="left-area">
                    <Typography variant="h3" className="bp-title">
                      차량정보를 입력해주세요
                    </Typography>
                  </Box>
                  <div className="right-area"></div>
                </div>
                <div className="item-field">
                  <FormControl
                    component="fieldset"
                    variant="standard"
                    className="fullWidth"
                  >
                    <RadioGroup
                      aria-labelledby="radio-buttons-group"
                      defaultValue="radio03-01"
                      name="radio buttons group"
                      className="bp-btns-group tabs-type group fullWidth"
                      row
                    >
                      <FormControlLabel
                        className="btn-form-type"
                        control={<Radio value="radio03-01" />}
                        label="법인차"
                      />
                      <FormControlLabel
                        className="btn-form-type"
                        control={<Radio value="radio03-02" />}
                        label="테스트차"
                      />
                    </RadioGroup>
                  </FormControl>
                </div>
                <div className="item-field">
                  <TextField
                    className="type-btn"
                    type="text"
                    label="차량번호"
                  />
                </div>
                <Box className="bp-instructions">
                  <Info fontSize="small" className="bp-icon xsmall" />
                  <div className="txt">배차받은 차량정보를 입력해주세요.</div>
                </Box>
              </div>
            </div>
            {/* [E]car-info-area */}
          </div>
          {/* [E] */}
        </Paper>
        {/* [E]ui-paper bztrip-wrap */}
        <BtnsGroup />
      </LayoutSub>
    </>
  );
};

export default MMA010300;
