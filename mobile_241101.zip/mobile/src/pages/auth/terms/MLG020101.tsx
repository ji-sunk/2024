import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG020101 = () => {
  const [selected, setSelected] = React.useState(false);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>개인정보 수집 • 이용</title>
      </Head>
      {/* [S]개인정보 수집 • 이용 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">개인정보 수집 • 이용</Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            {/* [S]terms-details */}
            <div className="terms-details">
              <p className="text-hide">개인정보 수집 • 이용</p>
              <div>
                비즈플레이㈜(이하 당사’)는 「개인정보보호법」, 「정보통신망
                이용촉진 및 정보보호에 관한 법률」, 「통신비밀보호법」,
                「전기통신사업법」, 「전자문서 및 전자거래기본법」 등
                정보통신서비스 제공자가 준수하여야 할 관련 법령 상의
                개인정보보호 규정을 준수하며, 관련 법령에 의거한
                개인정보처리방침을 정하여 이용자의 권익 보호에 최선을 다하고
                있습니다.
              </div>
              <ul>
                <li>
                  <p>제1조(개인정보 수집항목 및 이용목적)</p>
                  <div>
                    bzp출장관리는 다음의 목적을 위하여 개인정보를
                    수집/이용합니다. 수집/이용하고 있는 개인정보는 다음의 목적
                    이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는
                    경우에는 「개인정보 보호법」 제 18조에 따라 별도의 동의를
                    받는 등 필요한 조치를 이행할 예정입니다. 필수항목 외
                    선택항목을 입력하지 않았다 하여 서비스 이용에 제한은
                    없습니다.
                    <br />
                    <br />
                    회원가입 및 예약 등 필요 시점에 수집하는 개인정보의 범위는
                    다음과 같습니다.
                  </div>
                  <div className="table-area">
                    <table className="table-horizontal">
                      <caption>수집하는 개인정보의 범위</caption>
                      <colgroup>
                        <col style={{ width: "130px" }} />
                        <col style={{ width: "60px" }} />
                        <col style={{ width: "auto" }} />
                        <col style={{ width: "auto" }} />
                        <col style={{ width: "110px" }} />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>수집방법</th>
                          <th>구분</th>
                          <th>수집항목</th>
                          <th>이용목적</th>
                          <th>보유기간</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th rowSpan={2}>가입 /회원관리</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              개인정보
                              <br />
                              [이름, 이메일, 아이디, 비밀번호, 생년월일,
                              <br />
                              휴대폰번호, 이메일, 성별, 내외국인정보]
                            </div>
                            <div className="box">
                              회사정보
                              <br />
                              [회사코드, 회사명, 사원번호, 근무처, 부서명, 직급,
                              <br />
                              직책, 회사 전화번호]
                            </div>
                          </td>
                          <td>
                            - 서비스 이용에 따른 본인확인 및 개인정보 식별
                            <br />- 원활한 의사소통 경로의 확보 <br />-
                            불량회원의 부정 이용 방지와 비인가 사용방지 <br />-
                            분쟁조정을 위한 기록보존
                            <br /> - 불만처리 등 민원처리, 고지사항 전달
                          </td>
                          <td rowSpan={12} className="al-center">
                            임직원 퇴직, 회원탈퇴 시 <br />
                            또는 법정 의무 보유 기간까지
                          </td>
                        </tr>
                        <tr>
                          <td>선택</td>
                          <td>성명(영문), 마일리지번호</td>
                          <td>고객맞춤형 서비스제공(마일리지 등)</td>
                        </tr>

                        <tr>
                          <th rowSpan={4}>항공예약 및 발권</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              예약자 정보
                              <br />
                              [한글성명, 휴대폰번호, 긴급연락처, 이메일주소]
                            </div>
                            <div className="box">
                              탑승객 정보
                              <br />
                              [성명(국문/영문), 생년월일, 휴대폰번호, 이메일,
                              <br />
                              여권정보(국적,발행국,여권번호,여권만료일)]
                            </div>
                          </td>
                          <td>항공예약 및 발권</td>
                        </tr>
                        <tr>
                          <td rowSpan={3}>선택</td>
                          <td>
                            현지연락정보(도시, 현지연락처, 연락처)
                            <br />
                            체류지정보(도시,우편번호,주소)
                          </td>
                          <td>
                            항공사스케줄변경 및 운항취소 정보전달
                            <br /> 및 미주의 경우, 체류지 정보
                          </td>
                        </tr>
                        <tr>
                          <td>
                            증빙서류(재직증명서, 가족관계증명서, 장애인등록증)
                          </td>
                          <td>임직원 및 장애인 요금 제공</td>
                        </tr>
                        <tr>
                          <td>항공사, 마일리지 번호</td>
                          <td>항공사 마일리지 적립 제공</td>
                        </tr>
                        <tr>
                          <th>호텔예약</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              예약자 정보
                              <br />
                              [성명(국문/영문), 휴대폰번호, 이메일]
                            </div>
                            <div className="box">
                              투숙객 정보
                              <br />
                              [성명(국문/영문), 휴대폰번호, 이메일, 성별]
                            </div>
                          </td>
                          <td>호텔예약</td>
                        </tr>
                        <tr>
                          <th>고속버스 예약</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              예약자 정보
                              <br />
                              [한글성명, 휴대폰번호, 이메일]
                            </div>
                            <div className="box">
                              탑승객 정보
                              <br />
                              [한글성명, 생년월일, 휴대폰번호, 이메일]
                            </div>
                          </td>
                          <td>고속버스 예약</td>
                        </tr>
                        <tr>
                          <th rowSpan={2}>렌터카 예약</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              예약자 정보
                              <br />
                              [성명(국문/영문), 휴대폰번호, 이메일]
                            </div>
                            <div className="box">
                              이용자 정보
                              <br />
                              [성명(국문/영문), 휴대폰번호, 이메일]
                            </div>
                          </td>
                          <td>렌터카예약</td>
                        </tr>
                        <tr>
                          <td>선택</td>
                          <td>
                            <div className="box">마일리지번호</div>
                          </td>
                          <td>렌터카 마일리지 적립 제공</td>
                        </tr>
                        <tr>
                          <th>비자 예약</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              예약자 정보(택배발송, 사내행낭만 해당
                              <br />
                              [한글성명, 휴대폰번호, 이메일]
                            </div>
                            <div className="box">
                              발급자 정보
                              <br />
                              [성명(국문/영문), 휴대폰번호, 이메일]]
                            </div>
                          </td>
                          <td>비자예약</td>
                        </tr>
                        <tr>
                          <th>결제</th>
                          <td>필수</td>
                          <td>
                            <div className="box">
                              결제정보
                              <br />
                              [카드사명, 카드번호, 계좌번호, 유효기간, 비밀번호,
                              <br />
                              카드소유주명(개인카드만 해당),
                              <br />
                              사업자번호(법인카드만 해당) 여행상품 결제
                            </div>
                          </td>
                          <td>여행상품 결제</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </li>
                <li>
                  <p>제2조(개인정보의 처리 및 보유 기간)</p>
                  <ol>
                    <li>
                      <dl>
                        <dt>
                          <span className="num">①</span> 고객의 개인정보는
                          회원탈퇴 등 수집 및 이용목적이 달성되거나 동의철회
                          요청이 있는 경우 지체 없이 파기됩니다. 단, 회부 내부
                          방침에 의한 정보보호 사유 발생 또는 전자상거래
                          등에서의 소비자보호에 관한 법률」 등 관련법령의 규정에
                          의하여 다음과 같이 거래 관련 권리 의무 관계의 확인
                          등을 이유로 일정기간 보유하여야 할 필요가 있을
                          경우에는 그 기간 동안 보유합니다.
                        </dt>
                        <dd>
                          가. 회사 내부 방침에 의한 정보보호 사유
                          <br /> 부정이용기록: 1년
                        </dd>
                        <dd>
                          나. 관계 법령에 의한 정보 보유 사유
                          <br /> 계약서, 거래신청서 등 영업에 관한
                          중요서류(전자자료 포함) : 10년 (상법 제33조) 건당
                          거래금액이 1만원을 초과하는 전자금융거래에 관한 기록:
                          5년 (전자금융거래법) 건당 거래금액이 1만원 이하인
                          전자금융거래에 관한 기록: 1년 (전자금융거래법) 계약
                          또는 청약철회 등에 관한 기록: 5년 (전자상거래 등에서의
                          소비자보호에 관한 법률) 대금결제 및 재화 등의 공급에
                          관한 기록: 5년 (전자상거래 등에서의 소비자보호에 관한
                          법률) 소비자의 불만 또는 분쟁 처리에 관한 기록: 3년
                          (전자상거래 등에서의 소비자보호에 관한 법률) 기타 관련
                          법률에서 정하는 정보 보유 사유 발생시 그 기간
                        </dd>
                      </dl>
                    </li>
                    <li>
                      <span className="num">②</span> 그 밖의 고객사의 임직원이
                      퇴직 시 정산 목적으로 30일 보관 후 지체 없이 파기됩니다. ※
                      그 외 정보통신망법 제50조(영리목적의 광고성 정보 전송
                      제한) 준수 이력을 증빙하기 위하여 e메일, 문자, 앱 푸시
                      발송 이력과 관련된 개인정보를 최대 2년간 보관할 수
                      있습니다. 이 경우, 탈퇴 회원 및 휴면회원의 발송 이력은
                      일반 이용자의 개인정보와 별도로 보관되며, 다른 목적으로
                      이용하지 않습니다.
                    </li>
                    <li>
                      <span className="num">③</span> 다만 아이디, 본인확인값을
                      최소한의 식별을 위한 개인정보는 서비스 이용 혼란 및
                      부정사용 방지를 위해 회원탈퇴 및 철회 요청 이후에도
                      3개월간 보유할 수 있습니다
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">④</span> 개인정보 파기 방법은
                        다음과 같습니다.
                      </div>
                      <div className="box-indent">
                        1. 회사는 개인정보 보유기간의 경과, 처리 목적 달성 등
                        개인정보가 불필요하게 되었을 때에는 해당 정보를 지체없이
                        파기합니다.
                      </div>
                      <div className="box-indent">
                        2. 이용자로부터 동의 받은 개인정보 보유기간이 경과하거나
                        처리 목적이 달성되었음에 도 불구하고 다른 법령에 따라
                        개인정보를 계속 보존하여야 하는 경우에는, 별도 DB로
                        옮겨져 내부 방침 및 기타 관련법령에 의한 정보보호 사유에
                        따라(보유 및 이용기간 참조) 일정 기간 저장 후
                        사용됩니다. 별도 DB로 옮겨진 개인정보는 법률에 의한 경우
                        가 아니고서는 보유 이외의 다른 목적으로 이용되지
                        않습니다.
                      </div>
                      <div className="box-indent">
                        3. 파기 방법은 다음과 같습니다.
                        <br />- 종이에 출력된 개인정보는 분쇄기로 분쇄하거나
                        소각을 통하여 파기합니다.
                        <br /> - 전자적 파일형태로 저장된 개인정보는 기록을
                        재생할 수 없는 기술적 방법을 사용하 여 삭제 합니다.
                      </div>
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제3조(동의를 거부할 권리 및 거부 경우의 불이익)</p>
                  <ol>
                    <li>
                      귀하는 위와 같이 수집∙이용하는 개인정보에 대해 동의하지
                      않거나 개인정보를 기재하지 않음으로써 거부할 권리가
                      있으나, 동의를 거부할 경우 회원에게 제공되는 서비스가
                      제한될 수 있습니다.
                    </li>
                  </ol>
                </li>
              </ul>
              <div className="terms-footer">
                <p>부칙 (적용일자)</p>
                <div>이 약관은 yyyy년 mm월 dd일부터 시행됩니다.</div>
                <ul className="list-dot">
                  <li>- 이용약관 버전번호 : V1.0</li>
                  <li>- 이용약관 시행일자 : yyyy.mm.dd</li>
                  <li>- 이용약관 최종변경일자 : yyyy.mm.dd</li>
                </ul>
              </div>
            </div>
            {/* [E]terms-details */}
          </div>
        </DialogContent>
        <DialogActions className="dialog-footer">
          {/* [S]<BtnsGroup /> */}
          <Box className="btns-group">
            <Box className="inner">
              <Button variant="contained" size="large" className="btn-xlarge">
                {/* 240819 modify */}
                동의하기
              </Button>
            </Box>
          </Box>
          {/* [E]BtnsGroup */}
        </DialogActions>
      </Dialog>
      {/* [E]개인정보 수집 • 이용 */}
    </>
  );
};

export default MLG020101;
