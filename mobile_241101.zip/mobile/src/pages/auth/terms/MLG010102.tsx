import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG010102 = () => {
  const [selected, setSelected] = React.useState(false);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>본인확인서비스이용약관</title>
      </Head>
      {/* [S]본인확인서비스이용약관 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">본인확인서비스이용약관</Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            {/* [S]terms-details */}
            <div className="terms-details">
              <p className="text-hide">본인확인서비스이용약관</p>
              <ul>
                <li>
                  <p>제1조 (목적)</p>
                  <div>
                    이 약관은 본인확인서비스 대행기관인 주식회사
                    코리아크레딧뷰로(이하 ''회사''라 합니다)와 본인확인서비스
                    이용자(이하 ''이용자''라 합니다) 간에 본인확인서비스 이용에
                    관한 회사와 이용자의 권리와 의무, 기타 제반 사항을 정함을
                    목적으로 합니다.
                  </div>
                </li>
                <li>
                  <p>제2조 (용어의 정리)</p>
                  <ol>
                    <li>
                      <span className="num">①</span>
                      "본인확인서비스"라 함은 이용자가 유무선 인터넷의 웹사이트
                      및 스마트폰 Application 등(이하 "사이트"라 합니다.)에서
                      본인 명의로 개통한 휴대폰을 이용하여, "본인확인정보"를
                      입력하고 인증 절차를 통하여 본인 여부와 본인이 등록한
                      정보의 정확성을 확인하여 주는 서비스를 말합니다.
                    </li>
                    <li>
                      <span className="num">②</span> "본인확인정보"라 함은
                      이용자가 입력한 본인의 생년월일, 성별, 성명, 내/외국인
                      여부, 이동통신사, 본인명의로 개통된 휴대폰번호, 기타
                      본인확인기관과 이용자간에 별도로 설정한 번호 등 "이용자"의
                      본인 여부 확인에 필요한 정보를 말합니다.
                    </li>
                    <li>
                      <span className="num">③</span> "이용자"라 함은
                      "사이트"에서 본인확인기관이 제공하는 "본인확인서비스"를
                      이용하는 자를 말합니다.
                    </li>
                    <li>
                      <span className="num">④</span> "본인확인기관"이라 함은
                      "본인확인서비스" 관련 법령에 따라 주민등록번호를 수집
                      이용하고, "사이트"에서 주민등록번호를 사용하지 아니하고
                      본인을 확인할 수 있도록 해주는 방법을 개발 제공 관리하는
                      업무를 담당하는 사업자를 말합니다.
                    </li>
                    <li>
                      <span className="num">⑤</span> "대행기관"은 본인확인기관을
                      대신하여 "이용자"가 "사이트"에서 "본인확인서비스"를
                      제공받을 수 있도록 "사이트"와 본인확인기관간의
                      "본인확인서비스"를 중계하고 "이용자"에게 이용방법의 안내와
                      문의 등 지원업무를 담당하여서, "사이트"에서 "이용자"에게
                      "본인확인서비스"를 대행하여 제공하는 사업자를 말합니다.
                    </li>
                    <li>
                      <span className="num">⑥</span> "사이트"라 함은 유무선
                      인터넷의 Web사이트, 스마트폰 Application(Apps)을 통하여
                      "이용자"에게 서비스, Contents, Point 등의 각종 재화와
                      용역을 유/무료로 제공하는 사업자 및 기관, 단체를 말합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제3조 (약관의 명시 및 변경)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 회사는 본 약관을 서비스
                      초기 화면에 게시하여 이용자가 본 약관의 내용을 확인할 수
                      있도록 합니다.
                    </li>
                    <li>
                      <span className="num">②</span> 회사는 필요하다고 인정되는
                      경우 본 약관을 변경할 수 있으며, 회사가 약관을 변경할
                      경우에는 적용일자 및 변경사유를 명시하여 서비스 화면에
                      적용일자 14일 전부터 공지합니다.
                    </li>
                    <li>
                      <span className="num">③</span> 회사가 전항에 따라 변경
                      약관을 공지 또는 통지하면서 이용자에게 약관 변경 적용일
                      까지 거부의사를 표시하지 않으면 약관의 변경에 동의한
                      것으로 간주한다는 내용을 명확하게 공지 또는 통지하였음에도
                      이용자가 명시적으로 약관 변경에 대한 거부의사를 표시하지
                      아니하면 이용자가 변경 약관에 동의한 것으로 간주합니다.
                    </li>
                    <li>
                      <span className="num">④</span> 이용자 또는 사이트가 변경된
                      약관에 대한 내용을 알지 못하여 발생하는 손해 및 피해에
                      대해서는 회사는 일체 책임을 지지 않습니다.
                    </li>
                    <li>
                      <span className="num">⑤</span> 회사의 약관은 개인정보보호
                      등을 규정한 정보통신 이용촉진 및 정보보호 등에 관한 법률
                      등 관련 법령에서 정한 절차와 범위 내에서만 유효합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제4조 (본인확인서비스 제공시간)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 본인확인서비스의 이용은
                      연중무휴 1일 24시간을 원칙으로 합니다. 다만, 정기 점검 및
                      기타 기술상의 이유, 기타 운영상의 사유와 목적에 따라
                      회사가 정한 기간에 일시 중지될 수 있으며, 각 사이트의
                      기술상, 운영상의 사유와 목적에 따라 일시 중지될 수
                      있습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 회사는 본인확인서비스
                      중지에 따라 이용자에게 별도의 보상은 하지 않습니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제5조 (회사의 권리와 의무)</p>
                  <ol>
                    <li>
                      <span className="num">①</span> 회사는 본인확인서비스
                      대행과 관련하여 인지한 이용자의 본인확인정보를 본인의 승낙
                      없이 제3자에게 누설하거나 배포하지 않습니다. 단,
                      국가기관의 요구가 있는 경우, 범죄에 대한 수사상의 목적이
                      있는 경우 등 기타 관계 법령에서 정한 절차에 따른 요청이
                      있는 경우에는 그러하지 않습니다.
                    </li>
                    <li>
                      <span className="num">②</span> 회사는 이용자에게 안정적인
                      본인확인서비스 대행을 위하여 지속적으로 관련 시스템이나
                      절차, 기능 등의 예방점검, 유지보수 등을 이행하며,
                      본인확인서비스의 장애가 발생하는 경우, 이를 지체 없이 수리
                      및 복구합니다.
                    </li>
                    <li>
                      <span className="num">③</span> 회사는 서비스의 안전성과
                      신뢰성, 보안성을 확보하기 위하여 개인정보 처리시스템의
                      해킹방지시스템 및 보안관리 체계 운영 등 기술적, 관리적
                      조치를 취합니다.
                    </li>
                    <li>
                      <span className="num">④</span> 회사는 서버 및 통신기기의
                      정상작동여부 확인을 위하여 정보처리시스템 자원 상태의
                      감시, 경고 및 제어가 가능한 모니터링 체계를 갖춥니다
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">⑤</span> 회사는 해킹 침해 방지를
                        위하여 다음 각 호의 시스템 및 프로그램을 설치하여
                        운영합니다.
                      </div>
                      <div className="box-indent">
                        1. 침입 차단 및 탐지시스템 설치
                      </div>
                      <div className="box-indent">
                        2. 그 밖에 필요한 보호장비 또는 암호프로그램 등
                        정보보호시스템 설치
                      </div>
                    </li>
                    <li>
                      <span className="num">⑥</span> 회사는 컴퓨터바이러스
                      감염을 방지하기 위하여 바이러스 방지 대책을 자체적으로
                      운영합니다.
                    </li>
                  </ol>
                </li>
                <li>
                  <p>제6조 (이용자의 권리와 의무)</p>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> 이용자는 서비스를
                        이용함에 있어서 다음 각호에 해당하는 행위를 하여서는
                        안되며, 회사는 위반 행위에 따르는 일체의 법적 책임을
                        지지 않습니다.
                      </div>
                      <div className="box-indent">
                        1. 본인이 아닌 타인의 본인확인정보를 부정하게 사용 및
                        도용하는 행위
                      </div>
                      <div className="box-indent">
                        2. 회사 및 본인확인기관, 사이트의 저작권, 제3자의 저작권
                        등 기타 권리를 침해하는 행위
                      </div>
                      <div className="box-indent">
                        3. 법령에 규정하는 제반 범죄 및 위법 행위
                      </div>
                    </li>
                    <li>
                      <span className="num">②</span> 이용자는 본 약관에서
                      규정하는 사항과 서비스에 대한 이용안내 또는 주의사항 등을
                      준수하여야 합니다.
                    </li>
                    <li>
                      <span className="num">③</span> 이용자는 이용자 본인의
                      접근매체, 본인확인정보의 분실, 유출, 누설없이 본인 스스로
                      성실히 관리하여야 합니다.
                    </li>
                    <li>
                      <span className="num">④</span> 이용자는 회사의 서비스
                      고객센터를 통하여 관련 문의를 할 수 있습니다.
                      <br />
                      《회사의 서비스 고객센터 연락처 : 02-708-1000,
                      www.ok-name.co.kr》
                    </li>
                    <li>
                      <span className="num">⑤</span> 이용자는 본인확인서비스가
                      자신의 의사에 반하여 특정 사이트에 제공되었음을 안 때에는
                      본인확인기관 또는 회사를 통하여 자신의 본인확인정보 삭제를
                      요구할 수 있으며, 본인확인기관 또는 회사는 그 정정요구를
                      받은 날부터 2주 이내에 처리 결과를 알려 주어야 합니다.
                      <br />
                      《회사의 서비스 고객센터 연락처 : 02-708-1000,
                      www.ok-name.co.kr》
                    </li>
                  </ol>
                </li>
                <li>
                  <li>
                    <p>제7조 (이용자의 개인정보보호)</p>
                    <ol>
                      <li>
                        <span className="num">①</span> 회사는 본인확인서비스를
                        대행함에 있어 취득한 이용자의 정보 또는 자료를 이용자의
                        동의 없이 제3자에게 제공, 누설하거나 업무상 목적 외에
                        사용하지 않습니다.
                      </li>
                      <li>
                        <span className="num">②</span> 이용자의 개인정보 보호는
                        회사가 관련 법령과 회사가 수립하여 운영하는 개인정보
                        취급방침에 따릅니다. 자세한 회사의 개인정보 제공 범위와
                        보호 방침, 위탁은 서비스 홈페이지(www.ok-name.co.kr)에
                        제공되는 개인정보 취급방침을 참조하시기 바랍니다.
                      </li>
                    </ol>
                  </li>
                  <li>
                    <p>제8조 (약관 외 준칙)</p>
                    <div>
                      본 약관에 명시되지 아니한 사항에 대해서는 정보통신망 이용
                      촉진 및 정보보호 등에 관한 법률 등 기타 관련 법령 또는
                      상관례에 따릅니다.
                    </div>
                  </li>
                </li>
              </ul>

              <div className="terms-footer">
                <p>부칙</p>
                <div>(시행일) 이 약관은 공시한 날로부터 시행합니다.</div>
              </div>
            </div>
            {/* [E]terms-details */}
          </div>
        </DialogContent>
        <DialogActions className="dialog-footer">
          {/* [S]<BtnsGroup /> */}
          <Box className="btns-group">
            <Box className="inner">
              <Button variant="contained" size="large" className="btn-xlarge">
                {/* 240819 modify */}
                동의하기
              </Button>
            </Box>
          </Box>
          {/* [E]BtnsGroup */}
        </DialogActions>
      </Dialog>
      {/* [E]bizplay이용약관 */}
    </>
  );
};

export default MLG010102;
