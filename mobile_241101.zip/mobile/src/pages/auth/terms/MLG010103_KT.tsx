import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";
import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG010103_KT = () => {
  const [scroll, setScroll] = useState<DialogProps["scroll"]>("paper");
  const [openDialog, setOpenDialog] = useState(true);
  const descriptionElementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (openDialog) {
      descriptionElementRef.current?.focus();
    }
  }, [openDialog]);

  const handleCloseDialog = () => setOpenDialog(false);

  const handleAgree = () => {
    alert("동의가 완료되었습니다.");
    handleCloseDialog();
  };

  return (
    <>
      <Head>
        <title>케이티 개인정보 수집 이용 동의</title>
      </Head>
      <Dialog
        fullScreen
        open={openDialog}
        onClose={handleCloseDialog}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography className="primary-600">
                  개인정보 수집 이용 취급 위탁동의
                </Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseDialog}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
        </DialogTitle>

        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner ui-box terms-document">
            <Typography component="strong" className="primary-600">
              (주)케이티 귀중
            </Typography>
            <Typography paragraph>
              (주)케이티(이하 ‘회사’라 함)가 제공하는 본인확인서비스를 이용하기
              위해, 다음과 같이 ‘회사’가 본인의 개인정보를 수집 및 이용하고,
              개인정보의 취급을 위탁하는 것에 동의합니다.
            </Typography>

            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                1. 수집항목
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  이용자가 가입한 이동통신사, 휴대폰번호, 성명, 성별, 생년월일,
                  내/외국인 구분
                </Typography>
                <Typography component="li" mb={1}>
                  연계정보(CI), 중복가입확인정보(DI)
                </Typography>
                <Typography component="li" mb={1}>
                  이용자가 본인확인을 요청한 서비스명 및 URL정보, 본인확인
                  이용일시, IP 주소
                </Typography>
              </Box>
            </Box>

            {/* 이용목적 */}
            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                2. 이용목적
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  인터넷사업자의 서비스(회원가입, ID/PW찾기 등) 이용에 필요한
                  이용자 본인확인 여부 및 정보 전달(※ 이용자가 본인확인을 요청한
                  인터넷사업자에 한합니다.)
                </Typography>
                <Typography component="li" mb={1}>
                  (주)케이티 등 이동통신사에 이용자 정보를 전송하여 본인확인 및
                  휴대폰 정보의 일치 여부 확인
                </Typography>
                <Typography component="li" mb={1}>
                  휴대폰 사용자 확인을 위한 SMS 인증번호 전송
                </Typography>
                <Typography component="li">부정 이용 방지</Typography>
                <Typography component="li">
                  이용자 본인 요청에 의한 본인확인 이력정보 제공
                </Typography>
                <Typography component="li">
                  휴대폰번호보호서비스 가입여부 확인(서비스 가입자에 한함)
                </Typography>
                <Typography component="li">기타 법률에서 정한 목적</Typography>
              </Box>
            </Box>

            {/* 개인정보의 보유기간 및 이용기간 */}
            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                3. 개인정보의 보유기간 및 이용기간
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  "회사"는 이용자의 개인정보를 이용목적이 달성되거나 보유 및
                  보존기간이 종료하면 해당 정보를 지체없이 파기 하며 별도의
                  보관을 하지 않습니다. 단, 아래의 경우는 제외합니다.
                  <Typography component="p">
                    법령에서 정하는 경우 해당 기간까지 보유(상세 사항은 회사의
                    개인정보처리방침에 기재된 바에 따름
                  </Typography>
                </Typography>
              </Box>
            </Box>

            <Typography component="strong" className="primary-600">
              4. 본인확인서비스 제공을 위한 개인정보의 취급위탁
            </Typography>
            <ul>
              <li>
                <div className="style-table-box">
                  <dl className="style-row">
                    <dt>수탁자</dt>
                    <dd>
                      <Typography component="p">
                        코리아크레딧뷰로(주)
                      </Typography>
                    </dd>
                  </dl>
                  <dl className="style-row">
                    <dt>취급위탁 업무</dt>
                    <dd>
                      <Typography component="p">
                        본인확인정보의 정확성 여부 확인, 연계정보(CI) 및
                        중복가입확인정보(DI) 전송, 서비스 관련 상담 및 불만 처리
                        등
                      </Typography>
                    </dd>
                  </dl>
                </div>
              </li>
            </ul>

            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                5. 상기 개인정보 수집 및 이용과 취급위탁에 동의하지 않는 경우,
                서비스를 이용할 수 없습니다.
              </Typography>
              <div>
                ‘회사’가 제공하는 서비스의 개인정보 취급과 관련된 사항은 아래의
                ‘회사’ 홈페이지에 기재된 개인정보처리방침에 따릅니다.
                <br />
                -(주)케이티 : www.kt.com 본인은 상기 내용을 숙지하였으며 이에
                동의합니다.
              </div>
            </Box>

            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                &lt;코리아크레딧뷰로㈜&gt; 귀중
              </Typography>
              <div>
                귀사가 통신사(에스케이텔레콤㈜, ㈜케이티, LG유플러스㈜)로부터
                위탁 받아 제공하는 휴대폰본인확인서비스 이용과 관련하여 본인의
                개인정보를 수집·이용 및 제공하고자 하는 경우에는
                「개인정보보호법」 제15조, 제22조, 제24조, 「정보통신망 이용촉진
                및 정보보호 등에 관한 법률」 제22조에 따라 본인의 동의를 얻어야
                합니다. 이에 본인은 귀사가 아래와 같이 본인의 개인정보를 수집 ·
                이용 및 제공 하는데 동의합니다.
              </div>
            </Box>

            {/* 개인정보의 수집 및 이용목적 */}
            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                개인정보의 수집 및 이용목적
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  주민등록번호 대체서비스 제공개인정보보호법 제24조 2항에 의해
                  온라인 또는 오프라인상에서 회원가입, 글쓰기, 포인트적립 등
                  주민등록번호를 사용하지 않고도 본인임을 확인할 수 있는
                  개인정보보호 서비스(휴대폰본인확인서비스) 제공
                </Typography>
                <Typography component="li" mb={1}>
                  에스케이텔레콤(주), (주)케이티, LG유플러스(주) 등 통신사에
                  이용자 정보를 전송하여 본인확인 및 휴대폰 정보의 일치 여부
                  확인.
                </Typography>
                <Typography component="li" mb={1}>
                  휴대폰 사용자 확인을 위한 SMS(또는 LMS) 인증번호 전송.
                </Typography>
                <Typography component="li" mb={1}>
                  부정 이용 방지 및 수사의뢰.
                </Typography>
                <Typography component="li" mb={1}>
                  이용자 본인 요청에 의한 본인확인 이력정보 제공, 민원처리, 추후
                  분쟁조정을 위한 기록보존, 고지사항 전달 등.
                </Typography>
                <Typography component="li">
                  휴대폰번호보호서비스 가입여부 확인(서비스 가입자에 한함).
                </Typography>
              </Box>
            </Box>

            {/* 수집할 개인정보 */}
            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                □ 수집할 개인정보
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  이용자가 가입한 이동통신사, 휴대폰번호, 성명, 성별, 생년월일,
                  내/외국인 구분.
                </Typography>
                <Typography component="li" mb={1}>
                  중복가입확인정보(발급자의 웹사이트 중복가입 여부를 확인할 수
                  있는 정보).
                </Typography>
                <Typography component="li" mb={1}>
                  연계정보(온/오프라인 사업자간 제휴 등 연계서비스가 가능하도록
                  특정 개인을 식별할 수 있는 정보).
                </Typography>
                <Typography component="li" mb={1}>
                  인증처 및 사이트 URL.
                </Typography>
                <Typography component="li" mb={1}>
                  인증일시.
                </Typography>
                <Typography component="li">IP주소.</Typography>
              </Box>
            </Box>

            {/* 개인정보의 제공 */}
            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                □ 개인정보의 제공
              </Typography>
              <Box>
                {/* 1. 휴대폰본인확인서비스 제공 */}
                <Typography gutterBottom>
                  1. 휴대폰본인확인서비스 제공
                </Typography>
                <Typography component="li" mb={1}>
                  제공 받는자: SK텔레콤(주), (주)케이티, ㈜엘지유플러스.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 목적: 업무대행(본인확인정보 및 연계정보 전송 및 서비스
                  관련 업무 상담 및 불만처리 등).
                </Typography>
                <Typography component="li" mb={1}>
                  제공 항목: 생년월일, 성명, 성별, 내/외국인 구분, 휴대폰번호,
                  이동통신사.
                </Typography>
                <Typography component="li">
                  보유 기간: “제공받는 자”의 이용목적 달성 시 까지 보관하며,
                  세부사항은 각 사업자의 개인정보처리방침을 따름.
                </Typography>

                {/* 2. 휴대폰본인확인서비스 문자발송 */}
                <Typography gutterBottom>
                  2 휴대폰본인확인서비스 문자발송
                </Typography>
                <Typography component="li" mb={1}>
                  제공 받는자: SK텔레콤(주), (주)케이티, ㈜엘지유플러스.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 목적: 휴대폰본인확인서비스 점유확인을 위한 문자발송.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 항목: 휴대폰번호.
                </Typography>
                <Typography component="li">
                  보유 기간: “제공받는 자”의 이용목적 달성 시 까지 보관하며,
                  세부사항은 각 사업자의 개인정보처리방침을 따름.
                </Typography>

                {/* 3. 휴대폰본인확인서비스 제공 (서비스 이용 사업자) */}
                <Typography gutterBottom>
                  3 휴대폰본인확인서비스 제공 (서비스 이용 사업자)
                </Typography>
                <Typography component="li" mb={1}>
                  제공 받는자: 휴대폰본인확인서비스 이용 회사(코리아크레딧뷰로㈜
                  (이하 “회사”)와 계약된 사업자).
                </Typography>
                <Typography component="li" mb={1}>
                  제공 목적: 휴대폰본인확인서비스 제공.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 항목: 생년월일, 성명, 성별, 내/외국인 구분, 휴대폰번호,
                  이동통신사, IP주소, 중복가입확인정보(DI), 연계정보(CI).
                </Typography>
                <Typography component="li">
                  보유 기간: “회사”와 계약한 사업자의 이용목적 달성 시 까지
                  보관하며, 세부사항은 각 사업자의 개인정보처리방침을 따름.
                </Typography>

                {/* 4. 휴대폰인증보호서비스 안내 */}
                <Typography gutterBottom>
                  4 휴대폰인증보호서비스 안내(광고성정보 수신동의 선택 시)
                </Typography>
                <Typography component="li" mb={1}>
                  제공 받는자: ㈜민앤지, ㈜한국인증플랫폼즈.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 목적: 휴대폰인증보호서비스(휴대폰번호도용방지서비스)
                  안내.
                </Typography>
                <Typography component="li" mb={1}>
                  제공 항목: 휴대폰번호, 통신.
                </Typography>
                <Typography component="li">
                  보유 기간: 목적달성 후 폐기(동의 철회 시).
                </Typography>
              </Box>
            </Box>

            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                개인정보의 보유 및 이용기간
              </Typography>
              <Typography mb={1}>
                개인정보는 원칙적으로 개인정보의 수집목적 또는 제공받은 목적이
                소멸되면 파기됩니다. 단, “개인정보보호법”, “정보통신망 이용 촉진
                및 정보보호 등에 관한 법률”, “신용정보의 이용 및 보호에 관한
                법률”, ” 본인확인기관 지정 및 관리에 관한 지침”, ”방송통신위원회
                고시” 등 기타 관련법령의 규정에 의하여 법률관계의 확인 등을
                이유로 특정한 기간 동안 보유하여야 할 필요가 있을 경우에는
                아래에 정한 기간 동안 보유합니다.
              </Typography>
              <Box component="ol" sx={{ paddingLeft: "20px", margin: 0 }}>
                <Typography component="li" mb={1}>
                  방송통신위원회 정기점검 이행조치 및 회사 내부 방침에 의한
                  정보보유 사유로 본인확인 이력보관
                  <ul>
                    <li>부정이용 방지 및 민원처리: 1년 이내</li>
                  </ul>
                </Typography>
                <Typography component="li" mb={1}>
                  관계법령에 의한 정보보호 사유
                  <ul>
                    <li>소비자의 불만 또는 분쟁처리에 관한 기록: 3년</li>
                  </ul>
                </Typography>
              </Box>
            </Box>

            <Box mb={3}>
              <Typography component="strong" className="primary-600">
                동의거부권리 및 거부에 따른 불이익 내용
              </Typography>
              <Typography>
                개인정보 수집·이용 및 제공에 따른 동의는 거부할 수 있으며, 동의
                후에도 언제든지 철회 가능합니다. 다만, 동의 거부 시에는 서비스
                이용이 제한될 수 있습니다.
              </Typography>
            </Box>
          </div>
        </DialogContent>

        <DialogActions className="dialog-footer">
          <Box className="btns-group">
            <Box className="inner">
              <Button
                variant="contained"
                size="large"
                className="btn-xlarge"
                disabled
                onClick={handleAgree}
              >
                동의하기
              </Button>
            </Box>
          </Box>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default MLG010103_KT;
