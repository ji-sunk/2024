import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";

const PersonalInfoConsentTable = () => {
  return (
    <Box sx={{ padding: "20px" }}>
      <Typography variant="h5" gutterBottom>
        개인(신용)정보 수집·이용 동의
      </Typography>

      <Typography paragraph>
        현대자동차(이하, “기관”)는 자산관리 서비스를 제공하기 위해
        개인(신용)정보를 수집·이용하는 경우, 「신용정보의 이용 및 보호에 관한
        법률」 및 「개인정보보호법」 등 관련 법규에 따라 이용자 본인의 동의가
        필요합니다.
      </Typography>

      <TableContainer component={Paper}>
        <Table aria-label="personal information consent table">
          <TableHead>
            <TableRow>
              <TableCell align="center" sx={{ fontWeight: "bold" }}>
                항목
              </TableCell>
              <TableCell align="center" sx={{ fontWeight: "bold" }}>
                내용
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {/* Row 1 */}
            <TableRow>
              <TableCell>수집·이용 목적</TableCell>
              <TableCell>
                <ul>
                  <li>
                    ‘나의 자산’ 서비스 중 카드정보관리 (카드 가입현황 조회, 카드
                    거래내역 확인)
                  </li>
                  <li>‘마이데이터 개인카드 출장정산’ 서비스 제공 및 관리</li>
                  <li>기타 법령상 의무 이행</li>
                  <li>금융사고 조사 및 분쟁 해결</li>
                </ul>
              </TableCell>
            </TableRow>

            {/* Row 2 */}
            <TableRow>
              <TableCell>수집·이용 항목</TableCell>
              <TableCell>
                <Typography>개인(신용)정보:</Typography>
                <ul>
                  <li>CI</li>
                  <li>개인(신용)정보 제3자 제공 동의 변경일자, 동의 여부</li>
                  <li>회원가입 상태 변경일자, 회원/비회원 여부</li>
                </ul>
                <Typography>신용거래정보:</Typography>
                <ul>
                  <li>카드정보, 월별 및 일별 카드이용정보</li>
                </ul>
              </TableCell>
            </TableRow>

            {/* Row 3 */}
            <TableRow>
              <TableCell>보유 및 이용기간</TableCell>
              <TableCell>
                수집·이용 동의일로부터 서비스 이용 종료 또는 동의 철회 시까지
                보유됩니다. 단, 법령에 따라 보존이 필요한 경우 해당 기간 동안
                보존됩니다.
              </TableCell>
            </TableRow>

            {/* Row 4 */}
            <TableRow>
              <TableCell>동의 거부 시 불이익</TableCell>
              <TableCell>
                동의를 거부할 수 있지만, 동의하지 않을 경우 ‘마이데이터 개인카드
                출장정산’ 서비스 이용이 제한됩니다.
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default PersonalInfoConsentTable;
