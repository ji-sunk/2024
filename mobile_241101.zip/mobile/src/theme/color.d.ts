// src/theme/color.d.ts
import { PaletteColor, PaletteColorOptions } from "@mui/material/styles";

export interface ExtendedPaletteColor extends PaletteColor {
  lightest?: string;
  darkest?: string;
  alpha4?: string;
  alpha8?: string;
  alpha12?: string;
  alpha30?: string;
  alpha50?: string;
}

export interface ColorRange {
  50: string;
  100: string;
  200: string;
  300: string;
  400: string;
  500: string;
  600: string;
  700: string;
  800: string;
  900: string;
}

declare module "@mui/material/styles" {
  interface Palette {
    neutral: PaletteColorOptions;
    purple: PaletteColorOptions;
    indigo: PaletteColorOptions;
    green: PaletteColorOptions;
    blue: PaletteColorOptions;
  }

  interface PaletteOptions {
    neutral?: PaletteColorOptions;
    purple?: PaletteColorOptions;
    indigo?: PaletteColorOptions;
    green?: PaletteColorOptions;
    blue?: PaletteColorOptions;
  }
}
