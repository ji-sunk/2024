import {
  CheckCircleOutline,
  DateRange,
  HelpOutline,
} from "@mui/icons-material";
import AddOutlinedIcon from "@mui/icons-material/AddOutlined";
import ArrowDropDownOutlinedIcon from "@mui/icons-material/ArrowDropDownOutlined";
import CancelIcon from "@mui/icons-material/Cancel";
import HorizontalRuleOutlinedIcon from "@mui/icons-material/HorizontalRuleOutlined";
import {
  Autocomplete,
  Avatar,
  Box,
  Button,
  Checkbox,
  Chip,
  ClickAwayListener,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  Grow,
  IconButton,
  InputAdornment,
  List,
  ListItem,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  Radio,
  RadioGroup,
  Stack,
  Switch,
  TextField,
  Typography,
} from "@mui/material";
import Tooltip from "@mui/material/Tooltip";
import Grid from "@mui/material/Unstable_Grid2";
import { DateRangePicker } from "@mui/x-date-pickers-pro/DateRangePicker";
import { SingleInputDateRangeField } from "@mui/x-date-pickers-pro/SingleInputDateRangeField";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import {
  Calendar,
  ChevronRight,
  InfoCircle,
  SearchSm,
  User01,
} from "@untitled-ui/icons-react";
import dayjs, { Dayjs } from "dayjs";
import * as React from "react";
import { useRef, useState } from "react";
import { Scrollbar } from "src/components/scrollbar";
import styles from "./Guide.module.css";

const selectOption = [
  { label: "label1", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

/* 기간 달력 */
type DateRange<T> = [T | null, T | null];

interface CustomPickersShortcutsItem<T> {
  label: string;
  name?: string;
  getValue: () => T;
}

const shortcutsItems: CustomPickersShortcutsItem<DateRange<Dayjs>>[] = [
  {
    label: "1주",
    name: "week-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("week"), today.endOf("week")];
    },
  },
  {
    label: "1개월",
    name: "month-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month")];
    },
  },
  {
    label: "3개월",
    name: "three-months-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month").add(2, "months")];
    },
  },
  {
    label: "일별",
    name: "day-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today, today];
    },
  },
  {
    label: "월별",
    name: "month-shortcut",
    getValue: () => {
      const today = dayjs();
      return [today.startOf("month"), today.endOf("month")];
    },
  },
];
const renderShortcutButton = (shortcut) => (
  <>
    <Stack>
      <Button variant="outlined" className={`${shortcut.name}`}>
        {shortcut.label}
      </Button>
    </Stack>
  </>
);
const CustomActionBar = () => (
  <>
    <Stack spacing={0} className="btns-footer-area" direction="row">
      <div className="left"></div>
      <div className="right">
        <Button size="medium" className="btn-text-primary">
          취소
        </Button>
        <Button variant="contained" size="medium">
          확인
        </Button>
      </div>
    </Stack>
  </>
);

const BpComponent = () => {
  const [filteredLocations, setFilteredLocations] = useState("");
  const [RadioValue, setRadioValue] = useState("a");
  const label = { inputProps: { "aria-label": "Switch demo" } };
  const [RadioValue02, setRadioValue02] = useState("radio02-01");
  const [checked, setChecked] = useState([true, false]);
  const [agreeChecked, setAgreeChecked] = useState([false, false, false]);
  const [openDialog, setOpenDialog] = React.useState(false);

  const handleClickOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const clearSearch = () => {
    setFilteredLocations("");
  };

  const filterResults = (e) => {
    setFilteredLocations(e.target.value);
  };

  const handleChangeRadio = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRadioValue(event.target.value);
  };

  const handleChangeRadio02 = (event) => {
    setRadioValue02(event.target.value);
  };

  const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([event.target.checked, event.target.checked]);
  };

  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([event.target.checked, checked[1]]);
  };

  const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([checked[0], event.target.checked]);
  };

  const indeterminateChildren = (
    <FormGroup>
      <FormControlLabel
        label="Child 1"
        control={<Checkbox checked={checked[0]} onChange={handleChange2} />}
      />
      <FormControlLabel
        label="Child 2"
        control={<Checkbox checked={checked[1]} onChange={handleChange3} />}
      />
    </FormGroup>
  );

  const handleDelete = () => {
    console.info("You clicked the delete icon.");
  };

  const handleChangeAgreeAll = (event) => {
    const isChecked = event.target.checked;
    setAgreeChecked([isChecked, isChecked, isChecked]);
  };

  const handleChangeAgree1 = () => {
    setAgreeChecked([!agreeChecked[0], agreeChecked[1], agreeChecked[2]]);
  };

  const handleChangeAgree2 = () => {
    setAgreeChecked([agreeChecked[0], !agreeChecked[1], agreeChecked[2]]);
  };

  const handleChangeAgree3 = () => {
    setAgreeChecked([agreeChecked[0], agreeChecked[1], !agreeChecked[2]]);
  };
  const agreeChildren = (
    <List disablePadding className="bp-check-list list-agree">
      <ListItem>
        <FormControlLabel
          label="[필수] 서비스 이용약관 동의"
          control={
            <Checkbox checked={agreeChecked[0]} onChange={handleChangeAgree1} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
      <ListItem>
        <FormControlLabel
          label="[필수] 개인정보처리방침 동의"
          control={
            <Checkbox checked={agreeChecked[1]} onChange={handleChangeAgree2} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
      <ListItem>
        <FormControlLabel
          label="[선택] 이벤트 · 혜택 정보 수신"
          control={
            <Checkbox checked={agreeChecked[2]} onChange={handleChangeAgree3} />
          }
        />
        <Button
          size="medium"
          color="primary"
          className="btn-view"
          endIcon={<ChevronRight fontSize="small" className="bp-icon xsmall" />}
        >
          전체 보기
        </Button>
      </ListItem>
    </List>
  );

  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
    }
  }

  return (
    <>
      <h3 className={styles.heading3}>10-1. [공통]타입별 FORM</h3>

      <h4 className={styles.heading4}>10-1-1. [공통]공통 class</h4>
      <Grid container spacing={2}>
        <Grid xs={12}>
          1. 말줄임
          <br />
          - 텍스트 한줄 말줄임: className="bp-ellipsis"
          <br />
          - 텍스트 두줄 말줄임: className="bp-bp-ellipsis2"
          <br />- 텍스트 세줄 말줄임: className="bp-bp-ellipsis3"
        </Grid>
        <Grid xs={12}>
          2. display flex의 경우
          <br />
          - column 타입: className="item-column"
          <br />
          - 좌우 content between 타입: className="flex-content-between"
          <br />
          - 좌우 flex direction row 타입: className="flex-row"
          <br />
          - 좌우 flex direction reverse row 타입: className="flex-reverse"
          <br />
        </Grid>
        <Grid xs={12}>
          3. 넓이,높이 100%
          <br />
          - width 타입: className="fullWidth"
          <br />
          - height 타입: className="fill-height"
          <br />
        </Grid>
        <Grid xs={12}>
          4. 배경 색상 타임
          <br />
          - 회색 타입: className="has-bg" (background-color: rgba(242, 246, 255,
          1);)
          <br />
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>10-1-1. [공통]FORM + 텍스트 조합</h4>
      <Grid container spacing={2}>
        <Grid xs={6}>
          <dl className="item-flex">
            <dt className="txt">앞쪽 텍스트가 타이틀</dt>
            <dd>
              <div className="field-text-box">
                <span className="text text-before">앞쪽 텍스트</span>
                <TextField
                  placeholder="최대 50까지"
                  size="small"
                  hiddenLabel
                  fullWidth
                />
                <span className="text text-after">뒷쪽 텍스트</span>
              </div>
            </dd>
          </dl>
        </Grid>
        <Grid xs={6}>
          <dl className="item-flex">
            <dt className="txt">타이틀</dt>
            <dd>
              <Grid container spacing={2} className="bp-grid-field field-date">
                <Grid xs={4}>
                  <Autocomplete
                    includeInputInList
                    size="small"
                    id="select1-1"
                    fullWidth
                    options={selectOption}
                    renderInput={(params) => (
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder="지급일을 입력하세요"
                        {...params}
                        hiddenLabel
                      />
                    )}
                  />
                  {/* 테스트 시 : open */}
                </Grid>
                <Grid xs={8}>
                  <div className="field-text-box">
                    <span className="text text-before">앞쪽 텍스트</span>
                    <TextField
                      placeholder="최대 50까지"
                      size="small"
                      hiddenLabel
                      fullWidth
                    />
                    <span className="text text-after">MB</span>
                    <span className="text text-after">뒷쪽 텍스트</span>
                  </div>
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>10-1-2. [공통]테이블 사용 요소</h4>
      <Grid container spacing={2}>
        <Grid xs={6}>
          <dl className="item-user-info size-medium">
            <dt className="">
              <Avatar className="user-avatar" sx={{ width: 40, height: 40 }}>
                <User01 fontSize="small" className="bp-icon small" />
              </Avatar>
              {/* [D]기본 사진이 있을 경우
                <Avatar
                  alt="김비플"
                  src="/assets/images/tmp-Avatar.png"
                  className="user-avatar"
                  sx={{ width: 40, height: 40 }}
                />
              */}
            </dt>
            <dd>
              <div className="user-info-row">
                <div className="user-name">
                  김비플(테이블 안에 요소로 사용하세요)
                </div>
                <Chip label="20152525" size="small" className="bp-chip" />
              </div>
              <div className="user-info-row">
                <div className="user-team">인사1팀</div>
              </div>
            </dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-1-3. [공통][필터 템플릿/Drawer 레이어 사용]타이틀 별도(UI
        className="item-filter" or className="item-data data-report") + label 有
        기본 타입(column타입)
      </h4>
      <Grid container spacing={2}>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>타이틀(TextField)</dt>
            <dd>
              <TextField
                label="Label"
                placeholder="Placeholder 내용을 입력해주세요."
                fullWidth
                helperText="Some important text"
                error
              />
              <Stack spacing={0} className="bp-explain explain-default">
                <Stack spacing={0} className="bp-explain-row" direction="row">
                  <Box className="left">
                    <HelpOutline
                      fontSize="small"
                      className="bp-icon xsmall"
                      aria-label="설명"
                      color="disabled"
                    />
                    설명 영역입니다.
                    <strong className="bp-emp">중요한 텍스트 컬러</strong>입니다
                  </Box>
                  <Box className="right"></Box>
                </Stack>
                <Stack spacing={0} className="bp-explain-row" direction="row">
                  <Box className="left">
                    <InfoCircle
                      fontSize="small"
                      className="bp-icon xsmall"
                      aria-label="설명"
                      color="disabled"
                    />
                    설명 영역입니다.
                  </Box>
                  <Box className="right"></Box>
                </Stack>
              </Stack>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>타이틀(Autocomplete)</dt>
            <dd>
              <Autocomplete
                includeInputInList
                size="medium"
                id="select0-1"
                fullWidth
                options={selectOption}
                renderInput={(params) => (
                  <TextField
                    variant="filled"
                    size="medium"
                    label="Label"
                    placeholder="선택"
                    {...params}
                  />
                )}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>
              <div className="left">
                {/* [수정][20240315] 좌우 유형이 있어 해당 케이스는 className="left" 묶어서 표현 */}
                기간(DateRangePicker/Tooltip 포함)
                <Tooltip
                  title={
                    <div className="bp-tooltip">
                      <div className="tooltip-header">
                        <div className="left">
                          <h1 className="title">툴팁 Title</h1>
                        </div>
                        <div className="right"></div>
                      </div>
                      <div className="tooltip-body">
                        툴팁 내용의 상세 설명을 여기에 추가할 수 있습니다.
                      </div>
                    </div>
                  }
                  //open
                >
                  <IconButton
                    className="btn-icon-only btn-icon-info"
                    size="small"
                    aria-label="설명"
                  >
                    <InfoCircle fontSize="small" className="bp-icon xsmall" />
                  </IconButton>
                </Tooltip>
              </div>
            </dt>
            <dd>
              <DateRangePicker
                label="기간"
                className="bp-dateRangePicker fullWidth"
                slots={{
                  field: SingleInputDateRangeField,
                }}
                slotProps={{
                  textField: {
                    InputProps: {
                      startAdornment: (
                        <InputAdornment position="start" className="txt">
                          <strong>일별</strong> |
                        </InputAdornment>
                      ),
                      endAdornment: <Calendar />,
                    },
                    //helperText: "YYYY/MM/DD",
                  },
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>타이틀(TextField-단일 검색)</dt>
            <dd>
              <TextField
                variant="filled"
                size="medium"
                placeholder="(readOnly 샘플)검색어를 입력해 주세요."
                className="bp-search"
                fullWidth
                hiddenLabel
                value={filteredLocations}
                onChange={filterResults}
                onClick={handleClickOpenDialog}
                InputProps={{
                  readOnly: true,
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon
                            fontSize="small"
                            className="bp-icon small"
                          />
                        </IconButton>
                      )}
                      <IconButton
                        aria-label="Search"
                        size="small"
                        className="btn-search"
                      >
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>타이틀(TextField-멀티 검색)</dt>
            <dd>
              <TextField
                variant="filled"
                size="medium"
                label="chip 타입"
                placeholder="(readOnly 샘플)사용자명을 검색해 주세요."
                className="bp-search search-chip"
                fullWidth
                //defaultValue=""
                onClick={handleClickOpenDialog}
                InputLabelProps={
                  {
                    //shrink: true,
                  }
                }
                InputProps={{
                  readOnly: true,
                  /* [D] value값이 들어오면 해당 영역 활성화 */
                  startAdornment: (
                    <InputAdornment position="start" className="chips-groups">
                      <Chip
                        label="chips1"
                        size="small"
                        onDelete={handleDelete}
                      />
                      <Chip
                        label="chips2"
                        size="small"
                        onDelete={handleDelete}
                      />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon
                            fontSize="small"
                            className="bp-icon small"
                          />
                        </IconButton>
                      )}
                      <IconButton
                        aria-label="Search"
                        size="small"
                        className="btn-search"
                      >
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>조회날짜(DatePicker)</dt>
            <dd>
              <DatePicker
                label="시작일"
                className="bp-datePicker fullWidth"
                slotProps={{
                  textField: {
                    helperText: "YYYY/MM/DD",
                  },
                }}
                slots={{ openPickerIcon: Calendar }}
              />
            </dd>
            <dd>
              <DatePicker
                label="종료일"
                className="bp-datePicker fullWidth"
                slotProps={{
                  textField: {
                    helperText: "YYYY/MM/DD",
                  },
                }}
                slots={{ openPickerIcon: Calendar }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>카드(Autocomplete/TextField)</dt>
            <dd>
              <Autocomplete
                includeInputInList
                size="medium"
                id="select1-1"
                fullWidth
                options={selectOption}
                renderInput={(params) => (
                  <TextField
                    variant="filled"
                    size="medium"
                    label="카드그룹"
                    {...params}
                  />
                )}
              />
              {/* 테스트 시 : open */}
            </dd>
            <dd>
              <TextField
                label="카드번호"
                placeholder="카드번호를 입력해주세요."
                fullWidth
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter filter-combine">
            <dt>설정(Switch)</dt>
            <dd>
              <FormControlLabel
                control={<Switch defaultChecked />}
                label="제외 내역 포함"
              />
            </dd>
            <dd>
              <FormControlLabel
                control={<Switch />}
                label="소속 부서 계산서 포함"
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Checkbox-기본)</dt>
            <dd>
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel control={<Checkbox />} label="법인카드" />
                  <FormControlLabel control={<Checkbox />} label="기타간이" />
                </FormGroup>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Checkbox-row)</dt>
            <dd>
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="flex-row">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel control={<Checkbox />} label="법인카드" />
                  <FormControlLabel control={<Checkbox />} label="기타간이" />
                </FormGroup>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Radio-기본)</dt>
            <dd>
              <FormControl>
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className=""
                >
                  <FormControlLabel
                    control={<Radio value="radio01-01" />}
                    label="법인카드"
                  />
                  <FormControlLabel
                    control={<Radio value="radio01-02" />}
                    label="기타간이"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Radio--row)</dt>
            <dd>
              <FormControl>
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className="flex-row"
                >
                  <FormControlLabel
                    control={<Radio value="radio01-01" />}
                    label="법인카드"
                  />
                  <FormControlLabel
                    control={<Radio value="radio01-02" />}
                    label="기타간이"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>표기(FormGroup-Checkbox)</dt>
            <dd>
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <FormGroup className="bp-btns-group fullWidth" row>
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Checkbox />}
                    label="금액"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    disabled
                    control={<Checkbox />}
                    label="건수"
                  />
                </FormGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>표기(RadioGroup-Radio)</dt>
            <dd>
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className="bp-btns-group fullWidth"
                  row
                >
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-01" />}
                    label="검색"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-02" />}
                    label="금액"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-03" />}
                    label="건수"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-1-4. [공통][필터 템플릿 사용]타이틀 없음(UI className="item-filter"
        or className="item-data data-report") + label 有 기본 타입(column타입)
      </h4>
      <Grid container spacing={2}>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">타이틀(TextField)</dt>
            <dd>
              <TextField
                label="Label"
                placeholder="Placeholder 내용을 입력해주세요."
                fullWidth
                helperText="Some important text"
                error
              />
              <Stack spacing={0} className="bp-explain explain-default">
                <Stack spacing={0} className="bp-explain-row" direction="row">
                  <Box className="left">
                    <HelpOutline
                      fontSize="small"
                      className="bp-icon xsmall"
                      aria-label="설명"
                      color="disabled"
                    />
                    설명 영역입니다.
                    <strong className="bp-emp">중요한 텍스트 컬러</strong>입니다
                  </Box>
                  <Box className="right"></Box>
                </Stack>
                <Stack spacing={0} className="bp-explain-row" direction="row">
                  <Box className="left">
                    <InfoCircle
                      fontSize="small"
                      className="bp-icon xsmall"
                      aria-label="설명"
                      color="disabled"
                    />
                    설명 영역입니다.
                  </Box>
                  <Box className="right"></Box>
                </Stack>
              </Stack>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">타이틀(Autocomplete)</dt>
            <dd>
              <Autocomplete
                includeInputInList
                size="medium"
                id="select0-1"
                fullWidth
                options={selectOption}
                renderInput={(params) => (
                  <TextField
                    variant="filled"
                    size="medium"
                    label="Label"
                    placeholder="선택"
                    {...params}
                  />
                )}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">
              <div className="left">기간(DateRangePicker/Tooltip 포함)</div>
            </dt>
            <dd>
              <DateRangePicker
                label="기간"
                className="bp-dateRangePicker fullWidth"
                slots={{
                  field: SingleInputDateRangeField,
                }}
                slotProps={{
                  textField: {
                    InputProps: {
                      startAdornment: (
                        <InputAdornment position="start" className="txt">
                          <strong>일별</strong> |
                        </InputAdornment>
                      ),
                      endAdornment: <Calendar />,
                    },
                    //helperText: "YYYY/MM/DD",
                  },
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">타이틀(TextField-단일 검색)</dt>
            <dd>
              <TextField
                variant="filled"
                size="medium"
                placeholder="(readOnly 샘플)검색어를 입력해 주세요."
                className="bp-search"
                fullWidth
                hiddenLabel
                value={filteredLocations}
                onChange={filterResults}
                onClick={handleClickOpenDialog}
                InputProps={{
                  readOnly: true,
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon
                            fontSize="small"
                            className="bp-icon small"
                          />
                        </IconButton>
                      )}
                      <IconButton
                        aria-label="Search"
                        size="small"
                        className="btn-search"
                      >
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">타이틀(TextField-멀티 검색)</dt>
            <dd>
              <TextField
                variant="filled"
                size="medium"
                label="chip 타입"
                placeholder="(readOnly 샘플)사용자명을 검색해 주세요."
                className="bp-search search-chip"
                fullWidth
                //defaultValue=""
                onClick={handleClickOpenDialog}
                InputLabelProps={
                  {
                    //shrink: true,
                  }
                }
                InputProps={{
                  readOnly: true,
                  /* [D] value값이 들어오면 해당 영역 활성화 */
                  startAdornment: (
                    <InputAdornment position="start" className="chips-groups">
                      <Chip
                        label="chips1"
                        size="small"
                        onDelete={handleDelete}
                      />
                      <Chip
                        label="chips2"
                        size="small"
                        onDelete={handleDelete}
                      />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end" className="btn-groups">
                      {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                        <IconButton
                          size="small"
                          className="btn-clear"
                          onClick={clearSearch}
                        >
                          <CancelIcon
                            fontSize="small"
                            className="bp-icon small"
                          />
                        </IconButton>
                      )}
                      <IconButton
                        aria-label="Search"
                        size="small"
                        className="btn-search"
                      >
                        <SearchSm
                          fontSize="medium"
                          className="bp-icon medium icon-search"
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt className="ir">조회날짜(DatePicker)</dt>
            <dd>
              <DatePicker
                label="시작일"
                className="bp-datePicker fullWidth"
                slotProps={{
                  textField: {
                    helperText: "YYYY/MM/DD",
                  },
                }}
                slots={{ openPickerIcon: Calendar }}
              />
            </dd>
            <dd>
              <DatePicker
                label="종료일"
                className="bp-datePicker fullWidth"
                slotProps={{
                  textField: {
                    helperText: "YYYY/MM/DD",
                  },
                }}
                slots={{ openPickerIcon: Calendar }}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>카드(Autocomplete/TextField)</dt>
            <dd>
              <Autocomplete
                includeInputInList
                size="medium"
                id="select1-1"
                fullWidth
                options={selectOption}
                renderInput={(params) => (
                  <TextField
                    variant="filled"
                    size="medium"
                    label="카드그룹"
                    {...params}
                  />
                )}
              />
              {/* 테스트 시 : open */}
            </dd>
            <dd>
              <TextField
                label="카드번호"
                placeholder="카드번호를 입력해주세요."
                fullWidth
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter filter-combine">
            <dt>설정(Switch)</dt>
            <dd>
              <FormControlLabel
                control={<Switch defaultChecked />}
                label="제외 내역 포함"
              />
            </dd>
            <dd>
              <FormControlLabel
                control={<Switch />}
                label="소속 부서 계산서 포함"
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Checkbox-기본)</dt>
            <dd>
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel control={<Checkbox />} label="법인카드" />
                  <FormControlLabel control={<Checkbox />} label="기타간이" />
                </FormGroup>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Checkbox-row)</dt>
            <dd>
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="flex-row">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel control={<Checkbox />} label="법인카드" />
                  <FormControlLabel control={<Checkbox />} label="기타간이" />
                </FormGroup>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Radio-기본)</dt>
            <dd>
              <FormControl>
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className=""
                >
                  <FormControlLabel
                    control={<Radio value="radio01-01" />}
                    label="법인카드"
                  />
                  <FormControlLabel
                    control={<Radio value="radio01-02" />}
                    label="기타간이"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>사용내역(Radio--row)</dt>
            <dd>
              <FormControl>
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className="flex-row"
                >
                  <FormControlLabel
                    control={<Radio value="radio01-01" />}
                    label="법인카드"
                  />
                  <FormControlLabel
                    control={<Radio value="radio01-02" />}
                    label="기타간이"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>표기(FormGroup-Checkbox)</dt>
            <dd>
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <FormGroup className="bp-btns-group fullWidth" row>
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Checkbox defaultChecked />}
                    label="전체"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Checkbox />}
                    label="금액"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    disabled
                    control={<Checkbox />}
                    label="건수"
                  />
                </FormGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-filter">
            <dt>표기(RadioGroup-Radio)</dt>
            <dd>
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className="bp-btns-group fullWidth"
                  row
                >
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-01" />}
                    label="검색"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-02" />}
                    label="금액"
                  />
                  <FormControlLabel
                    className="btn-form-type"
                    control={<Radio value="radio03-03" />}
                    label="건수"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-4. [공통][상세 템플릿 사용]타이틀 별도(UI className="item-data
        data-report") 기본 타입
      </h4>
      <Grid container spacing={2}>
        <Grid xs={4}>
          <dl className="item-data data-report">
            <dt>
              기본 샘플<i className="required">*</i>
            </dt>
            <dd className="txt-data">
              <strong className="text-primary">강조할 때 색상</strong>
              <p className="text-primary">
                강조할 때 색상(태그는 원하는 상황에 맞춰 주세요)
              </p>
            </dd>
          </dl>
        </Grid>
        <Grid xs={4}>
          <dl className="item-data data-report">
            <dt>
              우측정렬 샘플<i className="required">*</i>
            </dt>
            <dd className="txt-data align-right">₩ 37,000</dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-5. [공통][상세/drawer 레이어 템플릿 사용]타이틀 별도(UI
        className="item-data data-report type-row") row 타입 + label
        無(hiddenLabel) 타입
      </h4>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            <dt>
              사용자<i className="required">*</i>
            </dt>
            <dd className="txt-data">
              <strong className="text-primary">
                지출결의 10월 1건 50,000원 홍길동 작성
              </strong>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            <dt>
              타이틀(FormGroup-Checkbox)<i className="required">*</i>
            </dt>
            <dd className="txt-data">
              <FormControl component="fieldset" variant="standard">
                <FormGroup className="flex-row">
                  <FormControlLabel
                    control={<Checkbox defaultChecked />}
                    label="옵션1 Checked"
                  />
                  <FormControlLabel
                    required
                    control={<Checkbox />}
                    label="옵션2 Required"
                  />
                  <FormControlLabel
                    disabled
                    control={<Checkbox />}
                    label="옵션3 Disabled"
                  />
                  <FormControlLabel
                    disabled
                    checked
                    control={<Checkbox />}
                    label="옵션4 Checkbox Disabled"
                  />
                </FormGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            <dt>타이틀(RadioGroup-Radio)</dt>
            <dd className="txt-data">
              <FormControl>
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radio01"
                  name="radio buttons group"
                  className="flex-row"
                >
                  <FormControlLabel
                    control={<Radio value="radio01-01" />}
                    label="Radio Checked"
                  />
                  <FormControlLabel
                    required
                    control={<Radio value="radio01-02" />}
                    label="Radio Required"
                  />
                  <FormControlLabel
                    disabled
                    control={<Radio value="radio01-03" />}
                    label="Radio Disabled"
                  />
                </RadioGroup>
                <FormHelperText>You can display an error</FormHelperText>
              </FormControl>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>
              타이틀(TextField)<i className="required">*</i>
            </dt>
            <dd className="txt-data">
              <TextField
                variant="filled"
                size="small"
                placeholder="내용을 입력하세요"
                fullWidth
                hiddenLabel
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>타이틀(Autocomplete)</dt>
            <dd className="txt-data">
              <Autocomplete
                includeInputInList
                size="small"
                id="select1-1"
                fullWidth
                options={selectOption}
                renderInput={(params) => (
                  <TextField
                    variant="filled"
                    size="small"
                    placeholder="내용을 입력하세요"
                    {...params}
                    hiddenLabel
                  />
                )}
              />
              {/* 테스트 시 : open */}
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>선택박스(~)</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field has-dash">
                {/* [D]~를 가지고 있는 그리드의 경우 class="has-dash"  */}
                <Grid xs={5}>
                  <Autocomplete
                    includeInputInList
                    size="small"
                    id="select1-1"
                    fullWidth
                    options={selectOption}
                    renderInput={(params) => (
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder="내용을 입력하세요"
                        {...params}
                        hiddenLabel
                      />
                    )}
                  />
                  {/* 테스트 시 : open */}
                  <span className="bp-dash">~</span>
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
                <Grid xs={5}>
                  <Autocomplete
                    includeInputInList
                    size="small"
                    id="select1-1"
                    fullWidth
                    options={selectOption}
                    renderInput={(params) => (
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder="내용을 입력하세요"
                        {...params}
                        hiddenLabel
                      />
                    )}
                  />
                  {/* 테스트 시 : open */}
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>필드 그리드 샘플(bp-grid-field)</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field">
                <Grid xs={8}>
                  <TextField
                    variant="filled"
                    size="small"
                    placeholder="내용을 입력하세요"
                    fullWidth
                    hiddenLabel
                  />
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
                <Grid xs={4}>form field 그리드 샘플</Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>직원</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field">
                <Grid xs={8}>
                  <TextField
                    variant="filled"
                    size="small"
                    placeholder="직원 검색"
                    className="bp-search"
                    fullWidth
                    hiddenLabel
                    value={filteredLocations}
                    onChange={filterResults}
                    InputProps={{
                      readOnly: true,
                      endAdornment: (
                        <InputAdornment position="end" className="btn-groups">
                          {filteredLocations && ( // value 값이 있는 경우에만 clear 버튼 생성
                            <IconButton
                              size="small"
                              className="btn-clear"
                              onClick={clearSearch}
                            >
                              <CancelIcon
                                fontSize="small"
                                className="bp-icon small"
                              />
                            </IconButton>
                          )}
                          <IconButton
                            aria-label="Search"
                            size="small"
                            className="btn-search"
                          >
                            <SearchSm
                              fontSize="medium"
                              className="bp-icon medium icon-search"
                            />
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>입력항목날짜/시간</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field">
                <Grid xs={8}>
                  <DateTimePicker
                    views={[
                      "year",
                      "month",
                      "day",
                      "hours",
                      "minutes",
                      "seconds",
                    ]}
                    className="bp-dateTimePicker size-small fullWidth"
                    slotProps={{
                      textField: {
                        helperText: "YYYY/MM/DD hh/mm aa",
                      },
                    }}
                    slots={{ openPickerIcon: Calendar }}
                  />
                  {/*  open */}
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>시간기간(시분)</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field field-time">
                <Grid xs={3}>
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="HH"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">시</span>
                  </div>
                </Grid>
                <Grid xs={3} className="bp-dash">
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="MM"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">분</span>
                  </div>
                </Grid>
                <Grid xs={3}>
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="HH"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">시</span>
                  </div>
                </Grid>
                <Grid xs={3}>
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="MM"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">분</span>
                  </div>
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>시간기간(시분)</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field field-time">
                <Grid xs={3}>
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="HH"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">시</span>
                  </div>
                </Grid>
                <Grid xs={3}>
                  <div className="field-time-group">
                    <Autocomplete
                      includeInputInList
                      size="small"
                      id="select0-2"
                      fullWidth
                      options={selectOption}
                      renderInput={(params) => (
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="MM"
                          hiddenLabel
                          {...params}
                        />
                      )}
                    />
                    <span className="txt">분</span>
                  </div>
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>기간</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field field-date">
                <Grid xs={4} className="bp-dash">
                  <div className="field-date-group">
                    <DatePicker
                      className="bp-datePicker size-small fullWidth"
                      format="yyyy/MM/dd"
                      slotProps={{
                        textField: {
                          helperText: "YYYY/MM/DD",
                        },
                      }}
                      slots={{
                        openPickerIcon: Calendar,
                      }}
                    />
                    {/*  open */}
                  </div>
                </Grid>
                <Grid xs={4}>
                  <div className="field-date-group">
                    <DatePicker
                      className="bp-datePicker size-small fullWidth"
                      slotProps={{
                        textField: {
                          helperText: "YYYY/MM/DD",
                        },
                      }}
                      slots={{
                        openPickerIcon: Calendar,
                      }}
                    />
                    {/*  open */}
                  </div>
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            {/* [D]상하 중앙 정렬:type-valign-center */}
            <dt>일자</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field">
                <Grid xs={8}>
                  <DatePicker
                    className="bp-datePicker size-small fullWidth"
                    format="yyyy/MM/dd"
                    slotProps={{
                      textField: {
                        //helperText: "YYYY/MM/DD",
                      },
                    }}
                    slots={{ openPickerIcon: Calendar }}
                  />
                  {/*  open */}
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
              </Grid>
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            <dt>내용</dt>
            <dd className="txt-data">
              <TextField
                variant="filled"
                placeholder="내용을 입력해 주세요."
                fullWidth
                hiddenLabel
                multiline
                maxRows={4}
              />
            </dd>
          </dl>
        </Grid>
        <Grid xs={12}>
          <dl className="item-data data-report type-row">
            <dt>항목1</dt>
            <dd className="txt-data">
              <Grid container spacing={2} className="bp-grid-field">
                <Grid xs={3}>
                  <dl className="item-flex">
                    <dt>항목명</dt>
                    <dd>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder=""
                        fullWidth
                        hiddenLabel
                      />
                    </dd>
                  </dl>
                </Grid>
                <Grid xs={3}>
                  <dl className="item-flex">
                    <dt>입력타입</dt>
                    <dd>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder=""
                        fullWidth
                        hiddenLabel
                      />
                    </dd>
                  </dl>
                </Grid>
                <Grid xs={3}>
                  <div className="has-info-group">
                    <FormControlLabel
                      control={<Checkbox defaultChecked />}
                      label="필수여부"
                    />
                    <Tooltip
                      title={
                        <div className="bp-tooltip">
                          <div className="tooltip-header">
                            <div className="left">
                              <h1 className="title">툴팁 Title</h1>
                            </div>
                            <div className="right"></div>
                          </div>
                          <div className="tooltip-body">
                            툴팁 내용의 상세 설명을 여기에 추가할 수 있습니다.
                          </div>
                        </div>
                      }
                      //open
                    >
                      <IconButton
                        className="btn-icon-only btn-icon-info"
                        size="small"
                        aria-label="설명"
                      >
                        <InfoCircle
                          fontSize="small"
                          className="bp-icon xsmall"
                        />
                      </IconButton>
                    </Tooltip>
                  </div>
                </Grid>
                <Grid xs={2}>
                  <div className="btns-group">
                    <IconButton
                      className="btn-icon-only btn-circle btn-bg-fill-reverse"
                      size="small"
                      color="primary"
                      aria-label="추가"
                    >
                      <AddOutlinedIcon
                        fontSize="small"
                        className="bp-icon small"
                      />
                    </IconButton>
                    <IconButton
                      className="btn-icon-only btn-circle btn-bg-fill-reverse btn-basic"
                      size="small"
                      color="error"
                      aria-label="제거"
                    >
                      <HorizontalRuleOutlinedIcon
                        fontSize="small"
                        className="bp-icon small"
                      />
                    </IconButton>
                  </div>
                </Grid>
              </Grid>
            </dd>
          </dl>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-6. [공통][등록/수정 템플릿 사용]타이틀 별도(UI className="item-data
        data-report type-row") row 타입 + label 無(hiddenLabel) 타입
      </h4>
      <Grid container spacing={2}>
        <Grid xs={12}>
          {/* [S]리스트 저장/수정 */}
          <List dense className="bp-list list-item-reg">
            <ListItem>
              <Grid container spacing={2} className="bp-grid-field fullWidth">
                <Grid xs={4}>
                  <dl className="item-data data-report type-sTitle">
                    <dt>거래처 유형</dt>
                    <dd className="txt-data">
                      <FormControl
                        component="fieldset"
                        variant="standard"
                        className="fullWidth"
                      >
                        <RadioGroup
                          aria-labelledby="radio-buttons-group"
                          defaultValue="radio01-01"
                          name="radio buttons group"
                          className="bp-btns-group group-type fullWidth"
                          row
                        >
                          <FormControlLabel
                            className="btn-form-type"
                            control={<Radio value="radio01-01" />}
                            label="법입"
                          />
                          <FormControlLabel
                            className="btn-form-type"
                            control={<Radio value="radio01-02" disabled />}
                            label="개인"
                          />
                        </RadioGroup>
                      </FormControl>
                    </dd>
                  </dl>
                </Grid>
                <Grid xs={4}>
                  <dl className="item-data data-report type-sTitle">
                    <dt>상태</dt>
                    <dd className="txt-data">
                      <FormControl
                        component="fieldset"
                        variant="standard"
                        className="fullWidth"
                      >
                        <RadioGroup
                          aria-labelledby="radio-buttons-group"
                          defaultValue="radio02-01"
                          name="radio buttons group"
                          className="bp-btns-group group-type fullWidth"
                          row
                        >
                          <FormControlLabel
                            className="btn-form-type"
                            control={<Radio value="radio02-01" />}
                            label="사용"
                          />
                          <FormControlLabel
                            className="btn-form-type"
                            control={<Radio value="radio02-02" disabled />}
                            label="미사용"
                          />
                        </RadioGroup>
                      </FormControl>
                    </dd>
                  </dl>
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
              </Grid>
            </ListItem>
            <ListItem>
              <Grid container spacing={2} className="bp-grid-field fullWidth">
                <Grid xs={6}>
                  <TextField
                    label="거래처명"
                    placeholder=""
                    fullWidth
                    required
                  />
                </Grid>
                <Grid xs={6}>
                  <TextField label="거래처코드" placeholder="" fullWidth />
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
              </Grid>
            </ListItem>
            <ListItem>
              <Grid container spacing={2} className="bp-grid-field fullWidth">
                <Grid xs={6}>
                  <TextField label="관리번호" placeholder="" fullWidth />
                </Grid>
                <Grid xs={6}>
                  <TextField label="ERP코드" placeholder="" fullWidth />
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
              </Grid>
            </ListItem>
            <ListItem>
              <Grid container spacing={2} className="bp-grid-field fullWidth">
                <Grid xs={12}>
                  <TextField label="메모" placeholder="" fullWidth />
                </Grid>
                {/* 12그리드 기준으로 뒤에 추가 될 경우 아래와 같이 추가(sx의 최대 합 12) */}
              </Grid>
            </ListItem>
          </List>
          {/* [E]리스트 저장/수정 */}
          <List
            dense
            className="bp-list list-item-reg list-item-flex list-item-line"
          >
            {/* [D]라인이 있는 경우:list-item-line */}
            <ListItem className="size-50per">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>타이틀 배경 있는 타입 리스트</dt>
                <dd className="txt-data">웹케시그룹</dd>
              </dl>
            </ListItem>
            <ListItem className="size-50per">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>그룹코드</dt>
                <dd className="txt-data">webcash</dd>
              </dl>
            </ListItem>
            <ListItem className="fullWidth">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>
                  그룹코드<i className="required"> *</i>
                </dt>
                <dd className="txt-data">
                  <FormControl>
                    <RadioGroup
                      aria-labelledby="radio-buttons-group"
                      defaultValue="radio01"
                      name="radio buttons group"
                      className="flex-row"
                    >
                      <FormControlLabel
                        control={<Radio value="radio01-01" />}
                        label="국내"
                      />
                      <FormControlLabel
                        control={<Radio value="radio01-02" />}
                        label="해외"
                      />
                    </RadioGroup>
                  </FormControl>
                </dd>
              </dl>
            </ListItem>
            <ListItem className="fullWidth">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>대표전화번호</dt>
                <dd className="txt-data">
                  <Grid container spacing={2} className="bp-grid-field">
                    <Grid xs={2}>
                      <Autocomplete
                        includeInputInList
                        size="small"
                        id="select1-1"
                        fullWidth
                        options={selectOption}
                        renderInput={(params) => (
                          <TextField
                            variant="filled"
                            size="small"
                            placeholder="선택"
                            {...params}
                            hiddenLabel
                          />
                        )}
                      />
                      {/* 테스트 시 : open */}
                    </Grid>
                    <Grid xs={2}>
                      <Autocomplete
                        includeInputInList
                        size="small"
                        id="select1-1"
                        fullWidth
                        options={selectOption}
                        renderInput={(params) => (
                          <TextField
                            variant="filled"
                            size="small"
                            placeholder="선택"
                            {...params}
                            hiddenLabel
                          />
                        )}
                      />
                      {/* 테스트 시 : open */}
                    </Grid>
                    <Grid xs={5}>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder=""
                        fullWidth
                        hiddenLabel
                      />
                    </Grid>
                  </Grid>
                </dd>
              </dl>
            </ListItem>
            <ListItem className="fullWidth">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>휴대폰번호</dt>
                <dd className="txt-data">
                  <Grid container spacing={2} className="bp-grid-field">
                    <Grid xs={2}>
                      <Box
                        className={`btn-dropdown dropdown-nation ${writeOpen ? "is-open" : ""}`}
                      >
                        <Button
                          variant="outlined"
                          size="large"
                          className="btn-basic"
                          fullWidth
                          id="write-button"
                          onClick={handleWriteOpen}
                          ref={writeAnchorRef}
                          aria-controls={writeOpen ? "write-menu" : undefined}
                          aria-expanded={writeOpen ? "true" : undefined}
                          aria-haspopup="true"
                          endIcon={
                            <ArrowDropDownOutlinedIcon
                              fontSize="small"
                              className="bp-icon small"
                            />
                          }
                        >
                          +82
                        </Button>
                        <Popper
                          open={writeOpen}
                          anchorEl={writeAnchorRef.current}
                          role={undefined}
                          placement="bottom-start"
                          transition
                          disablePortal
                          className="popper-dropdown fullWidth dropdown-Division"
                        >
                          {({ TransitionProps, placement }) => (
                            <Grow
                              {...TransitionProps}
                              style={{
                                transformOrigin:
                                  placement === "bottom-start"
                                    ? "left top"
                                    : "left bottom",
                              }}
                            >
                              <Paper>
                                <ClickAwayListener
                                  onClickAway={handleWriteClose}
                                >
                                  <Scrollbar className="ui-scroll">
                                    <MenuList
                                      autoFocusItem={writeOpen}
                                      id="write-menu"
                                      aria-labelledby="write-button"
                                      onKeyDown={handleListKeyDown}
                                    >
                                      <MenuItem onClick={handleWriteClose}>
                                        <div className="nation-box">
                                          <span className="flag">
                                            <img
                                              src="/assets/nation-image/KR.png"
                                              width={24}
                                              height={16}
                                              alt="대한민국(Republic of Korea) +82"
                                            />
                                          </span>
                                          <span className="txt">
                                            대한민국(Republic of Korea) +82
                                          </span>
                                        </div>
                                      </MenuItem>
                                      <MenuItem onClick={handleWriteClose}>
                                        <div className="nation-box">
                                          <span className="flag">
                                            <img
                                              src="/assets/nation-image/US.png"
                                              width={24}
                                              height={16}
                                              alt="미국(United States of America)
                                                  +1"
                                            />
                                          </span>
                                          <span className="txt">
                                            미국(United States of America) +1
                                          </span>
                                        </div>
                                      </MenuItem>
                                      <MenuItem onClick={handleWriteClose}>
                                        <div className="nation-box">
                                          <span className="flag">
                                            <img
                                              src="/assets/nation-image/CN.png"
                                              width={24}
                                              height={16}
                                              alt="중국(China) +86"
                                            />
                                          </span>
                                          <span className="txt">
                                            중국(China) +86
                                          </span>
                                        </div>
                                      </MenuItem>
                                      <MenuItem onClick={handleWriteClose}>
                                        <div className="nation-box">
                                          <span className="flag">
                                            <img
                                              src="/assets/nation-image/JP.png"
                                              width={24}
                                              height={16}
                                              alt="일본(Japan) +81"
                                            />
                                          </span>
                                          <span className="txt">
                                            일본(Japan) +81
                                          </span>
                                        </div>
                                      </MenuItem>
                                      <MenuItem onClick={handleWriteClose}>
                                        <div className="nation-box">
                                          <span className="flag">
                                            <img
                                              src="/assets/nation-image/VN.png"
                                              width={24}
                                              height={16}
                                              alt="베트남(Vietnam) +84"
                                            />
                                          </span>
                                          <span className="txt">
                                            베트남(Vietnam) +84
                                          </span>
                                        </div>
                                      </MenuItem>
                                    </MenuList>
                                  </Scrollbar>
                                </ClickAwayListener>
                              </Paper>
                            </Grow>
                          )}
                        </Popper>
                      </Box>
                    </Grid>
                    <Grid xs={7}>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder=""
                        fullWidth
                        hiddenLabel
                      />
                    </Grid>
                  </Grid>
                </dd>
              </dl>
            </ListItem>
            <ListItem className="fullWidth">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>회사 전화번호</dt>
                <dd className="txt-data">
                  <Grid container spacing={2} className="bp-grid-field">
                    <Grid xs={2}>
                      <Autocomplete
                        includeInputInList
                        size="small"
                        id="select1-1"
                        fullWidth
                        options={selectOption}
                        renderInput={(params) => (
                          <TextField
                            variant="filled"
                            size="small"
                            placeholder="선택"
                            {...params}
                            hiddenLabel
                          />
                        )}
                      />
                      {/* 테스트 시 : open */}
                    </Grid>
                    <Grid xs={5}>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder="전화번호"
                        fullWidth
                        hiddenLabel
                      />
                    </Grid>
                    <Grid xs={2}>
                      <TextField
                        variant="filled"
                        size="small"
                        placeholder="내선번호"
                        fullWidth
                        hiddenLabel
                      />
                    </Grid>
                  </Grid>
                </dd>
              </dl>
            </ListItem>
            <ListItem className="fullWidth">
              <dl className="item-data data-report type-row type-bg">
                {/* [D]상하 중앙 정렬:type-valign-center */}
                <dt>주소</dt>
                <dd className="txt-data">
                  <div className="bp-grid-field-wrap">
                    <Grid container spacing={2} className="bp-grid-field">
                      <Grid xs={2}>
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="우편번호"
                          fullWidth
                          hiddenLabel
                        />
                      </Grid>
                      <Grid xs={5}>
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="주소"
                          fullWidth
                          hiddenLabel
                          InputProps={{
                            readOnly: true,
                          }}
                        />
                      </Grid>
                      <Grid xs={2}>
                        <Button variant="contained" size="large" className="">
                          주소 검색
                        </Button>
                      </Grid>
                    </Grid>
                    <Grid container spacing={2} className="bp-grid-field">
                      <Grid xs={9}>
                        <TextField
                          variant="filled"
                          size="small"
                          placeholder="상세 주소"
                          fullWidth
                          hiddenLabel
                        />
                      </Grid>
                    </Grid>
                  </div>
                </dd>
              </dl>
            </ListItem>
          </List>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>10-7. [공통][설명]설명 유형</h4>
      <Grid container spacing={2}>
        <Grid xs={12}>
          {/* [S]테이블 하단 설명 */}
          <Stack spacing={0} className="bp-group-description">
            <Stack
              spacing={0}
              className="bp-group-description-row"
              direction="row"
            >
              <Box className="left"></Box>
              <Box className="right">
                <Typography variant="body1" className="bp-description">
                  (테이블 or 리스트 하단에 사용)
                  <i className="required">*</i>은 필수로 입력해야 합니다.
                </Typography>
              </Box>
            </Stack>
            <Stack
              spacing={0}
              className="bp-group-description-row description-type2"
              direction="row"
            >
              <Box className="left">
                <Typography variant="body2" className="bp-description">
                  최대 1개월까지 조회 가능합니다.
                </Typography>
              </Box>
              <Box className="right">
                <Chip
                  label="(국세청 팝업 하단에 사용) 마지막 실행일시: 2024/02/20 19:34:15"
                  size="small"
                  className="bp-chip color-twotone color-action-selected"
                />
              </Box>
            </Stack>
          </Stack>
          {/* [E]테이블 하단 설명 */}
        </Grid>
        <Grid xs={12}>
          {/* [S]테이블 하단 설명 */}
          <Stack
            spacing={0}
            className="bp-group-description description-bottom"
          >
            <Stack
              spacing={0}
              className="bp-group-description-row"
              direction="row"
            >
              <Box className="left">
                <List dense className="bp-list list-dotted">
                  <ListItem>
                    <i className="icon-dotted"></i>(테이블 or 리스트 하단에
                    사용) 문의사항은 고객센터 1566-7235로 연락 주시면 빠른 안내
                    도와드리겠습니다.
                  </ListItem>
                </List>
              </Box>
              <Box className="right"></Box>
            </Stack>
          </Stack>
          {/* [E]테이블 하단 설명 */}
        </Grid>
        <Grid xs={12}>
          {/* [S]설명 그룹 */}
          <Stack spacing={0} className="bp-group-description description-top">
            <Stack
              spacing={0}
              className="bp-group-description-row"
              direction="row"
            >
              <Box className="left">
                <List dense className="bp-list list-dotted">
                  <ListItem>(바닥페이지 단독 상단 설며응로 사용)</ListItem>
                  <ListItem>
                    <i className="icon-dotted"></i>
                    [입력항목 - 거래처] 사용 시, [기초정보관리 - 거래처]에서
                    설정된 [지급조건, 지급방법]을 사용영역에 불러오는
                    기능입니다.
                  </ListItem>
                  <ListItem>
                    <i className="icon-dotted"></i>
                    [기초정보관리 - 거래처]에 설정된 [지급조건, 지급방법]이 없는
                    경우, 사용영역에서 설정된 [입력항목]의 리스트에서 직접선택이
                    가능합니다.
                  </ListItem>
                </List>
              </Box>
              <Box className="right"></Box>
            </Stack>
          </Stack>
          {/* [E]설명 그룹 */}
        </Grid>
        <Grid xs={12}>
          {/* [S]팝업 내 설명 */}
          <Stack
            spacing={0}
            className="bp-group-description description-top description-bgType"
          >
            <Stack
              spacing={0}
              className="bp-group-description-row"
              direction="row"
            >
              <Box className="left">
                {/* [S]타이틀 그룹 */}
                <Stack className="bp-group-title">
                  <Stack
                    spacing={0}
                    className="bp-group-title-row"
                    direction="row"
                  >
                    <Box className="left">
                      <Typography variant="h2" className="bp-title title-sub">
                        EDI 신청 전 꼭 확인해주세요
                      </Typography>
                    </Box>
                    <Box className="right"></Box>
                  </Stack>
                </Stack>
                {/* [E]타이틀 그룹 */}
                <List dense className="bp-list list-checked">
                  <ListItem>
                    <CheckCircleOutline
                      fontSize="small"
                      className="bp-icon xsmall"
                    />
                    데이터 수신 소요기간은 영업일 기준 약 5일 소요되며,
                    우리카드는 등록일 익일부터 수신됩니다.
                  </ListItem>
                  <ListItem>
                    <CheckCircleOutline
                      fontSize="small"
                      className="bp-icon xsmall"
                    />
                    신청 후 상태가 ‘완료'로 변경되면 [카드현황] 메뉴에서 내역을
                    확인할 수 있습니다.
                  </ListItem>
                </List>
                <List dense className="bp-list">
                  <ListItem className="txt-import">
                    분할시 사용내역 목록에는 [분할1] 항목내용이 표기됩니다.
                  </ListItem>
                </List>
              </Box>
              <Box className="right"></Box>
            </Stack>
          </Stack>
          {/* [E]팝업 내 설명 */}
        </Grid>
        <Grid xs={12}>
          <Stack spacing={0} className="bp-message message-top">
            <Stack spacing={0} className="bp-group-message-row" direction="row">
              <Box className="left"></Box>
              <Box className="center">
                서버 다운로드 신청 현황 및 다운로드를 할 수 있습니다.
              </Box>
              <Box className="right"></Box>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack spacing={0} className="bp-message message-bottom">
            <Stack spacing={0} className="bp-group-message-row" direction="row">
              <Box className="left"></Box>
              <Box className="center">총 15 건의 결재를 진행하시겠습니까?</Box>
              <Box className="right"></Box>
            </Stack>
          </Stack>
        </Grid>
      </Grid>

      <h4 className={styles.heading4}>
        10-8. [공통][카드 상/하단 버튼 영역]하단 버튼 유형
      </h4>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack spacing={0} className="bp-btns-footer title-top">
            <Box className="left"></Box>
            <Box className="center"></Box>
            <Box className="right">
              <Button size="medium" color="error">
                초기화/삭제
              </Button>
              <Button size="medium" className="btn-text-primary">
                취소
              </Button>
              <Button variant="contained" size="medium">
                저장/확인/완료/선택완료/적용/결재요청
              </Button>
            </Box>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack spacing={0} className="bp-btns-footer btns-bottom">
            <Box className="left"></Box>
            <Box className="center"></Box>
            <Box className="right">
              <Button size="medium" color="error">
                초기화/삭제
              </Button>
              <Button size="medium" className="btn-text-primary">
                취소
              </Button>
              <Button variant="contained" size="medium">
                저장/확인/완료/선택완료/적용/결재요청
              </Button>
            </Box>
          </Stack>
        </Grid>
      </Grid>
    </>
  );
};

export default BpComponent;
