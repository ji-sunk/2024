import { Box, List, ListItem } from "@mui/material";
import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Autoplay, Navigation, Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import MyCard from "../common/MyCard";
import MyCardSkeleton from "../common/MyCardSkeleton";

// let slideInx = 0;
const MyCardListSwiper = () => {
  SwiperCore.use([Navigation, Scrollbar, Autoplay, Pagination]);
  return (
    <>
      <div className="swiper-container mycard">
        <Swiper
          className="mycard-area"
          loop={true} // 슬라이드 루프
          centeredSlides={true}
          spaceBetween={12} // 슬라이스 사이 간격
          slidesPerView={1.2} // 보여질 슬라이스 수
          navigation={false} // prev, next button
          grabCursor={true}
          pagination={{
            el: ".swiper-pagination",
            type: "fraction",
            formatFractionCurrent: function (number) {
              return "" + number;
            },
          }}
        >
          <SwiperSlide>
            <div>
              {/* [D]카드로딩중 : add "is-skeleton" */}
              <MyCardSkeleton />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div>
              <MyCard />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div>
              {/* [S] */}
              <div className="card-info">
                <Box className="card-box" data-code="374">
                  <div className="item-header">
                    <div className="left-area">
                      <Box className="item-logo">
                        <img
                          src="../../assets/images/card/logo-374.png"
                          alt="하나카드"
                        />
                      </Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-nickname">하나(비플)카드</Box>
                    </div>
                  </div>
                  <div className="item-cont">
                    <List className="list-card-number">
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                    </List>
                  </div>
                  <div className="item-footer inner-sides">
                    <div className="left-area">
                      <Box className="txt">비즈플레이 주식회사</Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-expiration">04/25</Box>
                    </div>
                  </div>
                  <Box className="tip">
                    <Box className="txt">
                      카드사로부터 정보를 받아오는 중 입니다.
                    </Box>
                  </Box>
                </Box>
              </div>
              {/* [E] */}
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div>
              {/* [S] */}
              <div className="card-info">
                <Box className="card-box" data-code="367">
                  <div className="item-header">
                    <div className="left-area">
                      <Box className="item-logo">
                        <img
                          src="../../assets/images/card/logo-367.png"
                          alt="현대카드"
                        />
                      </Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-nickname">현대(비플)카드</Box>
                    </div>
                  </div>
                  <div className="item-cont">
                    <List className="list-card-number">
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                    </List>
                  </div>
                  <div className="item-footer inner-sides">
                    <div className="left-area">
                      <Box className="txt">비즈플레이 주식회사</Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-expiration">04/25</Box>
                    </div>
                  </div>
                  <Box className="tip">
                    <Box className="txt">
                      카드사로부터 정보를 받아오는 중 입니다.
                    </Box>
                  </Box>
                </Box>
              </div>
              {/* [E] */}
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div>
              {/* [S] */}
              <div className="card-info">
                <Box className="card-box" data-code="372">
                  <div className="item-header">
                    <div className="left-area">
                      <Box className="item-logo">
                        <img
                          src="../../assets/images/card/logo-372.png"
                          alt="현대카드"
                        />
                      </Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-nickname">전북(비플)카드</Box>
                    </div>
                  </div>
                  <div className="item-cont">
                    <List className="list-card-number">
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt is-masking">＊＊＊＊</Box>
                      </ListItem>
                      <ListItem className="item">
                        <Box className="txt">0000</Box>
                      </ListItem>
                    </List>
                  </div>
                  <div className="item-footer inner-sides">
                    <div className="left-area">
                      <Box className="txt">비즈플레이 주식회사</Box>
                    </div>
                    <div className="right-area">
                      <Box className="data-expiration">04/25</Box>
                    </div>
                  </div>
                  <Box className="tip">
                    <Box className="txt">
                      카드사로부터 정보를 받아오는 중 입니다.
                    </Box>
                  </Box>
                </Box>
              </div>
              {/* [E] */}
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
      <div className="pagination-box">
        <div className="swiper-pagination"></div>
      </div>
    </>
  );
};

export default MyCardListSwiper;
