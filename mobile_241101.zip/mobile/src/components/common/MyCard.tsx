import { Box, List, ListItem } from "@mui/material";
import { FC } from "react";

type MyCardProps = {};
const MyCard: FC<MyCardProps> = () => {
  return (
    <>
      {/* [D]카드로딩중 : add "is-skeleton" */}
      <div className="card-info">
        <Box className="card-box" data-code="361">
          <div className="item-header">
            <div className="left-area">
              <Box className="item-logo">
                <img src="../../assets/images/card/logo-361.png" alt="BC카드" />
              </Box>
            </div>
            <div className="right-area">
              <Box className="data-nickname">BC(비플)카드</Box>
            </div>
          </div>
          <div className="item-cont">
            <List className="list-card-number">
              <ListItem className="item">
                <Box className="txt">0000</Box>
              </ListItem>
              <ListItem className="item">
                <Box className="txt is-masking">＊＊＊＊</Box>
              </ListItem>
              <ListItem className="item">
                <Box className="txt is-masking">＊＊＊＊</Box>
              </ListItem>
              <ListItem className="item">
                <Box className="txt">0000</Box>
              </ListItem>
            </List>
          </div>
          <div className="item-footer inner-sides">
            <div className="left-area">
              <Box className="txt">비즈플레이 주식회사</Box>
            </div>
            <div className="right-area">
              <Box className="data-expiration">04/25</Box>
            </div>
          </div>
          <Box className="tip">
            <Box className="txt">카드사로부터 정보를 받아오는 중 입니다.</Box>
          </Box>
        </Box>
      </div>
    </>
  );
};

export default MyCard;
