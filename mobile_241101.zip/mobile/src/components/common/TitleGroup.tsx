import { Box, Typography } from "@mui/material";
import { ChevronRight } from "@untitled-ui/icons-react";
import { ReactNode } from "react";
import { Link } from "react-router-dom";

interface TitleGroupProps {
  children?: ReactNode;
}
const TitleGroup = (props: TitleGroupProps) => {
  return (
    <>
      <Box className="title-group inner-sides">
        <Box className="left-area">
          <Typography variant="h6">사용내역</Typography>
        </Box>
        <Box className="right-area">
          <Link to="#" className="item-link">
            전체보기
            <ChevronRight className="bp-icon" />
          </Link>
        </Box>
      </Box>
    </>
  );
};

export default TitleGroup;
